(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
/*************************************************
              Board Rotation                    
*************************************************/
var storage
var storagePrefix = 'KiCad_HTML_BOM__' + pcbdata.metadata.title + '__' + pcbdata.metadata.revision + '__'

function initStorage (key) {
  try {
    window.localStorage.getItem("blank");
    storage = window.localStorage;
  } catch (e) {
    console.log("Storage init error");
    // localStorage not available
  }
  if (!storage) {
    try {
      window.sessionStorage.getItem("blank");
      storage = window.sessionStorage;
    } catch (e) {
      // sessionStorage also not available
    }
  }
}

function readStorage(key) {
  if (storage) {
    return storage.getItem(storagePrefix + '#' + key);
  } else {
    return null;
  }
}

function writeStorage(key, value) {
  if (storage) {
    storage.setItem(storagePrefix + '#' + key, value);
  }
}

/************************************************/

/*************************************************
              Highlighted Refs                    
*************************************************/
var highlightedRefs = [];

function setHighlightedRefs(refs){
    highlightedRefs = refs;
}

function getHighlightedRefs(){
    return highlightedRefs;
}
/************************************************/

/*************************************************
              Redraw On Drag                      
*************************************************/
var redrawOnDrag = true;

  
function setRedrawOnDrag(value){
    redrawOnDrag = value;
    writeStorage("redrawOnDrag", value);
}

function getRedrawOnDrag(){
    return redrawOnDrag;
}

/************************************************/

/*************************************************
BOM Split
*************************************************/
var bomsplit;

function setBomSplit(value){
    bomsplit = value;
}

function getBomSplit(){
    return bomsplit;
}

function destroyBomSplit(){
    bomsplit.destroy()
}

/************************************************/

/*************************************************
Canvas Split
*************************************************/
var canvassplit;

function setCanvasSplit(value){
    canvassplit = value;
}

function getCanvasSplit(){
    return canvassplit;
}

function destroyCanvasSplit(){
    canvassplit.destroy()
}

function collapseCanvasSplit(value)
{
    canvassplit.collapse(value);
}

function setSizesCanvasSplit(value){
    canvassplit.setSizes([50, 50]);
}

/************************************************/

/*************************************************
Canvas Layout
*************************************************/
var canvaslayout = "FB";

/*XXX Found a bug at startup. Code assumes that canvas layout 
is in one of three states. then system fails. he bug was that the 
canvasLayout was being set to 'default' which is not a valid state. 
So no is check that if default is sent in then set the layout to FB mode.
*/
/* TODO: Make the default check below actually check that the item 
is in one of the three valid states. If not then set to FB, otherwise set to one of
the three valid states
*/
function setCanvasLayout(value){
    if(value == 'default'){
        canvaslayout = 'FB'
    }
    else {
        canvaslayout = value;
    }
}

function getCanvasLayout(){
    return canvaslayout;
}

/************************************************/

/*************************************************
BOM Layout
*************************************************/
var bomlayout = "default";

function setBomLayout(value){
    bomlayout = value;
}

function getBomLayout(){
    return bomlayout;
}

/************************************************/

/*************************************************
BOM Sort Function
*************************************************/
var bomSortFunction = null;

function setBomSortFunction(value){
    bomSortFunction = value;
}

function getBomSortFunction(){
    return bomSortFunction;
}

/************************************************/

/*************************************************
Current Sort Column
*************************************************/
var currentSortColumn = null;

function setCurrentSortColumn(value){
    currentSortColumn = value;
}

function getCurrentSortColumn(){
    return currentSortColumn;
}

/************************************************/

/*************************************************
Current Sort Order
*************************************************/
var currentSortOrder = null;

function setCurrentSortOrder(value){
    currentSortOrder = value;
}

function getCurrentSortOrder(){
    return currentSortOrder;
}

/************************************************/

/*************************************************
Current Highlighted Row ID
*************************************************/
var currentHighlightedRowId;

function setCurrentHighlightedRowId(value){
    currentHighlightedRowId = value;
}

function getCurrentHighlightedRowId(){
    return currentHighlightedRowId;
}

/************************************************/

/*************************************************
Highlight Handlers
*************************************************/
var highlightHandlers = [];

function setHighlightHandlers(values){
    highlightHandlers = values;
}

function getHighlightHandlers(){
    return highlightHandlers;
}

function pushHighlightHandlers(value){
    highlightHandlers.push(value);
}

/************************************************/

/*************************************************
Checkboxes
*************************************************/
var checkboxes = [];

function setCheckboxes(values){
    checkboxes = values;
}

function getCheckboxes(){
    return checkboxes;
}

/************************************************/

/*************************************************
BOM Checkboxes
*************************************************/
var bomCheckboxes = "";

function setBomCheckboxes(values){
    bomCheckboxes = values;
}

function getBomCheckboxes(){
    return bomCheckboxes;
}
/************************************************/

/*************************************************
Remove BOM Entries
*************************************************/
var removeBOMEntries = "";

function setRemoveBOMEntries(values){
    removeBOMEntries = values;
}

function getRemoveBOMEntries(){
    return removeBOMEntries;
}
/************************************************/


/*************************************************
Remove BOM Entries
*************************************************/
var additionalAttributes = "";

function setAdditionalAttributes(values){
    additionalAttributes = values;
}

function getAdditionalAttributes(){
    return additionalAttributes;
}
/************************************************/


/*************************************************
Highlight Pin 1
*************************************************/
var highlightpin1 = false;

function setHighlightPin1(value) {
  writeStorage("highlightpin1", value);
  highlightpin1 = value;
}

function getHighlightPin1(){
    return highlightpin1;
}

/************************************************/

/*************************************************
Last Clicked Ref
*************************************************/
var lastClickedRef;

function setLastClickedRef(value) {
    lastClickedRef = value;
}

function getLastClickedRef() {
  return lastClickedRef;
}

/************************************************/


/*************************************************
Combine Values
*************************************************/
var combineValues = false;

function setCombineValues(value) {
  writeStorage("combineValues", value);
  combineValues = value;
}

function getCombineValues(){
    return combineValues;
}
/************************************************/


module.exports = {
  initStorage                , readStorage                , writeStorage       ,
  setHighlightedRefs         , getHighlightedRefs         ,
  setRedrawOnDrag            , getRedrawOnDrag            ,
  setBomSplit                , getBomSplit                , destroyBomSplit    ,
  setCanvasSplit             , getCanvasSplit             , destroyCanvasSplit , collapseCanvasSplit , setSizesCanvasSplit,
  setCanvasLayout            , getCanvasLayout            ,
  setBomLayout               , getBomLayout               ,
  setBomSortFunction         , getBomSortFunction         ,
  setCurrentSortColumn       , getCurrentSortColumn       ,
  setCurrentSortOrder        , getCurrentSortOrder        ,
  setCurrentHighlightedRowId , getCurrentHighlightedRowId ,
  setHighlightHandlers       , getHighlightHandlers       , pushHighlightHandlers ,
  setCheckboxes              , getCheckboxes              ,
  setBomCheckboxes           , getBomCheckboxes           ,
  setRemoveBOMEntries        , getRemoveBOMEntries        ,
  setAdditionalAttributes    , getAdditionalAttributes    ,
  setHighlightPin1           , getHighlightPin1           ,
  setLastClickedRef          , getLastClickedRef          ,
  setCombineValues           , getCombineValues

};
},{}],2:[function(require,module,exports){

var globalData = require('./global.js')
var render     = require('./render.js')
var ibom       = require('./ibom.js')

const boardRotation = document.getElementById('boardRotation');
boardRotation.oninput=function()
{
  render.setBoardRotation(boardRotation.value);
}

const darkModeBox = document.getElementById('darkmodeCheckbox');
darkModeBox.onchange = function () {
  ibom.setDarkMode(darkModeBox.checked)
}

const silkscreenCheckbox = document.getElementById('silkscreenCheckbox');
silkscreenCheckbox.checked=function(){
  ibom.silkscreenVisible(silkscreenCheckbox.checked)
}
silkscreenCheckbox.onchange=function(){
  ibom.silkscreenVisible(silkscreenCheckbox.checked)
}

const highlightpin1Checkbox =document.getElementById('highlightpin1Checkbox');
highlightpin1Checkbox.onchange=function(){
  globalData.setHighlightPin1(highlightpin1Checkbox.checked);
  render.redrawCanvas(allcanvas.front);
  render.redrawCanvas(allcanvas.back);
}

const dragCheckbox = document.getElementById('dragCheckbox');
dragCheckbox.checked=function(){
  globalData.setRedrawOnDrag(dragCheckbox.checked)
}
dragCheckbox.onchange=function(){
  globalData.setRedrawOnDrag(dragCheckbox.checked)
}


const combineValues = document.getElementById('combineValues');
combineValues.onchange=function(){
  globalData.setCombineValues(combineValues.checked);
  ibom.populateBomTable();
}

const filter = document.getElementById('filter');
filter.oninput=function(){
  ibom.setFilter(filter.value)
}

const bomCheckboxes = document.getElementById('bomCheckboxes');
bomCheckboxes.oninput=function(){
  ibom.setBomCheckboxes(bomCheckboxes.value);
}

const removeBOMEntries = document.getElementById('removeBOMEntries');
removeBOMEntries.oninput=function(){
  ibom.setRemoveBOMEntries(removeBOMEntries.value);
}

const additionalAttributes = document.getElementById('additionalAttributes');
additionalAttributes.oninput=function(){
  ibom.setAdditionalAttributes(additionalAttributes.value);
}

const fl_btn = document.getElementById('fl-btn');
fl_btn.onclick=function(){
  ibom.changeCanvasLayout('F');
}

const fb_btn = document.getElementById('fb-btn');
fb_btn.onclick=function(){
  ibom.changeCanvasLayout('FB');
}


const bl_btn = document.getElementById('bl-btn');
bl_btn.onclick=function(){
  ibom.changeCanvasLayout('B');
}

const bom_btn = document.getElementById('bom-btn');
bom_btn.onclick=function(){
  ibom.changeBomLayout('BOM')
}

const lr_btn = document.getElementById('lr-btn');
lr_btn.onclick=function(){
  ibom.changeBomLayout('LR')
}

const tb_btn = document.getElementById('tb-btn');
tb_btn.onclick=function(){
  ibom.changeBomLayout('TB')
}

},{"./global.js":1,"./ibom.js":3,"./render.js":6}],3:[function(require,module,exports){
/* DOM manipulation and misc code */


var Split = require('../vender/split.js')
var globalData = require('./global.js')
var render = require('./render.js')
var pcb    = require('./pcb.js')


//TODO:  GLOBAL VARIABLE REFACTOR
var filter = "";
function getFilter(input) {
  return filter;
}

function setFilter(input) {
  filter = input.toLowerCase();
  populateBomTable();
}

function dbg(html) {
  dbgdiv.innerHTML = html;
}

function setDarkMode(value) {
  if (value) {
    topmostdiv.classList.add("dark");
  } else {
    topmostdiv.classList.remove("dark");
  }
  globalData.writeStorage("darkmode", value);
  render.redrawCanvas(allcanvas.front);
  render.redrawCanvas(allcanvas.back);
}

function getStoredCheckboxRefs(checkbox) {
  var existingRefs = globalData.readStorage("checkbox_" + checkbox);
  if (!existingRefs) {
    return new Set();
  } else {
    return new Set(existingRefs.split(","));
  }
}

function getCheckboxState(checkbox, references) {
  var storedRefsSet = getStoredCheckboxRefs(checkbox);
  var currentRefsSet = new Set(references);
  // Get difference of current - stored
  var difference = new Set(currentRefsSet);
  for (ref of storedRefsSet) {
    difference.delete(ref);
  }
  if (difference.size == 0) {
    // All the current refs are stored
    return "checked";
  } else if (difference.size == currentRefsSet.size) {
    // None of the current refs are stored
    return "unchecked";
  } else {
    // Some of the refs are stored
    return "indeterminate";
  }
}

function setBomCheckboxState(checkbox, element, references) {
  var state = getCheckboxState(checkbox, references);
  element.checked = (state == "checked");
  element.indeterminate = (state == "indeterminate");
}

function createCheckboxChangeHandler(checkbox, references) {
  return function() {
    refsSet = getStoredCheckboxRefs(checkbox);
    if (this.checked) {
      // checkbox ticked
      for (var ref of references) {
        refsSet.add(ref);
      }
    } else {
      // checkbox unticked
      for (var ref of references) {
        refsSet.delete(ref);
      }
    }
    globalData.writeStorage("checkbox_" + checkbox, [...refsSet].join(","));
  }
}

function createRowHighlightHandler(rowid, refs) {
  return function() {
    if (globalData.getCurrentHighlightedRowId()) {
      if (globalData.getCurrentHighlightedRowId() == rowid) {
        return;
      }
      document.getElementById(globalData.getCurrentHighlightedRowId()).classList.remove("highlighted");
    }
    document.getElementById(rowid).classList.add("highlighted");
    globalData.setCurrentHighlightedRowId(rowid);
    globalData.setHighlightedRefs(refs);
    render.drawHighlights();
  }
}

function entryMatches(part) {
  // check refs
  if (part.reference.toLowerCase().indexOf(getFilter()) >= 0) {
      return true;
    }
  // check value
  if (part.value.toLowerCase().indexOf(getFilter())>= 0) {
    return true;
  }
  // check footprint
  if (part.package.toLowerCase().indexOf(getFilter())>= 0) {
    return true;
  }

  // Check the displayed attributes
  var additionalAttributes = globalData.getAdditionalAttributes().split(',');
  additionalAttributes     = additionalAttributes.filter(function(e){return e});
  for (var x of additionalAttributes) {
      // remove beginning and trailing whitespace
      x = x.trim()
      if (part.attributes.has(x)) {
        if(part.attributes.get(x).indexOf(getFilter()) >= 0){
          return true;
        }
      }
    }

  return false;
}


function highlightFilter(s) {
  if (!getFilter()) {
    return s;
  }
  var parts = s.toLowerCase().split(getFilter());
  if (parts.length == 1) {
    return s;
  }
  var r = "";
  var pos = 0;
  for (var i in parts) {
    if (i > 0) {
      r += '<mark class="highlight">' +
        s.substring(pos, pos + getFilter().length) +
        '</mark>';
      pos += getFilter().length;
    }
    r += s.substring(pos, pos + parts[i].length);
    pos += parts[i].length;
  }
  return r;
}

function checkboxSetUnsetAllHandler(checkboxname) {
  return function() {
    var checkboxnum = 0;
    while (checkboxnum < globalData.getCheckboxes().length &&
      globalData.getCheckboxes()[checkboxnum].toLowerCase() != checkboxname.toLowerCase()) {
      checkboxnum++;
    }
    if (checkboxnum >= globalData.getCheckboxes().length) {
      return;
    }
    var allset = true;
    var checkbox;
    var row;
    for (row of bombody.childNodes) {
      checkbox = row.childNodes[checkboxnum + 1].childNodes[0];
      if (!checkbox.checked || checkbox.indeterminate) {
        allset = false;
        break;
      }
    }
    for (row of bombody.childNodes) {
      checkbox = row.childNodes[checkboxnum + 1].childNodes[0];
      checkbox.checked = !allset;
      checkbox.indeterminate = false;
      checkbox.onchange();
    }
  }
}

function createColumnHeader(name, cls, comparator) {
  var th = document.createElement("TH");
  th.innerHTML = name;
  th.classList.add(cls);
  th.style.cursor = "pointer";
  var span = document.createElement("SPAN");
  span.classList.add("sortmark");
  span.classList.add("none");
  th.appendChild(span);
  th.onclick = function() {
    if (globalData.getCurrentSortColumn() && this !== globalData.getCurrentSortColumn()) {
      // Currently sorted by another column
      globalData.getCurrentSortColumn().childNodes[1].classList.remove(globalData.getCurrentSortOrder());
      globalData.getCurrentSortColumn().childNodes[1].classList.add("none");
      globalData.setCurrentSortColumn(null);
      globalData.setCurrentSortOrder(null);
    }
    if (globalData.getCurrentSortColumn() && this === globalData.getCurrentSortColumn()) {
      // Already sorted by this column
      if (globalData.getCurrentSortOrder() == "asc") {
        // Sort by this column, descending order
        globalData.setBomSortFunction(function(a, b) {
          return -comparator(a, b);
        });
        globalData.getCurrentSortColumn().childNodes[1].classList.remove("asc");
        globalData.getCurrentSortColumn().childNodes[1].classList.add("desc");
        globalData.setCurrentSortOrder("desc");
      } else {
        // Unsort
        globalData.setBomSortFunction(null);
        globalData.getCurrentSortColumn().childNodes[1].classList.remove("desc");
        globalData.getCurrentSortColumn().childNodes[1].classList.add("none");
        globalData.setCurrentSortColumn(null);
        globalData.setCurrentSortOrder(null);
      }
    } else {
      // Sort by this column, ascending order
      globalData.setBomSortFunction(comparator);
      globalData.setCurrentSortColumn(this);
      globalData.getCurrentSortColumn().childNodes[1].classList.remove("none");
      globalData.getCurrentSortColumn().childNodes[1].classList.add("asc");
      globalData.setCurrentSortOrder("asc");
    }
    populateBomBody();
  }
  return th;
}

function fancyDblClickHandler(el, onsingle, ondouble) {
  return function() {
    if (el.getAttribute("data-dblclick") == null) {
      el.setAttribute("data-dblclick", 1);
      setTimeout(function() {
        if (el.getAttribute("data-dblclick") == 1) {
          onsingle();
        }
        el.removeAttribute("data-dblclick");
      }, 200);
    } else {
      el.removeAttribute("data-dblclick");
      ondouble();
    }
  }
}

function populateBomHeader() {
  while (bomhead.firstChild) {
    bomhead.removeChild(bomhead.firstChild);
  }
  var tr = document.createElement("TR");
  var th = document.createElement("TH");
  th.classList.add("numCol");
  tr.appendChild(th);
  globalData.setCheckboxes(globalData.getBomCheckboxes().split(",").filter((e) => e));
  //XXX: There is something weird with this. The behavior is to sort the buttons but 
  // in the gui it actis funny
  var checkboxCompareClosure = function(checkbox) {
    return (a, b) => {
      var stateA = getCheckboxState(checkbox, a[3]);
      var stateB = getCheckboxState(checkbox, b[3]);
      if (stateA > stateB) return -1;
      if (stateA < stateB) return 1;
      return 0;
    }
  }

  for (var checkbox of globalData.getCheckboxes()) {
    th = createColumnHeader(
      checkbox, checkbox, checkboxCompareClosure(checkbox));
    th.onclick = fancyDblClickHandler(
      th, th.onclick.bind(th), checkboxSetUnsetAllHandler(checkbox));
    tr.appendChild(th);
  }

  tr.appendChild(createColumnHeader("References", "References", (partA, partB) => {
      if (partA.reference != partB.reference) return partA.reference > partB.reference ? 1 : -1;
      else return 0;
  }));

  tr.appendChild(createColumnHeader("Value", "Value", (partA, partB) => {
    if (partA.value != partB.value) return partA.value > partB.value ? 1 : -1;
    else return 0;
  }));

  tr.appendChild(createColumnHeader("Footprint", "Footprint", (partA, partB) => {
    if (partA.package != partB.package) return partA.package > partB.package ? 1 : -1;
    else return 0;
  }));

  var additionalAttributes = globalData.getAdditionalAttributes().split(',');
  // Remove null, "", undefined, and 0 values
  additionalAttributes    =additionalAttributes.filter(function(e){return e});
  for (var x of additionalAttributes) {
      // remove beginning and trailing whitespace
      x = x.trim()
      if (x) {
        tr.appendChild(createColumnHeader(x, "Attributes", (partA, partB) => {
          if (partA.attributes.get(x) != partB.attributes.get(x)) return  partA.attributes.get(x) > partB.attributes.get(x) ? 1 : -1;
          else return 0;
        }));
      }
    }

  if(globalData.getCombineValues())
  {
    //XXX: This comparison function is using positive and negative implicit
    tr.appendChild(createColumnHeader("Quantity", "Quantity", (partA, partB) => {
      return partA.quantity - partB.quantity;
    }));
  }

  bomhead.appendChild(tr);

}

////////////////////////////////////////////////////////////////////////////////
// Filter functions are defined here. These let the application filter 
// elements out of the complete bom. 
//
// The filtering function should return true if the part should be filtered out
// otherwise it returns false
////////////////////////////////////////////////////////////////////////////////
function GetBOMForSideOfBoard(location){
  var result = pcb.GetBOM();
    switch (location) {
    case 'F':
      result = pcb.filterBOMTable(result, filterBOM_Front);
      break;
    case 'B':
      result = pcb.filterBOMTable(result, filterBOM_Back);
      break;
    default:
      break;
  }
  return result;
}

function filterBOM_Front(part){
  var result = true;
  if(part.location == "F"){
    result = false;
  }
  return result;
}

function filterBOM_Back(part){
  var result = true;
  if(part.location == "B"){
    result = false;
  }
  return result;
}

function filterBOM_ByAttribute(part){
  var result = false;
  var splitFilterString = globalData.getRemoveBOMEntries().split(',');
  // Remove null, "", undefined, and 0 values
  splitFilterString    = splitFilterString.filter(function(e){return e});

  if(splitFilterString.length > 0 )
  {
    for(var i of splitFilterString){
      // removing beginning and trailing whitespace
      i = i.trim()
      if(part.attributes.has(i)){
        // Id the value is an empty string then dont filter out the entry. 
        // if the value is anything then filter out the bom entry
        if(part.attributes.get(i) != "")
        {
          result = true;
        }
      }
    }
  }

  return result;
}
////////////////////////////////////////////////////////////////////////////////

function GenerateBOMTable()
{
  // Get bom table with elements for the side of board the user has selected
  var bomtableTemp = GetBOMForSideOfBoard(globalData.getCanvasLayout());

  // Apply attribute filter to board
  bomtableTemp = pcb.filterBOMTable(bomtableTemp, filterBOM_ByAttribute);

  // If the parts are displayed one per line (not combined values), then the the bom table needs to be flattened. 
  // By default the data in the json file is combined
  bomtable = globalData.getCombineValues() ? pcb.GetBOMCombinedValues(bomtableTemp) : bomtableTemp;

  return bomtable;
}

//TODO: This should be rewritten to interact with json using the tags instead of 
//      having all of the elements hardcoded.
function populateBomBody() {
  while (bom.firstChild) {
    bom.removeChild(bom.firstChild);
  }
  globalData.setHighlightHandlers([]);
  globalData.setCurrentHighlightedRowId(null);
  var first = true;

  bomtable = GenerateBOMTable();

  if (globalData.getBomSortFunction()) {
    bomtable = bomtable.slice().sort(globalData.getBomSortFunction());
  }
  for (var i in bomtable) {
    var bomentry = bomtable[i];
    var references = bomentry.reference;

    if (getFilter() != ""){
      if(!entryMatches(bomentry)){
        continue;
      }
    }


    var tr = document.createElement("TR");
    var td = document.createElement("TD");
    var rownum = +i + 1;
    tr.id = "bomrow" + rownum;
    td.textContent = rownum;
    tr.appendChild(td);

    // Checkboxes
    for (var checkbox of globalData.getCheckboxes()) {
      if (checkbox) {
        td = document.createElement("TD");
        var input = document.createElement("input");
        input.type = "checkbox";
        input.onchange = createCheckboxChangeHandler(checkbox, references);
        setBomCheckboxState(checkbox, input, references);
        td.appendChild(input);
        tr.appendChild(td);
      }
    }

    //INFO: The lines below add the control the columns on the bom table
    // References
    td = document.createElement("TD");
    td.innerHTML = highlightFilter(references);
    tr.appendChild(td);
    // Value
    td = document.createElement("TD");
    td.innerHTML = highlightFilter(bomentry.value);
    tr.appendChild(td);
    // Footprint
    td = document.createElement("TD");
    td.innerHTML = highlightFilter(bomentry.package);
    tr.appendChild(td);
    
    // Attributes
    var additionalAttributes = globalData.getAdditionalAttributes().split(',');
    for (var x of additionalAttributes) {
      x = x.trim()
      if (x) {
        td = document.createElement("TD");
        td.innerHTML = highlightFilter(pcb.getAttributeValue(bomentry, x.toLowerCase()));
        tr.appendChild(td);
      }
    }

    if(globalData.getCombineValues())
    {

      td = document.createElement("TD");
      td.textContent = bomentry.quantity;
      tr.appendChild(td);
    }
    bom.appendChild(tr);


    bom.appendChild(tr);
    var handler = createRowHighlightHandler(tr.id, references);
    tr.onmousemove = handler;
    globalData.pushHighlightHandlers({
      id: tr.id,
      handler: handler,
      refs: references
    });
    if (getFilter() && first) {
      handler();
      first = false;
    }
  }
}

function smoothScrollToRow(rowid) {
  document.getElementById(rowid).scrollIntoView({
    behavior: "smooth",
    block: "center",
    inline: "nearest"
  });
}

function highlightPreviousRow() {
  if (!globalData.getCurrentHighlightedRowId()) {
    globalData.getHighlightHandlers()[globalData.getHighlightHandlers().length - 1].handler();
  } else {
    if (globalData.getHighlightHandlers().length > 1 &&
      globalData.getHighlightHandlers()[0].id == globalData.getCurrentHighlightedRowId()) {
      globalData.getHighlightHandlers()[globalData.getHighlightHandlers().length - 1].handler();
    } else {
      for (var i = 0; i < globalData.getHighlightHandlers().length - 1; i++) {
        if (globalData.getHighlightHandlers()[i + 1].id == globalData.getCurrentHighlightedRowId()) {
          globalData.getHighlightHandlers()[i].handler();
          break;
        }
      }
    }
  }
  smoothScrollToRow(globalData.getCurrentHighlightedRowId());
}

function highlightNextRow() {
  if (!globalData.getCurrentHighlightedRowId()) {
    globalData.getHighlightHandlers()[0].handler();
  } else {
    if (globalData.getHighlightHandlers().length > 1 &&
      globalData.getHighlightHandlers()[globalData.getHighlightHandlers().length - 1].id == globalData.getCurrentHighlightedRowId()) {
      globalData.getHighlightHandlers()[0].handler();
    } else {
      for (var i = 1; i < globalData.getHighlightHandlers().length; i++) {
        if (globalData.getHighlightHandlers()[i - 1].id == globalData.getCurrentHighlightedRowId()) {
          globalData.getHighlightHandlers()[i].handler();
          break;
        }
      }
    }
  }
  smoothScrollToRow(globalData.getCurrentHighlightedRowId());
}

function populateBomTable() {
  populateBomHeader();
  populateBomBody();
}

function modulesClicked(references) {
  var lastClickedIndex = references.indexOf(globalData.getLastClickedRef());
  var ref = references[(lastClickedIndex + 1) % references.length];
  for (var handler of globalData.getHighlightHandlers()) {
    if (handler.refs.indexOf(ref) >= 0) {
      globalData.setLastClickedRef(ref);
      handler.handler();
      smoothScrollToRow(globalData.getCurrentHighlightedRowId());
      break;
    }
  }
}

function silkscreenVisible(visible) {
  if (visible) {
    allcanvas.front.silk.style.display = "";
    allcanvas.back.silk.style.display = "";
    globalData.writeStorage("silkscreenVisible", true);
  } else {
    allcanvas.front.silk.style.display = "none";
    allcanvas.back.silk.style.display = "none";
    globalData.writeStorage("silkscreenVisible", false);
  }
}

function changeCanvasLayout(layout) {
  document.getElementById("fl-btn").classList.remove("depressed");
  document.getElementById("fb-btn").classList.remove("depressed");
  document.getElementById("bl-btn").classList.remove("depressed");
  switch (layout) {
    case 'F':
      document.getElementById("fl-btn").classList.add("depressed");
      if (globalData.getBomLayout() != "BOM") {
        globalData.collapseCanvasSplit(1);
      }
      break;
    case 'B':
      document.getElementById("bl-btn").classList.add("depressed");
      if (globalData.getBomLayout() != "BOM") {
        globalData.collapseCanvasSplit(0);
      }
      break;
    default:
      document.getElementById("fb-btn").classList.add("depressed");
      if (globalData.getBomLayout() != "BOM") {
        globalData.setSizesCanvasSplit([50, 50]);
      }
  }
  globalData.setCanvasLayout(layout);
  globalData.writeStorage("canvaslayout", layout);
  render.resizeAll();
  populateBomTable();
}

function populateMetadata() {
  var metadata  = pcb.GetMetadata();
  
  if(metadata.revision == "")
  {
    document.getElementById("title").innerHTML    = ""
    document.getElementById("revision").innerHTML = metadata.title;
  }
  else{
    document.getElementById("title").innerHTML    = metadata.title;
    document.getElementById("revision").innerHTML = "Rev: " + metadata.revision;
  }

  
  document.getElementById("company").innerHTML  = metadata.company;
  document.getElementById("filedate").innerHTML = metadata.date;
  if (metadata.title != "") {
    document.title = metadata.title + " BOM";
  }
}

function changeBomLayout(layout) {
  document.getElementById("bom-btn").classList.remove("depressed");
  document.getElementById("lr-btn").classList.remove("depressed");
  document.getElementById("tb-btn").classList.remove("depressed");
  switch (layout) {
    case 'BOM':
      document.getElementById("bom-btn").classList.add("depressed");
      if (globalData.getBomSplit()) {
        globalData.destroyBomSplit();
        globalData.setBomSplit(null);
        globalData.destroyCanvasSplit();
        globalData.setCanvasSplit(null);
      }
      document.getElementById("frontcanvas").style.display = "none";
      document.getElementById("backcanvas").style.display = "none";
      document.getElementById("bot").style.height = "";
      break;
    case 'TB':
      document.getElementById("tb-btn").classList.add("depressed");
      document.getElementById("frontcanvas").style.display = "";
      document.getElementById("backcanvas").style.display = "";
      document.getElementById("bot").style.height = "calc(100% - 80px)";
      document.getElementById("bomdiv").classList.remove("split-horizontal");
      document.getElementById("canvasdiv").classList.remove("split-horizontal");
      document.getElementById("frontcanvas").classList.add("split-horizontal");
      document.getElementById("backcanvas").classList.add("split-horizontal");
      if (globalData.getBomSplit()) {
        globalData.destroyBomSplit();
        globalData.setBomSplit(null);
        globalData.destroyCanvasSplit();
        globalData.setCanvasSplit(null);
      }
      globalData.setBomSplit(Split(['#bomdiv', '#canvasdiv'], {
        sizes: [50, 50],
        onDragEnd: render.resizeAll,
        direction: "vertical",
        gutterSize: 5
      }));
      globalData.setCanvasSplit(Split(['#frontcanvas', '#backcanvas'], {
        sizes: [50, 50],
        gutterSize: 5,
        onDragEnd: render.resizeAll
      }));
      break;
    case 'LR':
      document.getElementById("lr-btn").classList.add("depressed");
      document.getElementById("frontcanvas").style.display = "";
      document.getElementById("backcanvas").style.display = "";
      document.getElementById("bot").style.height = "calc(100% - 80px)";
      document.getElementById("bomdiv").classList.add("split-horizontal");
      document.getElementById("canvasdiv").classList.add("split-horizontal");
      document.getElementById("frontcanvas").classList.remove("split-horizontal");
      document.getElementById("backcanvas").classList.remove("split-horizontal");
      if (globalData.getBomSplit()) {
        globalData.destroyBomSplit();
        globalData.setBomSplit(null);
        globalData.destroyCanvasSplit();
        globalData.setCanvasSplit(null);
      }
      globalData.setBomSplit(Split(['#bomdiv', '#canvasdiv'], {
        sizes: [50, 50],
        onDragEnd: render.resizeAll,
        gutterSize: 5
      }));
      globalData.setCanvasSplit(Split(['#frontcanvas', '#backcanvas'], {
        sizes: [50, 50],
        gutterSize: 5,
        direction: "vertical",
        onDragEnd: render.resizeAll
      }));
  }
  globalData.setBomLayout(layout);
  globalData.writeStorage("bomlayout", layout);
  changeCanvasLayout(globalData.getCanvasLayout());
}

function focusInputField(input) {
  input.scrollIntoView(false);
  input.focus();
  input.select();
}

function focusFilterField() {
  focusInputField(document.getElementById("filter"));
}

function toggleBomCheckbox(bomrowid, checkboxnum) {
  if (!bomrowid || checkboxnum > globalData.getCheckboxes().length) {
    return;
  }
  var bomrow = document.getElementById(bomrowid);
  var checkbox = bomrow.childNodes[checkboxnum].childNodes[0];
  checkbox.checked = !checkbox.checked;
  checkbox.indeterminate = false;
  checkbox.onchange();
}

function checkBomCheckbox(bomrowid, checkboxname) {
  var checkboxnum = 0;
  while (checkboxnum < globalData.getCheckboxes().length &&
    globalData.getCheckboxes()[checkboxnum].toLowerCase() != checkboxname.toLowerCase()) {
    checkboxnum++;
  }
  if (!bomrowid || checkboxnum >= globalData.getCheckboxes().length) {
    return;
  }
  var bomrow = document.getElementById(bomrowid);
  var checkbox = bomrow.childNodes[checkboxnum + 1].childNodes[0];
  checkbox.checked = true;
  checkbox.indeterminate = false;
  checkbox.onchange();
}


function removeGutterNode(node) {
  for (var i = 0; i < node.childNodes.length; i++) {
    if (node.childNodes[i].classList &&
      node.childNodes[i].classList.contains("gutter")) {
      node.removeChild(node.childNodes[i]);
      break;
    }
  }
}

function cleanGutters() {
  removeGutterNode(document.getElementById("bot"));
  removeGutterNode(document.getElementById("canvasdiv"));
}

function setBomCheckboxes(value) {
  globalData.setBomCheckboxes(value);
  globalData.writeStorage("bomCheckboxes", value);
  populateBomTable();
}

function setRemoveBOMEntries(value) {
  globalData.setRemoveBOMEntries(value);
  globalData.writeStorage("removeBOMEntries", value);
  populateBomTable();
}

function setAdditionalAttributes(value) {
  globalData.setAdditionalAttributes(value);
  globalData.writeStorage("additionalAttributes", value);
  populateBomTable();
}

// XXX: None of this seems to be working. 
document.onkeydown = function(e) {
  switch (e.key) {
    case "n":
      if (document.activeElement.type == "text") {
        return;
      }
      if (globalData.getCurrentHighlightedRowId() !== null) {
        checkBomCheckbox(globalData.getCurrentHighlightedRowId(), "placed");
        highlightNextRow();
        e.preventDefault();
      }
      break;
    case "ArrowUp":
      highlightPreviousRow();
      e.preventDefault();
      break;
    case "ArrowDown":
      highlightNextRow();
      e.preventDefault();
      break;
    default:
      break;
  }
  if (e.altKey) {
    switch (e.key) {
      case "f":
        focusFilterField();
        e.preventDefault();
        break;
      case "z":
        changeBomLayout("BOM");
        e.preventDefault();
        break;
      case "x":
        changeBomLayout("LR");
        e.preventDefault();
        break;
      case "c":
        changeBomLayout("TB");
        e.preventDefault();
        break;
      case "v":
        changeCanvasLayout("F");
        e.preventDefault();
        break;
      case "b":
        changeCanvasLayout("FB");
        e.preventDefault();
        break;
      case "n":
        changeCanvasLayout("B");
        e.preventDefault();
        break;
      default:
        break;
    }
    if (e.key >= '1' && e.key <= '9') {
      toggleBomCheckbox(currentHighlightedRowId, parseInt(e.key));
    }
  }
}

//XXX: I would like this to be in the html functions js file. But this function needs to be 
//     placed here, otherwise the application rendering becomes very very weird.
window.onload = function(e) {
  
  // This function makes so that the user data for the pcb is converted to our internal structure
  pcb.OpenPcbData(pcbdata)
  

  globalData.initStorage();
  cleanGutters();
  render.initRender();
  dbgdiv = document.getElementById("dbg");
  bom = document.getElementById("bombody");
  bomhead = document.getElementById("bomhead");
  globalData.setBomLayout(globalData.readStorage("bomlayout"));
  if (!globalData.getBomLayout()) {
    globalData.setBomLayout("LR");
  }
  globalData.setCanvasLayout(globalData.readStorage("canvaslayout"));
  if (!globalData.getCanvasLayout()) {
    globalData.setCanvasLayout("FB");
  }

  populateMetadata();
  globalData.setBomCheckboxes(globalData.readStorage("bomCheckboxes"));
  if (globalData.getBomCheckboxes() === null) {
    globalData.setBomCheckboxes("Placed");
  }
  globalData.setRemoveBOMEntries(globalData.readStorage("removeBOMEntries"));
  if (globalData.getRemoveBOMEntries() === null) {
    globalData.setRemoveBOMEntries("");
  }
  globalData.setAdditionalAttributes(globalData.readStorage("additionalAttributes"));
  if (globalData.getAdditionalAttributes() === null) {
    globalData.setAdditionalAttributes("");
  }
  document.getElementById("bomCheckboxes").value = globalData.getBomCheckboxes();
  if (globalData.readStorage("silkscreenVisible") === "false") {
    document.getElementById("silkscreenCheckbox").checked = false;
    silkscreenVisible(false);
  }
  if (globalData.readStorage("redrawOnDrag") === "false") {
    document.getElementById("dragCheckbox").checked = false;
    globalData.setRedrawOnDrag(false);
  }
  if (globalData.readStorage("darkmode") === "true") {
    document.getElementById("darkmodeCheckbox").checked = true;
    setDarkMode(true);
  }
  if (globalData.readStorage("highlightpin1") === "true") {
    document.getElementById("highlightpin1Checkbox").checked = true;
    globalData.setHighlightPin1(true);
    render.redrawCanvas(allcanvas.front);
    render.redrawCanvas(allcanvas.back);
  }
  // If this is true then combine parts and display quantity
  if (globalData.readStorage("combineValues") === "true") {
    document.getElementById("combineValues").checked = true;
    globalData.setCombineValues(true);
  }
  boardRotation = globalData.readStorage("boardRotation");
  if (boardRotation === null) {
    boardRotation = 0;
  } else {
    boardRotation = parseInt(boardRotation);
  }
  document.getElementById("boardRotation").value = boardRotation / 5;
  document.getElementById("rotationDegree").textContent = boardRotation;
  // Triggers render
  changeBomLayout(globalData.getBomLayout());
}

window.onresize = render.resizeAll;
window.matchMedia("print").addListener(render.resizeAll);

module.exports = {
  setDarkMode        , silkscreenVisible      , changeBomLayout, changeCanvasLayout,
  setBomCheckboxes   , populateBomTable       , setFilter      , getFilter         ,
  setRemoveBOMEntries, setAdditionalAttributes
}

},{"../vender/split.js":7,"./global.js":1,"./pcb.js":4,"./render.js":6}],4:[function(require,module,exports){
/*
    This file contains all of the definitions for working with pcbdata.json. 
    This file declares all of the access functions and interfaces for converting 
    the json file into an internal data structure. 
*/

/***************************************************************************************************
                                         PCB Part Interfaces
**************************************************************************************************/
// Read the ecad property. This property lets the application know what 
// ecad software generated the json file. 
function GetCADType(pcbdataStructure)
{
    if(pcbdataStructure.hasOwnProperty("ecad")){
        return pcbdataStructure.ecad;
    }
}

// This will hold the part objects. There is one entry per part
// Format of a part is as follows
// [VALUE,PACKAGE,REFRENECE DESIGNATOR, ,LOCATION, ATTRIBUTE],
// where ATTRIBUTE is a dict of ATTRIBUTE NAME : ATTRIBUTE VALUE
var BOM = [];

// Constructor for creating a part.
function Part(value, package, reference, location, attributes) {
    this.quantity   = 1;
    this.value      = value;
    this.package    = package;
    this.reference  = reference;
    this.location   = location;
    this.attributes = attributes;
}

function CopyPart(inputPart){
  // XXX: This is not performing a deep copy, attributes is a map and this is being copied by 
  //      reference which is not quite what we want here. It should be a deep copy so once called
  //      this will result in a completely new object that will not reference one another
  return new Part(inputPart.value, inputPart.package, inputPart.reference, inputPart.location, inputPart.attributes);
}

//TODO: There should be steps here for validating the data and putting it into a 
//      format that is valid for our application
function CreateBOM(pcbdataStructure){
    // For every part in the input file, convert it to our internal 
    // representation data structure.
    for(var part of pcbdataStructure.bom.both){
        // extract the part data. This is here so I can iterate the design 
        // when I make changes to the underlying json file.
        var value     = part[1];
        var package   = part[2];
        var reference = part[3][0];
        var location  = part[6];

        // AttributeName and AttributeValue are two strings that are deliminated by ';'. 
        // Split the strings by ';' and then zip them together
        var attributeNames = part[4].split(';');
        var attributeValues = part[5].split(';');

        //XXX: ASSUMTION that attributeNames is the same length as attributeValues
        attributes = new Map(); // Create a empty dictionary
        for(var i in attributeNames){
            attributes.set(attributeNames[i].toLowerCase(),attributeValues[i].toLowerCase());
        }
        // Add the par to the global part array
        BOM.push(new Part(value, package, reference, location, attributes));
    }
}

function GetBOM(){
      return BOM;
}

// TAkes a BOM table and a filter function. The filter 
// function is used onthe provided table to remove 
// any part that satisfy the filter
function filterBOMTable(bomtable, filterFunction){
  var result = [];

  // Makes sure that thE filter function is defined. 
  // if not defined then nothing should be filtered. 
  if(filterFunction != null){
    for(var i in bomtable){
      // If the filter returns false -> do not remove part, it does not need to be filtered
      if(!filterFunction(bomtable[i])){
        result.push(CopyPart(bomtable[i]));
      }
    }
  }
  else{
    result = bomtable;
  }
  return result;
}

// Takes a bom table and combines entries that are the same
function GetBOMCombinedValues(bomtableTemp){
    result = [];

    // TODO: sort bomtableTemp. Assumption here is that the bomtableTemp is presorted

    if(bomtableTemp.length>0){
      // XXX: Assuming that the input json data has bom entries presorted
      // TODO: Start at index 1, and compare the current to the last, this should simplify the logic
      // Need to create a new object by deep copy. this is because objects by default are passed by reference and i dont 
      // want to modify them.
      result.push(CopyPart(bomtableTemp[0]));
      count = 0;
      for (var n = 1; n < bomtableTemp.length;n++)
      {
        if(result[count].value == bomtableTemp[n].value)
        {
          // For parts that are listed as combined, store the references as an array.
          // This is because the logic for highlighting needs to match strings and 
          // If an appended string is used it might not work right
          refString = result[count].reference + "," + bomtableTemp[n].reference;
          result[count].quantity += 1;
          result[count].reference = refString;
        }
        else
        {
          result.push(CopyPart(bomtableTemp[n]));
          count++;
        }
      }
    }
    return result;
}

function getAttributeValue(part, attributeToLookup){
    var attributes = part.attributes;
    var result = "";

    if(attributeToLookup == "name")
    {
      result = part.reference;
    }
    else
    {
      result = (attributes.has(attributeToLookup) ? attributes.get(attributeToLookup) : "");
    }
    // Check that the attribute exists by looking up its name. If it exists
    // the return the value for the attribute, otherwise return an empty string. 
    return result;
}

/***************************************************************************************************
                                         PCB Metadata Interfaces
***************************************************************************************************/
var metadata;
// Constructor for creating a part.
function Metadata(title, revision, company, date) {
    this.title    = title;
    this.revision = revision;
    this.company  = company;
    this.date     = date;
}

function CreateMetadata(pcbdataStructure){
  metadata = new Metadata(pcbdataStructure.metadata.title  , pcbdataStructure.metadata.revision, 
                      pcbdataStructure.metadata.company, pcbdataStructure.metadata.date);
}

function GetMetadata(){
  return metadata;
}



function OpenPcbData(pcbdata){
  CreateBOM(pcbdata);
  CreateMetadata(pcbdata);
}

module.exports = {
  OpenPcbData, GetBOM, getAttributeValue, GetBOMCombinedValues, filterBOMTable, GetMetadata
}
},{}],5:[function(require,module,exports){
var pcbFont = {
    "font_data": {
        " ": {
            "l": [],
            "w": 0.7619047619047619
        },
        "#": {
            "l": [
                [
                    [
                        0.19047619047619047,
                        -0.7142857142857142
                    ],
                    [
                        0.9047619047619047,
                        -0.7142857142857142
                    ]
                ],
                [
                    [
                        0.47619047619047616,
                        -1.1428571428571428
                    ],
                    [
                        0.19047619047619047,
                        0.14285714285714285
                    ]
                ],
                [
                    [
                        0.8095238095238095,
                        -0.2857142857142857
                    ],
                    [
                        0.09523809523809523,
                        -0.2857142857142857
                    ]
                ],
                [
                    [
                        0.5238095238095237,
                        0.14285714285714285
                    ],
                    [
                        0.8095238095238095,
                        -1.1428571428571428
                    ]
                ]
            ],
            "w": 1.0
        },
        "-": {
            "l": [
                [
                    [
                        0.23809523809523814,
                        -0.42857142857142855
                    ],
                    [
                        1.0,
                        -0.42857142857142855
                    ]
                ]
            ],
            "w": 1.2380952380952381
        },
        ".": {
            "l": [
                [
                    [
                        0.23809523809523808,
                        -0.14285714285714285
                    ],
                    [
                        0.2857142857142857,
                        -0.09523809523809523
                    ],
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.19047619047619047,
                        -0.09523809523809523
                    ],
                    [
                        0.23809523809523808,
                        -0.14285714285714285
                    ],
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ]
                ]
            ],
            "w": 0.47619047619047616
        },
        "0": {
            "l": [
                [
                    [
                        0.42857142857142855,
                        -1.0476190476190474
                    ],
                    [
                        0.5238095238095237,
                        -1.0476190476190474
                    ],
                    [
                        0.6190476190476191,
                        -1.0
                    ],
                    [
                        0.6666666666666666,
                        -0.9523809523809523
                    ],
                    [
                        0.7142857142857142,
                        -0.8571428571428571
                    ],
                    [
                        0.7619047619047619,
                        -0.6666666666666666
                    ],
                    [
                        0.7619047619047619,
                        -0.42857142857142855
                    ],
                    [
                        0.7142857142857142,
                        -0.23809523809523808
                    ],
                    [
                        0.6666666666666666,
                        -0.14285714285714285
                    ],
                    [
                        0.6190476190476191,
                        -0.09523809523809523
                    ],
                    [
                        0.5238095238095237,
                        -0.047619047619047616
                    ],
                    [
                        0.42857142857142855,
                        -0.047619047619047616
                    ],
                    [
                        0.3333333333333333,
                        -0.09523809523809523
                    ],
                    [
                        0.2857142857142857,
                        -0.14285714285714285
                    ],
                    [
                        0.23809523809523808,
                        -0.23809523809523808
                    ],
                    [
                        0.19047619047619047,
                        -0.42857142857142855
                    ],
                    [
                        0.19047619047619047,
                        -0.6666666666666666
                    ],
                    [
                        0.23809523809523808,
                        -0.8571428571428571
                    ],
                    [
                        0.2857142857142857,
                        -0.9523809523809523
                    ],
                    [
                        0.3333333333333333,
                        -1.0
                    ],
                    [
                        0.42857142857142855,
                        -1.0476190476190474
                    ]
                ]
            ],
            "w": 0.9523809523809523
        },
        "1": {
            "l": [
                [
                    [
                        0.7619047619047619,
                        -0.047619047619047616
                    ],
                    [
                        0.19047619047619047,
                        -0.047619047619047616
                    ]
                ],
                [
                    [
                        0.47619047619047616,
                        -0.047619047619047616
                    ],
                    [
                        0.47619047619047616,
                        -1.0476190476190474
                    ],
                    [
                        0.38095238095238093,
                        -0.9047619047619047
                    ],
                    [
                        0.2857142857142857,
                        -0.8095238095238095
                    ],
                    [
                        0.19047619047619047,
                        -0.7619047619047619
                    ]
                ]
            ],
            "w": 0.9523809523809523
        },
        "2": {
            "l": [
                [
                    [
                        0.19047619047619047,
                        -0.9523809523809523
                    ],
                    [
                        0.23809523809523808,
                        -1.0
                    ],
                    [
                        0.3333333333333333,
                        -1.0476190476190474
                    ],
                    [
                        0.5714285714285714,
                        -1.0476190476190474
                    ],
                    [
                        0.6666666666666666,
                        -1.0
                    ],
                    [
                        0.7142857142857142,
                        -0.9523809523809523
                    ],
                    [
                        0.7619047619047619,
                        -0.8571428571428571
                    ],
                    [
                        0.7619047619047619,
                        -0.7619047619047619
                    ],
                    [
                        0.7142857142857142,
                        -0.6190476190476191
                    ],
                    [
                        0.14285714285714285,
                        -0.047619047619047616
                    ],
                    [
                        0.7619047619047619,
                        -0.047619047619047616
                    ]
                ]
            ],
            "w": 0.9523809523809523
        },
        "3": {
            "l": [
                [
                    [
                        0.14285714285714285,
                        -1.0476190476190474
                    ],
                    [
                        0.7619047619047619,
                        -1.0476190476190474
                    ],
                    [
                        0.42857142857142855,
                        -0.6666666666666666
                    ],
                    [
                        0.5714285714285714,
                        -0.6666666666666666
                    ],
                    [
                        0.6666666666666666,
                        -0.6190476190476191
                    ],
                    [
                        0.7142857142857142,
                        -0.5714285714285714
                    ],
                    [
                        0.7619047619047619,
                        -0.47619047619047616
                    ],
                    [
                        0.7619047619047619,
                        -0.23809523809523808
                    ],
                    [
                        0.7142857142857142,
                        -0.14285714285714285
                    ],
                    [
                        0.6666666666666666,
                        -0.09523809523809523
                    ],
                    [
                        0.5714285714285714,
                        -0.047619047619047616
                    ],
                    [
                        0.2857142857142857,
                        -0.047619047619047616
                    ],
                    [
                        0.19047619047619047,
                        -0.09523809523809523
                    ],
                    [
                        0.14285714285714285,
                        -0.14285714285714285
                    ]
                ]
            ],
            "w": 0.9523809523809523
        },
        "4": {
            "l": [
                [
                    [
                        0.6666666666666666,
                        -0.7142857142857142
                    ],
                    [
                        0.6666666666666666,
                        -0.047619047619047616
                    ]
                ],
                [
                    [
                        0.42857142857142855,
                        -1.0952380952380951
                    ],
                    [
                        0.19047619047619047,
                        -0.38095238095238093
                    ],
                    [
                        0.8095238095238095,
                        -0.38095238095238093
                    ]
                ]
            ],
            "w": 0.9523809523809523
        },
        "5": {
            "l": [
                [
                    [
                        0.7142857142857142,
                        -1.0476190476190474
                    ],
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ],
                    [
                        0.19047619047619047,
                        -0.5714285714285714
                    ],
                    [
                        0.23809523809523808,
                        -0.6190476190476191
                    ],
                    [
                        0.3333333333333333,
                        -0.6666666666666666
                    ],
                    [
                        0.5714285714285714,
                        -0.6666666666666666
                    ],
                    [
                        0.6666666666666666,
                        -0.6190476190476191
                    ],
                    [
                        0.7142857142857142,
                        -0.5714285714285714
                    ],
                    [
                        0.7619047619047619,
                        -0.47619047619047616
                    ],
                    [
                        0.7619047619047619,
                        -0.23809523809523808
                    ],
                    [
                        0.7142857142857142,
                        -0.14285714285714285
                    ],
                    [
                        0.6666666666666666,
                        -0.09523809523809523
                    ],
                    [
                        0.5714285714285714,
                        -0.047619047619047616
                    ],
                    [
                        0.3333333333333333,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -0.09523809523809523
                    ],
                    [
                        0.19047619047619047,
                        -0.14285714285714285
                    ]
                ]
            ],
            "w": 0.9523809523809523
        },
        ":": {
            "l": [
                [
                    [
                        0.23809523809523808,
                        -0.14285714285714285
                    ],
                    [
                        0.2857142857142857,
                        -0.09523809523809523
                    ],
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.19047619047619047,
                        -0.09523809523809523
                    ],
                    [
                        0.23809523809523808,
                        -0.14285714285714285
                    ],
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ]
                ],
                [
                    [
                        0.23809523809523808,
                        -0.6666666666666666
                    ],
                    [
                        0.2857142857142857,
                        -0.6190476190476191
                    ],
                    [
                        0.23809523809523808,
                        -0.5714285714285714
                    ],
                    [
                        0.19047619047619047,
                        -0.6190476190476191
                    ],
                    [
                        0.23809523809523808,
                        -0.6666666666666666
                    ],
                    [
                        0.23809523809523808,
                        -0.5714285714285714
                    ]
                ]
            ],
            "w": 0.47619047619047616
        },
        "A": {
            "l": [
                [
                    [
                        0.19047619047619047,
                        -0.3333333333333333
                    ],
                    [
                        0.6666666666666666,
                        -0.3333333333333333
                    ]
                ],
                [
                    [
                        0.09523809523809523,
                        -0.047619047619047616
                    ],
                    [
                        0.42857142857142855,
                        -1.0476190476190474
                    ],
                    [
                        0.7619047619047619,
                        -0.047619047619047616
                    ]
                ]
            ],
            "w": 0.8571428571428571
        },
        "B": {
            "l": [
                [
                    [
                        0.5714285714285714,
                        -0.5714285714285714
                    ],
                    [
                        0.7142857142857142,
                        -0.5238095238095237
                    ],
                    [
                        0.7619047619047619,
                        -0.47619047619047616
                    ],
                    [
                        0.8095238095238094,
                        -0.38095238095238093
                    ],
                    [
                        0.8095238095238094,
                        -0.23809523809523808
                    ],
                    [
                        0.7619047619047619,
                        -0.14285714285714285
                    ],
                    [
                        0.7142857142857142,
                        -0.09523809523809523
                    ],
                    [
                        0.619047619047619,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523803,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523803,
                        -1.0476190476190474
                    ],
                    [
                        0.5714285714285714,
                        -1.0476190476190474
                    ],
                    [
                        0.6666666666666665,
                        -1.0
                    ],
                    [
                        0.7142857142857142,
                        -0.9523809523809523
                    ],
                    [
                        0.7619047619047619,
                        -0.8571428571428571
                    ],
                    [
                        0.7619047619047619,
                        -0.7619047619047619
                    ],
                    [
                        0.7142857142857142,
                        -0.6666666666666666
                    ],
                    [
                        0.6666666666666665,
                        -0.6190476190476191
                    ],
                    [
                        0.5714285714285714,
                        -0.5714285714285714
                    ],
                    [
                        0.23809523809523803,
                        -0.5714285714285714
                    ]
                ]
            ],
            "w": 1.0
        },
        "C": {
            "l": [
                [
                    [
                        0.8095238095238095,
                        -0.14285714285714285
                    ],
                    [
                        0.7619047619047619,
                        -0.09523809523809523
                    ],
                    [
                        0.6190476190476191,
                        -0.047619047619047616
                    ],
                    [
                        0.5238095238095237,
                        -0.047619047619047616
                    ],
                    [
                        0.38095238095238093,
                        -0.09523809523809523
                    ],
                    [
                        0.2857142857142857,
                        -0.19047619047619047
                    ],
                    [
                        0.23809523809523808,
                        -0.2857142857142857
                    ],
                    [
                        0.19047619047619047,
                        -0.47619047619047616
                    ],
                    [
                        0.19047619047619047,
                        -0.6190476190476191
                    ],
                    [
                        0.23809523809523808,
                        -0.8095238095238095
                    ],
                    [
                        0.2857142857142857,
                        -0.9047619047619047
                    ],
                    [
                        0.38095238095238093,
                        -1.0
                    ],
                    [
                        0.5238095238095237,
                        -1.0476190476190474
                    ],
                    [
                        0.6190476190476191,
                        -1.0476190476190474
                    ],
                    [
                        0.7619047619047619,
                        -1.0
                    ],
                    [
                        0.8095238095238095,
                        -0.9523809523809523
                    ]
                ]
            ],
            "w": 1.0
        },
        "D": {
            "l": [
                [
                    [
                        0.23809523809523803,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523803,
                        -1.0476190476190474
                    ],
                    [
                        0.4761904761904761,
                        -1.0476190476190474
                    ],
                    [
                        0.619047619047619,
                        -1.0
                    ],
                    [
                        0.7142857142857142,
                        -0.9047619047619047
                    ],
                    [
                        0.7619047619047619,
                        -0.8095238095238095
                    ],
                    [
                        0.8095238095238094,
                        -0.6190476190476191
                    ],
                    [
                        0.8095238095238094,
                        -0.47619047619047616
                    ],
                    [
                        0.7619047619047619,
                        -0.2857142857142857
                    ],
                    [
                        0.7142857142857142,
                        -0.19047619047619047
                    ],
                    [
                        0.619047619047619,
                        -0.09523809523809523
                    ],
                    [
                        0.4761904761904761,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523803,
                        -0.047619047619047616
                    ]
                ]
            ],
            "w": 1.0
        },
        "E": {
            "l": [
                [
                    [
                        0.23809523809523808,
                        -0.5714285714285714
                    ],
                    [
                        0.5714285714285714,
                        -0.5714285714285714
                    ]
                ],
                [
                    [
                        0.7142857142857142,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ],
                    [
                        0.7142857142857142,
                        -1.0476190476190474
                    ]
                ]
            ],
            "w": 0.9047619047619047
        },
        "F": {
            "l": [
                [
                    [
                        0.5714285714285714,
                        -0.5714285714285714
                    ],
                    [
                        0.23809523809523808,
                        -0.5714285714285714
                    ]
                ],
                [
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ],
                    [
                        0.7142857142857142,
                        -1.0476190476190474
                    ]
                ]
            ],
            "w": 0.8571428571428571
        },
        "G": {
            "l": [
                [
                    [
                        0.7619047619047619,
                        -1.0
                    ],
                    [
                        0.6666666666666666,
                        -1.0476190476190474
                    ],
                    [
                        0.5238095238095237,
                        -1.0476190476190474
                    ],
                    [
                        0.38095238095238093,
                        -1.0
                    ],
                    [
                        0.2857142857142857,
                        -0.9047619047619047
                    ],
                    [
                        0.23809523809523808,
                        -0.8095238095238095
                    ],
                    [
                        0.19047619047619047,
                        -0.6190476190476191
                    ],
                    [
                        0.19047619047619047,
                        -0.47619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -0.2857142857142857
                    ],
                    [
                        0.2857142857142857,
                        -0.19047619047619047
                    ],
                    [
                        0.38095238095238093,
                        -0.09523809523809523
                    ],
                    [
                        0.5238095238095237,
                        -0.047619047619047616
                    ],
                    [
                        0.6190476190476191,
                        -0.047619047619047616
                    ],
                    [
                        0.7619047619047619,
                        -0.09523809523809523
                    ],
                    [
                        0.8095238095238095,
                        -0.14285714285714285
                    ],
                    [
                        0.8095238095238095,
                        -0.47619047619047616
                    ],
                    [
                        0.6190476190476191,
                        -0.47619047619047616
                    ]
                ]
            ],
            "w": 1.0
        },
        "I": {
            "l": [
                [
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ]
                ]
            ],
            "w": 0.47619047619047616
        },
        "J": {
            "l": [
                [
                    [
                        0.5238095238095237,
                        -1.0476190476190474
                    ],
                    [
                        0.5238095238095237,
                        -0.3333333333333333
                    ],
                    [
                        0.47619047619047616,
                        -0.19047619047619047
                    ],
                    [
                        0.38095238095238093,
                        -0.09523809523809523
                    ],
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.14285714285714285,
                        -0.047619047619047616
                    ]
                ]
            ],
            "w": 0.7619047619047619
        },
        "L": {
            "l": [
                [
                    [
                        0.7142857142857142,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ]
                ]
            ],
            "w": 0.8095238095238095
        },
        "M": {
            "l": [
                [
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ],
                    [
                        0.5714285714285714,
                        -0.3333333333333333
                    ],
                    [
                        0.9047619047619047,
                        -1.0476190476190474
                    ],
                    [
                        0.9047619047619047,
                        -0.047619047619047616
                    ]
                ]
            ],
            "w": 1.1428571428571428
        },
        "N": {
            "l": [
                [
                    [
                        0.23809523809523803,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523803,
                        -1.0476190476190474
                    ],
                    [
                        0.8095238095238094,
                        -0.047619047619047616
                    ],
                    [
                        0.8095238095238094,
                        -1.0476190476190474
                    ]
                ]
            ],
            "w": 1.0476190476190474
        },
        "P": {
            "l": [
                [
                    [
                        0.23809523809523803,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523803,
                        -1.0476190476190474
                    ],
                    [
                        0.619047619047619,
                        -1.0476190476190474
                    ],
                    [
                        0.7142857142857142,
                        -1.0
                    ],
                    [
                        0.7619047619047619,
                        -0.9523809523809523
                    ],
                    [
                        0.8095238095238094,
                        -0.8571428571428571
                    ],
                    [
                        0.8095238095238094,
                        -0.7142857142857142
                    ],
                    [
                        0.7619047619047619,
                        -0.6190476190476191
                    ],
                    [
                        0.7142857142857142,
                        -0.5714285714285714
                    ],
                    [
                        0.619047619047619,
                        -0.5238095238095237
                    ],
                    [
                        0.23809523809523803,
                        -0.5238095238095237
                    ]
                ]
            ],
            "w": 1.0
        },
        "R": {
            "l": [
                [
                    [
                        0.8095238095238094,
                        -0.047619047619047616
                    ],
                    [
                        0.4761904761904761,
                        -0.5238095238095237
                    ]
                ],
                [
                    [
                        0.23809523809523803,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523803,
                        -1.0476190476190474
                    ],
                    [
                        0.619047619047619,
                        -1.0476190476190474
                    ],
                    [
                        0.7142857142857142,
                        -1.0
                    ],
                    [
                        0.7619047619047619,
                        -0.9523809523809523
                    ],
                    [
                        0.8095238095238094,
                        -0.8571428571428571
                    ],
                    [
                        0.8095238095238094,
                        -0.7142857142857142
                    ],
                    [
                        0.7619047619047619,
                        -0.6190476190476191
                    ],
                    [
                        0.7142857142857142,
                        -0.5714285714285714
                    ],
                    [
                        0.619047619047619,
                        -0.5238095238095237
                    ],
                    [
                        0.23809523809523803,
                        -0.5238095238095237
                    ]
                ]
            ],
            "w": 1.0
        },
        "S": {
            "l": [
                [
                    [
                        0.19047619047619047,
                        -0.09523809523809523
                    ],
                    [
                        0.3333333333333333,
                        -0.047619047619047616
                    ],
                    [
                        0.5714285714285714,
                        -0.047619047619047616
                    ],
                    [
                        0.6666666666666666,
                        -0.09523809523809523
                    ],
                    [
                        0.7142857142857142,
                        -0.14285714285714285
                    ],
                    [
                        0.7619047619047619,
                        -0.23809523809523808
                    ],
                    [
                        0.7619047619047619,
                        -0.3333333333333333
                    ],
                    [
                        0.7142857142857142,
                        -0.42857142857142855
                    ],
                    [
                        0.6666666666666666,
                        -0.47619047619047616
                    ],
                    [
                        0.5714285714285714,
                        -0.5238095238095237
                    ],
                    [
                        0.38095238095238093,
                        -0.5714285714285714
                    ],
                    [
                        0.2857142857142857,
                        -0.6190476190476191
                    ],
                    [
                        0.23809523809523808,
                        -0.6666666666666666
                    ],
                    [
                        0.19047619047619047,
                        -0.7619047619047619
                    ],
                    [
                        0.19047619047619047,
                        -0.8571428571428571
                    ],
                    [
                        0.23809523809523808,
                        -0.9523809523809523
                    ],
                    [
                        0.2857142857142857,
                        -1.0
                    ],
                    [
                        0.38095238095238093,
                        -1.0476190476190474
                    ],
                    [
                        0.6190476190476191,
                        -1.0476190476190474
                    ],
                    [
                        0.7619047619047619,
                        -1.0
                    ]
                ]
            ],
            "w": 0.9523809523809523
        },
        "U": {
            "l": [
                [
                    [
                        0.23809523809523803,
                        -1.0476190476190474
                    ],
                    [
                        0.23809523809523803,
                        -0.23809523809523808
                    ],
                    [
                        0.28571428571428564,
                        -0.14285714285714285
                    ],
                    [
                        0.33333333333333326,
                        -0.09523809523809523
                    ],
                    [
                        0.4285714285714285,
                        -0.047619047619047616
                    ],
                    [
                        0.619047619047619,
                        -0.047619047619047616
                    ],
                    [
                        0.7142857142857142,
                        -0.09523809523809523
                    ],
                    [
                        0.7619047619047619,
                        -0.14285714285714285
                    ],
                    [
                        0.8095238095238094,
                        -0.23809523809523808
                    ],
                    [
                        0.8095238095238094,
                        -1.0476190476190474
                    ]
                ]
            ],
            "w": 1.0476190476190474
        },
        "V": {
            "l": [
                [
                    [
                        0.09523809523809523,
                        -1.0476190476190474
                    ],
                    [
                        0.42857142857142855,
                        -0.047619047619047616
                    ],
                    [
                        0.7619047619047619,
                        -1.0476190476190474
                    ]
                ]
            ],
            "w": 0.8571428571428571
        },
        "W": {
            "l": [
                [
                    [
                        0.14285714285714285,
                        -1.0476190476190474
                    ],
                    [
                        0.38095238095238093,
                        -0.047619047619047616
                    ],
                    [
                        0.5714285714285714,
                        -0.7619047619047619
                    ],
                    [
                        0.7619047619047619,
                        -0.047619047619047616
                    ],
                    [
                        1.0,
                        -1.0476190476190474
                    ]
                ]
            ],
            "w": 1.1428571428571428
        },
        "X": {
            "l": [
                [
                    [
                        0.14285714285714285,
                        -1.0476190476190474
                    ],
                    [
                        0.8095238095238095,
                        -0.047619047619047616
                    ]
                ],
                [
                    [
                        0.8095238095238095,
                        -1.0476190476190474
                    ],
                    [
                        0.14285714285714285,
                        -0.047619047619047616
                    ]
                ]
            ],
            "w": 0.9523809523809523
        },
        "a": {
            "l": [
                [
                    [
                        0.6666666666666666,
                        -0.047619047619047616
                    ],
                    [
                        0.6666666666666666,
                        -0.5714285714285714
                    ],
                    [
                        0.6190476190476191,
                        -0.6666666666666666
                    ],
                    [
                        0.5238095238095237,
                        -0.7142857142857142
                    ],
                    [
                        0.3333333333333333,
                        -0.7142857142857142
                    ],
                    [
                        0.23809523809523808,
                        -0.6666666666666666
                    ]
                ],
                [
                    [
                        0.6666666666666666,
                        -0.09523809523809523
                    ],
                    [
                        0.5714285714285714,
                        -0.047619047619047616
                    ],
                    [
                        0.3333333333333333,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -0.09523809523809523
                    ],
                    [
                        0.19047619047619047,
                        -0.19047619047619047
                    ],
                    [
                        0.19047619047619047,
                        -0.2857142857142857
                    ],
                    [
                        0.23809523809523808,
                        -0.38095238095238093
                    ],
                    [
                        0.3333333333333333,
                        -0.42857142857142855
                    ],
                    [
                        0.5714285714285714,
                        -0.42857142857142855
                    ],
                    [
                        0.6666666666666666,
                        -0.47619047619047616
                    ]
                ]
            ],
            "w": 0.9047619047619047
        },
        "d": {
            "l": [
                [
                    [
                        0.6666666666666666,
                        -0.047619047619047616
                    ],
                    [
                        0.6666666666666666,
                        -1.0476190476190474
                    ]
                ],
                [
                    [
                        0.6666666666666666,
                        -0.09523809523809523
                    ],
                    [
                        0.5714285714285714,
                        -0.047619047619047616
                    ],
                    [
                        0.38095238095238093,
                        -0.047619047619047616
                    ],
                    [
                        0.2857142857142857,
                        -0.09523809523809523
                    ],
                    [
                        0.23809523809523808,
                        -0.14285714285714285
                    ],
                    [
                        0.19047619047619047,
                        -0.23809523809523808
                    ],
                    [
                        0.19047619047619047,
                        -0.5238095238095237
                    ],
                    [
                        0.23809523809523808,
                        -0.6190476190476191
                    ],
                    [
                        0.2857142857142857,
                        -0.6666666666666666
                    ],
                    [
                        0.38095238095238093,
                        -0.7142857142857142
                    ],
                    [
                        0.5714285714285714,
                        -0.7142857142857142
                    ],
                    [
                        0.6666666666666666,
                        -0.6666666666666666
                    ]
                ]
            ],
            "w": 0.9047619047619047
        },
        "e": {
            "l": [
                [
                    [
                        0.6190476190476191,
                        -0.09523809523809523
                    ],
                    [
                        0.5238095238095237,
                        -0.047619047619047616
                    ],
                    [
                        0.3333333333333333,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -0.09523809523809523
                    ],
                    [
                        0.19047619047619047,
                        -0.19047619047619047
                    ],
                    [
                        0.19047619047619047,
                        -0.5714285714285714
                    ],
                    [
                        0.23809523809523808,
                        -0.6666666666666666
                    ],
                    [
                        0.3333333333333333,
                        -0.7142857142857142
                    ],
                    [
                        0.5238095238095237,
                        -0.7142857142857142
                    ],
                    [
                        0.6190476190476191,
                        -0.6666666666666666
                    ],
                    [
                        0.6666666666666666,
                        -0.5714285714285714
                    ],
                    [
                        0.6666666666666666,
                        -0.47619047619047616
                    ],
                    [
                        0.19047619047619047,
                        -0.38095238095238093
                    ]
                ]
            ],
            "w": 0.8571428571428571
        },
        "g": {
            "l": [
                [
                    [
                        0.6666666666666666,
                        -0.7142857142857142
                    ],
                    [
                        0.6666666666666666,
                        0.09523809523809523
                    ],
                    [
                        0.6190476190476191,
                        0.19047619047619047
                    ],
                    [
                        0.5714285714285714,
                        0.23809523809523808
                    ],
                    [
                        0.47619047619047616,
                        0.2857142857142857
                    ],
                    [
                        0.3333333333333333,
                        0.2857142857142857
                    ],
                    [
                        0.23809523809523808,
                        0.23809523809523808
                    ]
                ],
                [
                    [
                        0.6666666666666666,
                        -0.09523809523809523
                    ],
                    [
                        0.5714285714285714,
                        -0.047619047619047616
                    ],
                    [
                        0.38095238095238093,
                        -0.047619047619047616
                    ],
                    [
                        0.2857142857142857,
                        -0.09523809523809523
                    ],
                    [
                        0.23809523809523808,
                        -0.14285714285714285
                    ],
                    [
                        0.19047619047619047,
                        -0.23809523809523808
                    ],
                    [
                        0.19047619047619047,
                        -0.5238095238095237
                    ],
                    [
                        0.23809523809523808,
                        -0.6190476190476191
                    ],
                    [
                        0.2857142857142857,
                        -0.6666666666666666
                    ],
                    [
                        0.38095238095238093,
                        -0.7142857142857142
                    ],
                    [
                        0.5714285714285714,
                        -0.7142857142857142
                    ],
                    [
                        0.6666666666666666,
                        -0.6666666666666666
                    ]
                ]
            ],
            "w": 0.9047619047619047
        },
        "i": {
            "l": [
                [
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -0.7142857142857142
                    ]
                ],
                [
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ],
                    [
                        0.19047619047619047,
                        -1.0
                    ],
                    [
                        0.23809523809523808,
                        -0.9523809523809523
                    ],
                    [
                        0.2857142857142857,
                        -1.0
                    ],
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ],
                    [
                        0.23809523809523808,
                        -0.9523809523809523
                    ]
                ]
            ],
            "w": 0.47619047619047616
        },
        "k": {
            "l": [
                [
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ]
                ],
                [
                    [
                        0.3333333333333333,
                        -0.42857142857142855
                    ],
                    [
                        0.6190476190476191,
                        -0.047619047619047616
                    ]
                ],
                [
                    [
                        0.6190476190476191,
                        -0.7142857142857142
                    ],
                    [
                        0.23809523809523808,
                        -0.3333333333333333
                    ]
                ]
            ],
            "w": 0.8095238095238095
        },
        "l": {
            "l": [
                [
                    [
                        0.38095238095238093,
                        -0.047619047619047616
                    ],
                    [
                        0.2857142857142857,
                        -0.09523809523809523
                    ],
                    [
                        0.23809523809523808,
                        -0.19047619047619047
                    ],
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ]
                ]
            ],
            "w": 0.5238095238095237
        },
        "n": {
            "l": [
                [
                    [
                        0.23809523809523808,
                        -0.7142857142857142
                    ],
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ]
                ],
                [
                    [
                        0.23809523809523808,
                        -0.6190476190476191
                    ],
                    [
                        0.2857142857142857,
                        -0.6666666666666666
                    ],
                    [
                        0.38095238095238093,
                        -0.7142857142857142
                    ],
                    [
                        0.5238095238095237,
                        -0.7142857142857142
                    ],
                    [
                        0.6190476190476191,
                        -0.6666666666666666
                    ],
                    [
                        0.6666666666666666,
                        -0.5714285714285714
                    ],
                    [
                        0.6666666666666666,
                        -0.047619047619047616
                    ]
                ]
            ],
            "w": 0.9047619047619047
        },
        "o": {
            "l": [
                [
                    [
                        0.38095238095238093,
                        -0.047619047619047616
                    ],
                    [
                        0.2857142857142857,
                        -0.09523809523809523
                    ],
                    [
                        0.23809523809523808,
                        -0.14285714285714285
                    ],
                    [
                        0.19047619047619047,
                        -0.23809523809523808
                    ],
                    [
                        0.19047619047619047,
                        -0.5238095238095237
                    ],
                    [
                        0.23809523809523808,
                        -0.6190476190476191
                    ],
                    [
                        0.2857142857142857,
                        -0.6666666666666666
                    ],
                    [
                        0.38095238095238093,
                        -0.7142857142857142
                    ],
                    [
                        0.5238095238095237,
                        -0.7142857142857142
                    ],
                    [
                        0.6190476190476191,
                        -0.6666666666666666
                    ],
                    [
                        0.6666666666666666,
                        -0.6190476190476191
                    ],
                    [
                        0.7142857142857142,
                        -0.5238095238095237
                    ],
                    [
                        0.7142857142857142,
                        -0.23809523809523808
                    ],
                    [
                        0.6666666666666666,
                        -0.14285714285714285
                    ],
                    [
                        0.6190476190476191,
                        -0.09523809523809523
                    ],
                    [
                        0.5238095238095237,
                        -0.047619047619047616
                    ],
                    [
                        0.38095238095238093,
                        -0.047619047619047616
                    ]
                ]
            ],
            "w": 0.9047619047619047
        },
        "r": {
            "l": [
                [
                    [
                        0.23809523809523808,
                        -0.047619047619047616
                    ],
                    [
                        0.23809523809523808,
                        -0.7142857142857142
                    ]
                ],
                [
                    [
                        0.23809523809523808,
                        -0.5238095238095237
                    ],
                    [
                        0.2857142857142857,
                        -0.6190476190476191
                    ],
                    [
                        0.3333333333333333,
                        -0.6666666666666666
                    ],
                    [
                        0.42857142857142855,
                        -0.7142857142857142
                    ],
                    [
                        0.5238095238095237,
                        -0.7142857142857142
                    ]
                ]
            ],
            "w": 0.6190476190476191
        },
        "s": {
            "l": [
                [
                    [
                        0.19047619047619047,
                        -0.09523809523809523
                    ],
                    [
                        0.2857142857142857,
                        -0.047619047619047616
                    ],
                    [
                        0.47619047619047616,
                        -0.047619047619047616
                    ],
                    [
                        0.5714285714285714,
                        -0.09523809523809523
                    ],
                    [
                        0.6190476190476191,
                        -0.19047619047619047
                    ],
                    [
                        0.6190476190476191,
                        -0.23809523809523808
                    ],
                    [
                        0.5714285714285714,
                        -0.3333333333333333
                    ],
                    [
                        0.47619047619047616,
                        -0.38095238095238093
                    ],
                    [
                        0.3333333333333333,
                        -0.38095238095238093
                    ],
                    [
                        0.23809523809523808,
                        -0.42857142857142855
                    ],
                    [
                        0.19047619047619047,
                        -0.5238095238095237
                    ],
                    [
                        0.19047619047619047,
                        -0.5714285714285714
                    ],
                    [
                        0.23809523809523808,
                        -0.6666666666666666
                    ],
                    [
                        0.3333333333333333,
                        -0.7142857142857142
                    ],
                    [
                        0.47619047619047616,
                        -0.7142857142857142
                    ],
                    [
                        0.5714285714285714,
                        -0.6666666666666666
                    ]
                ]
            ],
            "w": 0.8095238095238095
        },
        "t": {
            "l": [
                [
                    [
                        0.09523809523809523,
                        -0.7142857142857142
                    ],
                    [
                        0.47619047619047616,
                        -0.7142857142857142
                    ]
                ],
                [
                    [
                        0.23809523809523808,
                        -1.0476190476190474
                    ],
                    [
                        0.23809523809523808,
                        -0.19047619047619047
                    ],
                    [
                        0.2857142857142857,
                        -0.09523809523809523
                    ],
                    [
                        0.38095238095238093,
                        -0.047619047619047616
                    ],
                    [
                        0.47619047619047616,
                        -0.047619047619047616
                    ]
                ]
            ],
            "w": 0.5714285714285714
        },
        "u": {
            "l": [
                [
                    [
                        0.6666666666666666,
                        -0.7142857142857142
                    ],
                    [
                        0.6666666666666666,
                        -0.047619047619047616
                    ]
                ],
                [
                    [
                        0.23809523809523808,
                        -0.7142857142857142
                    ],
                    [
                        0.23809523809523808,
                        -0.19047619047619047
                    ],
                    [
                        0.2857142857142857,
                        -0.09523809523809523
                    ],
                    [
                        0.38095238095238093,
                        -0.047619047619047616
                    ],
                    [
                        0.5238095238095237,
                        -0.047619047619047616
                    ],
                    [
                        0.6190476190476191,
                        -0.09523809523809523
                    ],
                    [
                        0.6666666666666666,
                        -0.14285714285714285
                    ]
                ]
            ],
            "w": 0.9047619047619047
        },
        "v": {
            "l": [
                [
                    [
                        0.14285714285714285,
                        -0.7142857142857142
                    ],
                    [
                        0.38095238095238093,
                        -0.047619047619047616
                    ],
                    [
                        0.6190476190476191,
                        -0.7142857142857142
                    ]
                ]
            ],
            "w": 0.7619047619047619
        }
    }
}
},{}],6:[function(require,module,exports){
/* PCB rendering code */

var globalData = require('./global.js')

function deg2rad(deg) {
  return deg * Math.PI / 180;
}

function calcFontPoint(linepoint, text, offsetx, offsety, tilt) {
  var point = [
    linepoint[0] * text.width + offsetx,
    linepoint[1] * text.height + offsety
  ];
  // Adding half a line height here is technically a bug
  // but pcbnew currently does the same, text is slightly shifted.
  point[0] -= (point[1] + text.height * 0.5) * tilt;
  return point;
}

function drawtext(ctx, text, color, flip) {
  ctx.save();
  ctx.translate(...text.pos);
  var angle = -text.angle;
  if (text.attr.includes("mirrored")) {
    ctx.scale(-1, 1);
    angle = -angle;
  }
  var tilt = 0;
  if (text.attr.includes("italic")) {
    tilt = 0.125;
  }
  var interline = (text.height * 1.5 + text.thickness) / 2;
  var txt = text.text.split("\n");
  ctx.rotate(deg2rad(angle));
  ctx.fillStyle = color;
  ctx.strokeStyle = color;
  ctx.lineCap = "round";
  ctx.lineWidth = text.thickness;
  for (var i in txt) {
    var offsety = (-(txt.length - 1) + i * 2) * interline + text.height / 2;
    var lineWidth = 0;
    for (var c of txt[i]) {
      lineWidth += pcbFont.font_data[c].w * text.width;
    }
    var offsetx = 0;
    switch (text.horiz_justify) {
      case -1:
        // Justify left, do nothing
        break;
      case 0:
        // Justify center
        offsetx -= lineWidth / 2;
        break;
      case 1:
        // Justify right
        offsetx -= lineWidth;
        break;
    }
    for (var c of txt[i]) {
      for (var line of pcbFont.font_data[c].l) {
        // Drawing each segment separately instead of
        // polyline because round line caps don't work in joints
        for (var i = 0; i < line.length - 1; i++) {
          ctx.beginPath();
          ctx.moveTo(...calcFontPoint(line[i], text, offsetx, offsety, tilt));
          ctx.lineTo(...calcFontPoint(line[i + 1], text, offsetx, offsety, tilt));
          ctx.stroke();
        }
      }
      offsetx += pcbFont.font_data[c].w * text.width;
    }
  }
  ctx.restore();
}

function drawedge(ctx, scalefactor, edge, color) {
  ctx.strokeStyle = color;
  ctx.lineWidth = Math.max(1 / scalefactor, edge.width);
  ctx.lineCap = "round";
  if (edge.type == "segment") 
  {
    ctx.beginPath();
    ctx.moveTo(...edge.start);
    ctx.lineTo(...edge.end);
    ctx.stroke();
  }
  if (edge.type == "arc") {
    ctx.beginPath();
    ctx.arc(
      ...edge.start,
      edge.radius,
      deg2rad(edge.startangle),
      deg2rad(edge.endangle));
    ctx.stroke();
  }
  if (edge.type == "circle") {
    ctx.beginPath();
    ctx.arc(
      ...edge.start,
      edge.radius,
      0, 2 * Math.PI);
    ctx.closePath();
    ctx.stroke();
  }
}

function drawRoundRect(ctx, color, size, radius, ctxmethod) {
  ctx.beginPath();
  ctx.strokeStyle = color;
  var x = size[0] * -0.5;
  var y = size[1] * -0.5;
  var width = size[0];
  var height = size[1];
  ctx.moveTo(x, 0);
  ctx.arcTo(x, y + height, x + width, y + height, radius);
  ctx.arcTo(x + width, y + height, x + width, y, radius);
  ctx.arcTo(x + width, y, x, y, radius);
  ctx.arcTo(x, y, x, y + height, radius);
  ctx.closePath();
  ctxmethod();
}

function drawOblong(ctx, color, size, ctxmethod) {
  drawRoundRect(ctx, color, size, Math.min(size[0], size[1]) / 2, ctxmethod);
}

function drawPolygons(ctx, color, polygons, ctxmethod) {
  ctx.fillStyle = color;
  if(polygons.length>0)
  {
    for (var polygon of polygons) {
      ctx.beginPath();
      for (var vertex of polygon) {
        ctx.lineTo(...vertex)
      }
      ctx.closePath();
      ctxmethod();
    }
  }
}

function drawPolygonShape(ctx, shape, color) {
  ctx.save();
  ctx.translate(...shape.pos);
  ctx.rotate(deg2rad(-shape.angle));
  drawPolygons(ctx, color, shape.polygons, ctx.fill.bind(ctx));
  ctx.restore();
}

function drawDrawing(ctx, layer, scalefactor, drawing, color) {
  if (["segment", "arc", "circle"].includes(drawing.type)) {
    drawedge(ctx, scalefactor, drawing, color);
  } else if (drawing.type == "polygon") {
    drawPolygonShape(ctx, drawing, color);
  } else {
    drawtext(ctx, drawing, color, layer == "B");
  }
}

function drawCircle(ctx, radius, ctxmethod) {
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, 2 * Math.PI);
  ctx.closePath();
  ctxmethod();
}

function drawPad(ctx, pad, color, outline) {
  ctx.save();
  ctx.translate(...pad.pos);
  ctx.rotate(deg2rad(pad.angle));
  if (pad.offset) {
    ctx.translate(...pad.offset);
  }
  ctx.fillStyle = color;
  ctx.strokeStyle = color;
  var ctxmethod = outline ? ctx.stroke.bind(ctx) : ctx.fill.bind(ctx);
  if (pad.shape == "rect") {
    var rect = [...pad.size.map(c => -c * 0.5), ...pad.size];
    if (outline) {
      ctx.strokeRect(...rect);
    } else {
      ctx.fillRect(...rect);
    }
  } else if (pad.shape == "oval") {
    drawOblong(ctx, color, pad.size, ctxmethod);
  } else if (pad.shape == "circle") {
    drawCircle(ctx, pad.size[0] / 2, ctxmethod);
  } else if (pad.shape == "roundrect") {
    drawRoundRect(ctx, color, pad.size, pad.radius, ctxmethod);
  } else if (pad.shape == "custom") {
    drawPolygons(ctx, color, pad.polygons, ctxmethod);
  }
  if (pad.type == "th" && !outline) {
    ctx.fillStyle = "#CCCCCC";
    if (pad.drillshape == "oblong") {
      drawOblong(ctx, "#CCCCCC", pad.drillsize, ctxmethod);
    } else {
      drawCircle(ctx, pad.drillsize[0] / 2, ctxmethod);
    }
  }
  ctx.restore();
}

function drawModule(ctx, layer, scalefactor, module, padcolor, outlinecolor, highlight) {
  if (highlight) {
    // draw bounding box
    if (module.layer == layer) {
      ctx.save();
      ctx.globalAlpha = 0.2;
      ctx.translate(...module.bbox.pos);
      ctx.fillStyle = padcolor;
      ctx.fillRect(0, 0,...module.bbox.size);
      ctx.globalAlpha = 1;
      ctx.strokeStyle = padcolor;
      ctx.strokeRect(
        0, 0,
        ...module.bbox.size);
      ctx.restore();
    }
  }
  // draw drawings
  for (var drawing of module.drawings) {
    if (drawing.layer == layer) {
      drawDrawing(ctx, layer, scalefactor, drawing.drawing, padcolor);
    }
  }
  // draw pads
  for (var pad of module.pads) {
    if (pad.layers.includes(layer)) {
      drawPad(ctx, pad, padcolor, false);
      
      
      if (pad.pin1 && globalData.getHighlightPin1()) 
      {
        drawPad(ctx, pad, outlinecolor, true);
      }
    }
  }
}

function drawEdges(canvas, scalefactor) {
  var ctx = canvas.getContext("2d");
  var edgecolor = getComputedStyle(topmostdiv).getPropertyValue('--pcb-edge-color');
  for (var edge of pcbdata.edges) {
    drawedge(ctx, scalefactor, edge, edgecolor);
  }
}

function drawModules(canvas, layer, scalefactor, highlightedRefs) {
  var ctx = canvas.getContext("2d");
  ctx.lineWidth = 3 / scalefactor;
  var style = getComputedStyle(topmostdiv);
  var padcolor = style.getPropertyValue('--pad-color');
  var outlinecolor = style.getPropertyValue('--pin1-outline-color');
  if (highlightedRefs.length > 0) {
    padcolor = style.getPropertyValue('--pad-color-highlight');
    outlinecolor = style.getPropertyValue('--pin1-outline-color-highlight');
  }
  for (var i in pcbdata.modules) {
    var mod = pcbdata.modules[i];
    var highlight = highlightedRefs.includes(mod.ref);
    if (highlightedRefs.length == 0 || highlight) {
      drawModule(ctx, layer, scalefactor, mod, padcolor, outlinecolor, highlight);
    }
  }
}

function drawSilkscreen(canvas, layer, scalefactor)
{
  var ctx = canvas.getContext("2d");
  for (var d of pcbdata.silkscreen[layer])
  {
    if (["segment", "arc", "circle"].includes(d.type))
    {
      drawedge(ctx, scalefactor, d, "#aa4");
    }
    else if (d.type == "polygon")
    {
      drawPolygonShape(ctx, d, "#4aa");
    }
    else
    {
      drawtext(ctx, d, "#4aa", layer == "B");
    }
  }
}

function clearCanvas(canvas) {
  var ctx = canvas.getContext("2d");
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.restore();
}

function drawHighlightsOnLayer(canvasdict) {
  clearCanvas(canvasdict.highlight);
  drawModules(canvasdict.highlight, canvasdict.layer,
    canvasdict.transform.s, globalData.getHighlightedRefs());
}

function drawHighlights() {
  drawHighlightsOnLayer(allcanvas.front);
  drawHighlightsOnLayer(allcanvas.back);
}

function drawBackground(canvasdict) {
  clearCanvas(canvasdict.bg);
  clearCanvas(canvasdict.silk);
  drawEdges(canvasdict.bg, canvasdict.transform.s);
  drawModules(canvasdict.bg, canvasdict.layer, canvasdict.transform.s, []);
  drawSilkscreen(canvasdict.silk, canvasdict.layer, canvasdict.transform.s);
}

function prepareCanvas(canvas, flip, transform) {
  var ctx = canvas.getContext("2d");
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  var fontsize = 1.55;
  ctx.scale(transform.zoom, transform.zoom);
  ctx.translate(transform.panx, transform.pany);
  if (flip) {
    ctx.scale(-1, 1);
  }
  ctx.translate(transform.x, transform.y);
  ctx.rotate(deg2rad(boardRotation));
  ctx.scale(transform.s, transform.s);
}

function prepareLayer(canvasdict) {
  var flip = (canvasdict.layer != "B");
  for (var c of ["bg", "silk", "highlight"]) {
    prepareCanvas(canvasdict[c], flip, canvasdict.transform);
  }
}

function rotateVector(v, angle) {
  angle = deg2rad(angle);
  return [
    v[0] * Math.cos(angle) - v[1] * Math.sin(angle),
    v[0] * Math.sin(angle) + v[1] * Math.cos(angle)
  ];
}

function applyRotation(bbox) {
  var corners = [
    [bbox.minx, bbox.miny],
    [bbox.minx, bbox.maxy],
    [bbox.maxx, bbox.miny],
    [bbox.maxx, bbox.maxy],
  ];
  corners = corners.map((v) => rotateVector(v, boardRotation));
  return {
    minx: corners.reduce((a, v) => Math.min(a, v[0]), Infinity),
    miny: corners.reduce((a, v) => Math.min(a, v[1]), Infinity),
    maxx: corners.reduce((a, v) => Math.max(a, v[0]), -Infinity),
    maxy: corners.reduce((a, v) => Math.max(a, v[1]), -Infinity),
  }
}

function recalcLayerScale(canvasdict) {
  var canvasdivid = {
    "F": "frontcanvas",
    "B": "backcanvas"
  } [canvasdict.layer];
  var width = document.getElementById(canvasdivid).clientWidth * 2;
  var height = document.getElementById(canvasdivid).clientHeight * 2;
  var bbox = applyRotation(pcbdata.edges_bbox);
  var scalefactor = 0.98 * Math.min(
    width / (bbox.maxx - bbox.minx),
    height / (bbox.maxy - bbox.miny)
  );
  if (scalefactor < 0.1) {
    scalefactor = 1;
  }
  canvasdict.transform.s = scalefactor;
  var flip = (canvasdict.layer != "B");
  if (flip) {
    canvasdict.transform.x = -((bbox.maxx + bbox.minx) * scalefactor + width) * 0.5;
  } else {
    canvasdict.transform.x = -((bbox.maxx + bbox.minx) * scalefactor - width) * 0.5;
  }
  canvasdict.transform.y = -((bbox.maxy + bbox.miny) * scalefactor - height) * 0.5;
  for (var c of ["bg", "silk", "highlight"]) {
    canvas = canvasdict[c];
    canvas.width = width;
    canvas.height = height;
    canvas.style.width = (width / 2) + "px";
    canvas.style.height = (height / 2) + "px";
  }
  console.log("Scale factor " + canvasdivid + ": ", canvasdict.transform);
}

function redrawCanvas(layerdict) {
  prepareLayer(layerdict);
  drawBackground(layerdict);
  drawHighlightsOnLayer(layerdict);
}

function resizeCanvas(layerdict) {
  recalcLayerScale(layerdict);
  redrawCanvas(layerdict);
}

function resizeAll() {
  resizeCanvas(allcanvas.front);
  resizeCanvas(allcanvas.back);
}

function bboxScan(layer, x, y) {
  var result = [];
  for (var i in pcbdata.modules) {
    var module = pcbdata.modules[i];
    if (module.layer == layer) {
      var b = module.bbox;
      if (b.pos[0] <= x && b.pos[0] + b.size[0] >= x &&
        b.pos[1] <= y && b.pos[1] + b.size[1] >= y) {
        result.push(module.ref);
      }
    }
  }
  return result;
}

function handleMouseDown(e, layerdict) {
  if (e.which != 1) {
    return;
  }
  e.preventDefault();
  e.stopPropagation();
  layerdict.transform.mousestartx = e.offsetX;
  layerdict.transform.mousestarty = e.offsetY;
  layerdict.transform.mousedownx = e.offsetX;
  layerdict.transform.mousedowny = e.offsetY;
  layerdict.transform.mousedown = true;
}

function handleMouseClick(e, layerdict) {
  var x = e.offsetX;
  var y = e.offsetY;
  var t = layerdict.transform;
  if (layerdict.layer == "B") {
    x = (2 * x / t.zoom - t.panx + t.x) / -t.s;
  } else {
    x = (2 * x / t.zoom - t.panx - t.x) / t.s;
  }
  y = (2 * y / t.zoom - t.y - t.pany) / t.s;
  var v = rotateVector([x, y], -boardRotation);
  var reflist = bboxScan(layerdict.layer, v[0], v[1]);
  if (reflist.length > 0) {
    modulesClicked(reflist);
    drawHighlights();
  }
}

function handleMouseUp(e, layerdict) {
  e.preventDefault();
  e.stopPropagation();
  if (e.which == 1 &&
    layerdict.transform.mousedown &&
    layerdict.transform.mousedownx == e.offsetX &&
    layerdict.transform.mousedowny == e.offsetY) {
    // This is just a click
    handleMouseClick(e, layerdict);
    layerdict.transform.mousedown = false;
    return;
  }
  if (e.which == 3) {
    // Reset pan and zoom on right click.
    layerdict.transform.panx = 0;
    layerdict.transform.pany = 0;
    layerdict.transform.zoom = 1;
    redrawCanvas(layerdict);
  } else if (!globalData.getRedrawOnDrag()) {
    redrawCanvas(layerdict);
  }
  layerdict.transform.mousedown = false;
}

function handleMouseMove(e, layerdict) {
  if (!layerdict.transform.mousedown) {
    return;
  }
  e.preventDefault();
  e.stopPropagation();
  var dx = e.offsetX - layerdict.transform.mousestartx;
  var dy = e.offsetY - layerdict.transform.mousestarty;
  layerdict.transform.panx += 2 * dx / layerdict.transform.zoom;
  layerdict.transform.pany += 2 * dy / layerdict.transform.zoom;
  layerdict.transform.mousestartx = e.offsetX;
  layerdict.transform.mousestarty = e.offsetY;
  if (globalData.getRedrawOnDrag()) {
    redrawCanvas(layerdict);
  }
}

function handleMouseWheel(e, layerdict) {
  e.preventDefault();
  e.stopPropagation();
  var t = layerdict.transform;
  var wheeldelta = e.deltaY;
  if (e.deltaMode == 1) {
    // FF only, scroll by lines
    wheeldelta *= 30;
  } else if (e.deltaMode == 2) {
    wheeldelta *= 300;
  }
  var m = Math.pow(1.1, -wheeldelta / 40);
  // Limit amount of zoom per tick.
  if (m > 2) {
    m = 2;
  } else if (m < 0.5) {
    m = 0.5;
  }
  t.zoom *= m;
  var zoomd = (1 - m) / t.zoom;
  t.panx += 2 * e.offsetX * zoomd;
  t.pany += 2 * e.offsetY * zoomd;
  redrawCanvas(layerdict);
  console.log(layerdict.transform.zoom);
}

function addMouseHandlers(div, layerdict) {
  div.onmousedown = function(e) {
    handleMouseDown(e, layerdict);
  };
  div.onmousemove = function(e) {
    handleMouseMove(e, layerdict);
  };
  div.onmouseup = function(e) {
    handleMouseUp(e, layerdict);
  };
  div.onmouseout = function(e) {
    handleMouseUp(e, layerdict);
  }
  div.onwheel = function(e) {
    handleMouseWheel(e, layerdict);
  }
  for (var element of [div, layerdict.bg, layerdict.silk, layerdict.highlight]) {
    element.addEventListener("contextmenu", function(e) {
      e.preventDefault();
    }, false);
  }
}

function setBoardRotation(value) {
  boardRotation = value * 5;
  globalData.writeStorage("boardRotation", boardRotation);
  document.getElementById("rotationDegree").textContent = boardRotation;
  resizeAll();
}

function initRender() {
  allcanvas = {
    front: {
      transform: {
        x: 0,
        y: 0,
        s: 1,
        panx: 0,
        pany: 0,
        zoom: 1,
        mousestartx: 0,
        mousestarty: 0,
        mousedown: false,
      },
      bg: document.getElementById("F_bg"),
      silk: document.getElementById("F_slk"),
      highlight: document.getElementById("F_hl"),
      layer: "F",
    },
    back: {
      transform: {
        x: 0,
        y: 0,
        s: 1,
        panx: 0,
        pany: 0,
        zoom: 1,
        mousestartx: 0,
        mousestarty: 0,
        mousedown: false,
      },
      bg: document.getElementById("B_bg"),
      silk: document.getElementById("B_slk"),
      highlight: document.getElementById("B_hl"),
      layer: "B",
    }
  };
  addMouseHandlers(document.getElementById("frontcanvas"), allcanvas.front);
  addMouseHandlers(document.getElementById("backcanvas"), allcanvas.back);
}

module.exports = {
  resizeAll,
  initRender,
  redrawCanvas,
  drawHighlights,
  setBoardRotation
};
},{"./global.js":1}],7:[function(require,module,exports){
/*
  Split.js - v1.3.5
  MIT License
  https://github.com/nathancahill/Split.js
*/
!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):e.Split=t()}(this,function(){"use strict";var e=window,t=e.document,n="addEventListener",i="removeEventListener",r="getBoundingClientRect",s=function(){return!1},o=e.attachEvent&&!e[n],a=["","-webkit-","-moz-","-o-"].filter(function(e){var n=t.createElement("div");return n.style.cssText="width:"+e+"calc(9px)",!!n.style.length}).shift()+"calc",l=function(e){return"string"==typeof e||e instanceof String?t.querySelector(e):e};return function(u,c){function z(e,t,n){var i=A(y,t,n);Object.keys(i).forEach(function(t){return e.style[t]=i[t]})}function h(e,t){var n=B(y,t);Object.keys(n).forEach(function(t){return e.style[t]=n[t]})}function f(e){var t=E[this.a],n=E[this.b],i=t.size+n.size;t.size=e/this.size*i,n.size=i-e/this.size*i,z(t.element,t.size,this.aGutterSize),z(n.element,n.size,this.bGutterSize)}function m(e){var t;this.dragging&&((t="touches"in e?e.touches[0][b]-this.start:e[b]-this.start)<=E[this.a].minSize+M+this.aGutterSize?t=E[this.a].minSize+this.aGutterSize:t>=this.size-(E[this.b].minSize+M+this.bGutterSize)&&(t=this.size-(E[this.b].minSize+this.bGutterSize)),f.call(this,t),c.onDrag&&c.onDrag())}function g(){var e=E[this.a].element,t=E[this.b].element;this.size=e[r]()[y]+t[r]()[y]+this.aGutterSize+this.bGutterSize,this.start=e[r]()[G]}function d(){var t=this,n=E[t.a].element,r=E[t.b].element;t.dragging&&c.onDragEnd&&c.onDragEnd(),t.dragging=!1,e[i]("mouseup",t.stop),e[i]("touchend",t.stop),e[i]("touchcancel",t.stop),t.parent[i]("mousemove",t.move),t.parent[i]("touchmove",t.move),delete t.stop,delete t.move,n[i]("selectstart",s),n[i]("dragstart",s),r[i]("selectstart",s),r[i]("dragstart",s),n.style.userSelect="",n.style.webkitUserSelect="",n.style.MozUserSelect="",n.style.pointerEvents="",r.style.userSelect="",r.style.webkitUserSelect="",r.style.MozUserSelect="",r.style.pointerEvents="",t.gutter.style.cursor="",t.parent.style.cursor=""}function S(t){var i=this,r=E[i.a].element,o=E[i.b].element;!i.dragging&&c.onDragStart&&c.onDragStart(),t.preventDefault(),i.dragging=!0,i.move=m.bind(i),i.stop=d.bind(i),e[n]("mouseup",i.stop),e[n]("touchend",i.stop),e[n]("touchcancel",i.stop),i.parent[n]("mousemove",i.move),i.parent[n]("touchmove",i.move),r[n]("selectstart",s),r[n]("dragstart",s),o[n]("selectstart",s),o[n]("dragstart",s),r.style.userSelect="none",r.style.webkitUserSelect="none",r.style.MozUserSelect="none",r.style.pointerEvents="none",o.style.userSelect="none",o.style.webkitUserSelect="none",o.style.MozUserSelect="none",o.style.pointerEvents="none",i.gutter.style.cursor=j,i.parent.style.cursor=j,g.call(i)}function v(e){e.forEach(function(t,n){if(n>0){var i=F[n-1],r=E[i.a],s=E[i.b];r.size=e[n-1],s.size=t,z(r.element,r.size,i.aGutterSize),z(s.element,s.size,i.bGutterSize)}})}function p(){F.forEach(function(e){e.parent.removeChild(e.gutter),E[e.a].element.style[y]="",E[e.b].element.style[y]=""})}void 0===c&&(c={});var y,b,G,E,w=l(u[0]).parentNode,D=e.getComputedStyle(w).flexDirection,U=c.sizes||u.map(function(){return 100/u.length}),k=void 0!==c.minSize?c.minSize:100,x=Array.isArray(k)?k:u.map(function(){return k}),L=void 0!==c.gutterSize?c.gutterSize:10,M=void 0!==c.snapOffset?c.snapOffset:30,O=c.direction||"horizontal",j=c.cursor||("horizontal"===O?"ew-resize":"ns-resize"),C=c.gutter||function(e,n){var i=t.createElement("div");return i.className="gutter gutter-"+n,i},A=c.elementStyle||function(e,t,n){var i={};return"string"==typeof t||t instanceof String?i[e]=t:i[e]=o?t+"%":a+"("+t+"% - "+n+"px)",i},B=c.gutterStyle||function(e,t){return n={},n[e]=t+"px",n;var n};"horizontal"===O?(y="width","clientWidth",b="clientX",G="left","paddingLeft"):"vertical"===O&&(y="height","clientHeight",b="clientY",G="top","paddingTop");var F=[];return E=u.map(function(e,t){var i,s={element:l(e),size:U[t],minSize:x[t]};if(t>0&&(i={a:t-1,b:t,dragging:!1,isFirst:1===t,isLast:t===u.length-1,direction:O,parent:w},i.aGutterSize=L,i.bGutterSize=L,i.isFirst&&(i.aGutterSize=L/2),i.isLast&&(i.bGutterSize=L/2),"row-reverse"===D||"column-reverse"===D)){var a=i.a;i.a=i.b,i.b=a}if(!o&&t>0){var c=C(t,O);h(c,L),c[n]("mousedown",S.bind(i)),c[n]("touchstart",S.bind(i)),w.insertBefore(c,s.element),i.gutter=c}0===t||t===u.length-1?z(s.element,s.size,L/2):z(s.element,s.size,L);var f=s.element[r]()[y];return f<s.minSize&&(s.minSize=f),t>0&&F.push(i),s}),o?{setSizes:v,destroy:p}:{setSizes:v,getSizes:function(){return E.map(function(e){return e.size})},collapse:function(e){if(e===F.length){var t=F[e-1];g.call(t),o||f.call(t,t.size-t.bGutterSize)}else{var n=F[e];g.call(n),o||f.call(n,n.aGutterSize)}},destroy:p}}});

},{}]},{},[5,3,6,2,4,7])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJzcmMvZ2xvYmFsLmpzIiwic3JjL2h0bWxGdW5jdGlvbnMuanMiLCJzcmMvaWJvbS5qcyIsInNyYy9wY2IuanMiLCJzcmMvcGNiZm9udC5qcyIsInNyYy9yZW5kZXIuanMiLCJ2ZW5kZXIvc3BsaXQuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNqWEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaEdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2g1QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2hMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbCtEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3RsQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbigpe2Z1bmN0aW9uIHIoZSxuLHQpe2Z1bmN0aW9uIG8oaSxmKXtpZighbltpXSl7aWYoIWVbaV0pe3ZhciBjPVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmU7aWYoIWYmJmMpcmV0dXJuIGMoaSwhMCk7aWYodSlyZXR1cm4gdShpLCEwKTt2YXIgYT1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK2krXCInXCIpO3Rocm93IGEuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixhfXZhciBwPW5baV09e2V4cG9ydHM6e319O2VbaV1bMF0uY2FsbChwLmV4cG9ydHMsZnVuY3Rpb24ocil7dmFyIG49ZVtpXVsxXVtyXTtyZXR1cm4gbyhufHxyKX0scCxwLmV4cG9ydHMscixlLG4sdCl9cmV0dXJuIG5baV0uZXhwb3J0c31mb3IodmFyIHU9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZSxpPTA7aTx0Lmxlbmd0aDtpKyspbyh0W2ldKTtyZXR1cm4gb31yZXR1cm4gcn0pKCkiLCIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAgICAgICAgICAgIEJvYXJkIFJvdGF0aW9uICAgICAgICAgICAgICAgICAgICBcclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxudmFyIHN0b3JhZ2VcclxudmFyIHN0b3JhZ2VQcmVmaXggPSAnS2lDYWRfSFRNTF9CT01fXycgKyBwY2JkYXRhLm1ldGFkYXRhLnRpdGxlICsgJ19fJyArIHBjYmRhdGEubWV0YWRhdGEucmV2aXNpb24gKyAnX18nXHJcblxyXG5mdW5jdGlvbiBpbml0U3RvcmFnZSAoa2V5KSB7XHJcbiAgdHJ5IHtcclxuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJsYW5rXCIpO1xyXG4gICAgc3RvcmFnZSA9IHdpbmRvdy5sb2NhbFN0b3JhZ2U7XHJcbiAgfSBjYXRjaCAoZSkge1xyXG4gICAgY29uc29sZS5sb2coXCJTdG9yYWdlIGluaXQgZXJyb3JcIik7XHJcbiAgICAvLyBsb2NhbFN0b3JhZ2Ugbm90IGF2YWlsYWJsZVxyXG4gIH1cclxuICBpZiAoIXN0b3JhZ2UpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHdpbmRvdy5zZXNzaW9uU3RvcmFnZS5nZXRJdGVtKFwiYmxhbmtcIik7XHJcbiAgICAgIHN0b3JhZ2UgPSB3aW5kb3cuc2Vzc2lvblN0b3JhZ2U7XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIC8vIHNlc3Npb25TdG9yYWdlIGFsc28gbm90IGF2YWlsYWJsZVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcmVhZFN0b3JhZ2Uoa2V5KSB7XHJcbiAgaWYgKHN0b3JhZ2UpIHtcclxuICAgIHJldHVybiBzdG9yYWdlLmdldEl0ZW0oc3RvcmFnZVByZWZpeCArICcjJyArIGtleSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gd3JpdGVTdG9yYWdlKGtleSwgdmFsdWUpIHtcclxuICBpZiAoc3RvcmFnZSkge1xyXG4gICAgc3RvcmFnZS5zZXRJdGVtKHN0b3JhZ2VQcmVmaXggKyAnIycgKyBrZXksIHZhbHVlKTtcclxuICB9XHJcbn1cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAgICAgICAgICAgIEhpZ2hsaWdodGVkIFJlZnMgICAgICAgICAgICAgICAgICAgIFxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG52YXIgaGlnaGxpZ2h0ZWRSZWZzID0gW107XHJcblxyXG5mdW5jdGlvbiBzZXRIaWdobGlnaHRlZFJlZnMocmVmcyl7XHJcbiAgICBoaWdobGlnaHRlZFJlZnMgPSByZWZzO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRIaWdobGlnaHRlZFJlZnMoKXtcclxuICAgIHJldHVybiBoaWdobGlnaHRlZFJlZnM7XHJcbn1cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbiAgICAgICAgICAgICAgUmVkcmF3IE9uIERyYWcgICAgICAgICAgICAgICAgICAgICAgXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbnZhciByZWRyYXdPbkRyYWcgPSB0cnVlO1xyXG5cclxuICBcclxuZnVuY3Rpb24gc2V0UmVkcmF3T25EcmFnKHZhbHVlKXtcclxuICAgIHJlZHJhd09uRHJhZyA9IHZhbHVlO1xyXG4gICAgd3JpdGVTdG9yYWdlKFwicmVkcmF3T25EcmFnXCIsIHZhbHVlKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0UmVkcmF3T25EcmFnKCl7XHJcbiAgICByZXR1cm4gcmVkcmF3T25EcmFnO1xyXG59XHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuQk9NIFNwbGl0XHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbnZhciBib21zcGxpdDtcclxuXHJcbmZ1bmN0aW9uIHNldEJvbVNwbGl0KHZhbHVlKXtcclxuICAgIGJvbXNwbGl0ID0gdmFsdWU7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldEJvbVNwbGl0KCl7XHJcbiAgICByZXR1cm4gYm9tc3BsaXQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRlc3Ryb3lCb21TcGxpdCgpe1xyXG4gICAgYm9tc3BsaXQuZGVzdHJveSgpXHJcbn1cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG5DYW52YXMgU3BsaXRcclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxudmFyIGNhbnZhc3NwbGl0O1xyXG5cclxuZnVuY3Rpb24gc2V0Q2FudmFzU3BsaXQodmFsdWUpe1xyXG4gICAgY2FudmFzc3BsaXQgPSB2YWx1ZTtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0Q2FudmFzU3BsaXQoKXtcclxuICAgIHJldHVybiBjYW52YXNzcGxpdDtcclxufVxyXG5cclxuZnVuY3Rpb24gZGVzdHJveUNhbnZhc1NwbGl0KCl7XHJcbiAgICBjYW52YXNzcGxpdC5kZXN0cm95KClcclxufVxyXG5cclxuZnVuY3Rpb24gY29sbGFwc2VDYW52YXNTcGxpdCh2YWx1ZSlcclxue1xyXG4gICAgY2FudmFzc3BsaXQuY29sbGFwc2UodmFsdWUpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzZXRTaXplc0NhbnZhc1NwbGl0KHZhbHVlKXtcclxuICAgIGNhbnZhc3NwbGl0LnNldFNpemVzKFs1MCwgNTBdKTtcclxufVxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkNhbnZhcyBMYXlvdXRcclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxudmFyIGNhbnZhc2xheW91dCA9IFwiRkJcIjtcclxuXHJcbi8qWFhYIEZvdW5kIGEgYnVnIGF0IHN0YXJ0dXAuIENvZGUgYXNzdW1lcyB0aGF0IGNhbnZhcyBsYXlvdXQgXHJcbmlzIGluIG9uZSBvZiB0aHJlZSBzdGF0ZXMuIHRoZW4gc3lzdGVtIGZhaWxzLiBoZSBidWcgd2FzIHRoYXQgdGhlIFxyXG5jYW52YXNMYXlvdXQgd2FzIGJlaW5nIHNldCB0byAnZGVmYXVsdCcgd2hpY2ggaXMgbm90IGEgdmFsaWQgc3RhdGUuIFxyXG5TbyBubyBpcyBjaGVjayB0aGF0IGlmIGRlZmF1bHQgaXMgc2VudCBpbiB0aGVuIHNldCB0aGUgbGF5b3V0IHRvIEZCIG1vZGUuXHJcbiovXHJcbi8qIFRPRE86IE1ha2UgdGhlIGRlZmF1bHQgY2hlY2sgYmVsb3cgYWN0dWFsbHkgY2hlY2sgdGhhdCB0aGUgaXRlbSBcclxuaXMgaW4gb25lIG9mIHRoZSB0aHJlZSB2YWxpZCBzdGF0ZXMuIElmIG5vdCB0aGVuIHNldCB0byBGQiwgb3RoZXJ3aXNlIHNldCB0byBvbmUgb2ZcclxudGhlIHRocmVlIHZhbGlkIHN0YXRlc1xyXG4qL1xyXG5mdW5jdGlvbiBzZXRDYW52YXNMYXlvdXQodmFsdWUpe1xyXG4gICAgaWYodmFsdWUgPT0gJ2RlZmF1bHQnKXtcclxuICAgICAgICBjYW52YXNsYXlvdXQgPSAnRkInXHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgICBjYW52YXNsYXlvdXQgPSB2YWx1ZTtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0Q2FudmFzTGF5b3V0KCl7XHJcbiAgICByZXR1cm4gY2FudmFzbGF5b3V0O1xyXG59XHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuQk9NIExheW91dFxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG52YXIgYm9tbGF5b3V0ID0gXCJkZWZhdWx0XCI7XHJcblxyXG5mdW5jdGlvbiBzZXRCb21MYXlvdXQodmFsdWUpe1xyXG4gICAgYm9tbGF5b3V0ID0gdmFsdWU7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldEJvbUxheW91dCgpe1xyXG4gICAgcmV0dXJuIGJvbWxheW91dDtcclxufVxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkJPTSBTb3J0IEZ1bmN0aW9uXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbnZhciBib21Tb3J0RnVuY3Rpb24gPSBudWxsO1xyXG5cclxuZnVuY3Rpb24gc2V0Qm9tU29ydEZ1bmN0aW9uKHZhbHVlKXtcclxuICAgIGJvbVNvcnRGdW5jdGlvbiA9IHZhbHVlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRCb21Tb3J0RnVuY3Rpb24oKXtcclxuICAgIHJldHVybiBib21Tb3J0RnVuY3Rpb247XHJcbn1cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG5DdXJyZW50IFNvcnQgQ29sdW1uXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbnZhciBjdXJyZW50U29ydENvbHVtbiA9IG51bGw7XHJcblxyXG5mdW5jdGlvbiBzZXRDdXJyZW50U29ydENvbHVtbih2YWx1ZSl7XHJcbiAgICBjdXJyZW50U29ydENvbHVtbiA9IHZhbHVlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRDdXJyZW50U29ydENvbHVtbigpe1xyXG4gICAgcmV0dXJuIGN1cnJlbnRTb3J0Q29sdW1uO1xyXG59XHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuQ3VycmVudCBTb3J0IE9yZGVyXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbnZhciBjdXJyZW50U29ydE9yZGVyID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHNldEN1cnJlbnRTb3J0T3JkZXIodmFsdWUpe1xyXG4gICAgY3VycmVudFNvcnRPcmRlciA9IHZhbHVlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRDdXJyZW50U29ydE9yZGVyKCl7XHJcbiAgICByZXR1cm4gY3VycmVudFNvcnRPcmRlcjtcclxufVxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkN1cnJlbnQgSGlnaGxpZ2h0ZWQgUm93IElEXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbnZhciBjdXJyZW50SGlnaGxpZ2h0ZWRSb3dJZDtcclxuXHJcbmZ1bmN0aW9uIHNldEN1cnJlbnRIaWdobGlnaHRlZFJvd0lkKHZhbHVlKXtcclxuICAgIGN1cnJlbnRIaWdobGlnaHRlZFJvd0lkID0gdmFsdWU7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldEN1cnJlbnRIaWdobGlnaHRlZFJvd0lkKCl7XHJcbiAgICByZXR1cm4gY3VycmVudEhpZ2hsaWdodGVkUm93SWQ7XHJcbn1cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG5IaWdobGlnaHQgSGFuZGxlcnNcclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxudmFyIGhpZ2hsaWdodEhhbmRsZXJzID0gW107XHJcblxyXG5mdW5jdGlvbiBzZXRIaWdobGlnaHRIYW5kbGVycyh2YWx1ZXMpe1xyXG4gICAgaGlnaGxpZ2h0SGFuZGxlcnMgPSB2YWx1ZXM7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldEhpZ2hsaWdodEhhbmRsZXJzKCl7XHJcbiAgICByZXR1cm4gaGlnaGxpZ2h0SGFuZGxlcnM7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHB1c2hIaWdobGlnaHRIYW5kbGVycyh2YWx1ZSl7XHJcbiAgICBoaWdobGlnaHRIYW5kbGVycy5wdXNoKHZhbHVlKTtcclxufVxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkNoZWNrYm94ZXNcclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxudmFyIGNoZWNrYm94ZXMgPSBbXTtcclxuXHJcbmZ1bmN0aW9uIHNldENoZWNrYm94ZXModmFsdWVzKXtcclxuICAgIGNoZWNrYm94ZXMgPSB2YWx1ZXM7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldENoZWNrYm94ZXMoKXtcclxuICAgIHJldHVybiBjaGVja2JveGVzO1xyXG59XHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuQk9NIENoZWNrYm94ZXNcclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxudmFyIGJvbUNoZWNrYm94ZXMgPSBcIlwiO1xyXG5cclxuZnVuY3Rpb24gc2V0Qm9tQ2hlY2tib3hlcyh2YWx1ZXMpe1xyXG4gICAgYm9tQ2hlY2tib3hlcyA9IHZhbHVlcztcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0Qm9tQ2hlY2tib3hlcygpe1xyXG4gICAgcmV0dXJuIGJvbUNoZWNrYm94ZXM7XHJcbn1cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcblJlbW92ZSBCT00gRW50cmllc1xyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG52YXIgcmVtb3ZlQk9NRW50cmllcyA9IFwiXCI7XHJcblxyXG5mdW5jdGlvbiBzZXRSZW1vdmVCT01FbnRyaWVzKHZhbHVlcyl7XHJcbiAgICByZW1vdmVCT01FbnRyaWVzID0gdmFsdWVzO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRSZW1vdmVCT01FbnRyaWVzKCl7XHJcbiAgICByZXR1cm4gcmVtb3ZlQk9NRW50cmllcztcclxufVxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcblJlbW92ZSBCT00gRW50cmllc1xyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG52YXIgYWRkaXRpb25hbEF0dHJpYnV0ZXMgPSBcIlwiO1xyXG5cclxuZnVuY3Rpb24gc2V0QWRkaXRpb25hbEF0dHJpYnV0ZXModmFsdWVzKXtcclxuICAgIGFkZGl0aW9uYWxBdHRyaWJ1dGVzID0gdmFsdWVzO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRBZGRpdGlvbmFsQXR0cmlidXRlcygpe1xyXG4gICAgcmV0dXJuIGFkZGl0aW9uYWxBdHRyaWJ1dGVzO1xyXG59XHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuSGlnaGxpZ2h0IFBpbiAxXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbnZhciBoaWdobGlnaHRwaW4xID0gZmFsc2U7XHJcblxyXG5mdW5jdGlvbiBzZXRIaWdobGlnaHRQaW4xKHZhbHVlKSB7XHJcbiAgd3JpdGVTdG9yYWdlKFwiaGlnaGxpZ2h0cGluMVwiLCB2YWx1ZSk7XHJcbiAgaGlnaGxpZ2h0cGluMSA9IHZhbHVlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRIaWdobGlnaHRQaW4xKCl7XHJcbiAgICByZXR1cm4gaGlnaGxpZ2h0cGluMTtcclxufVxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkxhc3QgQ2xpY2tlZCBSZWZcclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxudmFyIGxhc3RDbGlja2VkUmVmO1xyXG5cclxuZnVuY3Rpb24gc2V0TGFzdENsaWNrZWRSZWYodmFsdWUpIHtcclxuICAgIGxhc3RDbGlja2VkUmVmID0gdmFsdWU7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldExhc3RDbGlja2VkUmVmKCkge1xyXG4gIHJldHVybiBsYXN0Q2xpY2tlZFJlZjtcclxufVxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG5Db21iaW5lIFZhbHVlc1xyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG52YXIgY29tYmluZVZhbHVlcyA9IGZhbHNlO1xyXG5cclxuZnVuY3Rpb24gc2V0Q29tYmluZVZhbHVlcyh2YWx1ZSkge1xyXG4gIHdyaXRlU3RvcmFnZShcImNvbWJpbmVWYWx1ZXNcIiwgdmFsdWUpO1xyXG4gIGNvbWJpbmVWYWx1ZXMgPSB2YWx1ZTtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0Q29tYmluZVZhbHVlcygpe1xyXG4gICAgcmV0dXJuIGNvbWJpbmVWYWx1ZXM7XHJcbn1cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IHtcclxuICBpbml0U3RvcmFnZSAgICAgICAgICAgICAgICAsIHJlYWRTdG9yYWdlICAgICAgICAgICAgICAgICwgd3JpdGVTdG9yYWdlICAgICAgICxcclxuICBzZXRIaWdobGlnaHRlZFJlZnMgICAgICAgICAsIGdldEhpZ2hsaWdodGVkUmVmcyAgICAgICAgICxcclxuICBzZXRSZWRyYXdPbkRyYWcgICAgICAgICAgICAsIGdldFJlZHJhd09uRHJhZyAgICAgICAgICAgICxcclxuICBzZXRCb21TcGxpdCAgICAgICAgICAgICAgICAsIGdldEJvbVNwbGl0ICAgICAgICAgICAgICAgICwgZGVzdHJveUJvbVNwbGl0ICAgICxcclxuICBzZXRDYW52YXNTcGxpdCAgICAgICAgICAgICAsIGdldENhbnZhc1NwbGl0ICAgICAgICAgICAgICwgZGVzdHJveUNhbnZhc1NwbGl0ICwgY29sbGFwc2VDYW52YXNTcGxpdCAsIHNldFNpemVzQ2FudmFzU3BsaXQsXHJcbiAgc2V0Q2FudmFzTGF5b3V0ICAgICAgICAgICAgLCBnZXRDYW52YXNMYXlvdXQgICAgICAgICAgICAsXHJcbiAgc2V0Qm9tTGF5b3V0ICAgICAgICAgICAgICAgLCBnZXRCb21MYXlvdXQgICAgICAgICAgICAgICAsXHJcbiAgc2V0Qm9tU29ydEZ1bmN0aW9uICAgICAgICAgLCBnZXRCb21Tb3J0RnVuY3Rpb24gICAgICAgICAsXHJcbiAgc2V0Q3VycmVudFNvcnRDb2x1bW4gICAgICAgLCBnZXRDdXJyZW50U29ydENvbHVtbiAgICAgICAsXHJcbiAgc2V0Q3VycmVudFNvcnRPcmRlciAgICAgICAgLCBnZXRDdXJyZW50U29ydE9yZGVyICAgICAgICAsXHJcbiAgc2V0Q3VycmVudEhpZ2hsaWdodGVkUm93SWQgLCBnZXRDdXJyZW50SGlnaGxpZ2h0ZWRSb3dJZCAsXHJcbiAgc2V0SGlnaGxpZ2h0SGFuZGxlcnMgICAgICAgLCBnZXRIaWdobGlnaHRIYW5kbGVycyAgICAgICAsIHB1c2hIaWdobGlnaHRIYW5kbGVycyAsXHJcbiAgc2V0Q2hlY2tib3hlcyAgICAgICAgICAgICAgLCBnZXRDaGVja2JveGVzICAgICAgICAgICAgICAsXHJcbiAgc2V0Qm9tQ2hlY2tib3hlcyAgICAgICAgICAgLCBnZXRCb21DaGVja2JveGVzICAgICAgICAgICAsXHJcbiAgc2V0UmVtb3ZlQk9NRW50cmllcyAgICAgICAgLCBnZXRSZW1vdmVCT01FbnRyaWVzICAgICAgICAsXHJcbiAgc2V0QWRkaXRpb25hbEF0dHJpYnV0ZXMgICAgLCBnZXRBZGRpdGlvbmFsQXR0cmlidXRlcyAgICAsXHJcbiAgc2V0SGlnaGxpZ2h0UGluMSAgICAgICAgICAgLCBnZXRIaWdobGlnaHRQaW4xICAgICAgICAgICAsXHJcbiAgc2V0TGFzdENsaWNrZWRSZWYgICAgICAgICAgLCBnZXRMYXN0Q2xpY2tlZFJlZiAgICAgICAgICAsXHJcbiAgc2V0Q29tYmluZVZhbHVlcyAgICAgICAgICAgLCBnZXRDb21iaW5lVmFsdWVzXHJcblxyXG59OyIsIlxyXG52YXIgZ2xvYmFsRGF0YSA9IHJlcXVpcmUoJy4vZ2xvYmFsLmpzJylcclxudmFyIHJlbmRlciAgICAgPSByZXF1aXJlKCcuL3JlbmRlci5qcycpXHJcbnZhciBpYm9tICAgICAgID0gcmVxdWlyZSgnLi9pYm9tLmpzJylcclxuXHJcbmNvbnN0IGJvYXJkUm90YXRpb24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYm9hcmRSb3RhdGlvbicpO1xyXG5ib2FyZFJvdGF0aW9uLm9uaW5wdXQ9ZnVuY3Rpb24oKVxyXG57XHJcbiAgcmVuZGVyLnNldEJvYXJkUm90YXRpb24oYm9hcmRSb3RhdGlvbi52YWx1ZSk7XHJcbn1cclxuXHJcbmNvbnN0IGRhcmtNb2RlQm94ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2Rhcmttb2RlQ2hlY2tib3gnKTtcclxuZGFya01vZGVCb3gub25jaGFuZ2UgPSBmdW5jdGlvbiAoKSB7XHJcbiAgaWJvbS5zZXREYXJrTW9kZShkYXJrTW9kZUJveC5jaGVja2VkKVxyXG59XHJcblxyXG5jb25zdCBzaWxrc2NyZWVuQ2hlY2tib3ggPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2lsa3NjcmVlbkNoZWNrYm94Jyk7XHJcbnNpbGtzY3JlZW5DaGVja2JveC5jaGVja2VkPWZ1bmN0aW9uKCl7XHJcbiAgaWJvbS5zaWxrc2NyZWVuVmlzaWJsZShzaWxrc2NyZWVuQ2hlY2tib3guY2hlY2tlZClcclxufVxyXG5zaWxrc2NyZWVuQ2hlY2tib3gub25jaGFuZ2U9ZnVuY3Rpb24oKXtcclxuICBpYm9tLnNpbGtzY3JlZW5WaXNpYmxlKHNpbGtzY3JlZW5DaGVja2JveC5jaGVja2VkKVxyXG59XHJcblxyXG5jb25zdCBoaWdobGlnaHRwaW4xQ2hlY2tib3ggPWRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdoaWdobGlnaHRwaW4xQ2hlY2tib3gnKTtcclxuaGlnaGxpZ2h0cGluMUNoZWNrYm94Lm9uY2hhbmdlPWZ1bmN0aW9uKCl7XHJcbiAgZ2xvYmFsRGF0YS5zZXRIaWdobGlnaHRQaW4xKGhpZ2hsaWdodHBpbjFDaGVja2JveC5jaGVja2VkKTtcclxuICByZW5kZXIucmVkcmF3Q2FudmFzKGFsbGNhbnZhcy5mcm9udCk7XHJcbiAgcmVuZGVyLnJlZHJhd0NhbnZhcyhhbGxjYW52YXMuYmFjayk7XHJcbn1cclxuXHJcbmNvbnN0IGRyYWdDaGVja2JveCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkcmFnQ2hlY2tib3gnKTtcclxuZHJhZ0NoZWNrYm94LmNoZWNrZWQ9ZnVuY3Rpb24oKXtcclxuICBnbG9iYWxEYXRhLnNldFJlZHJhd09uRHJhZyhkcmFnQ2hlY2tib3guY2hlY2tlZClcclxufVxyXG5kcmFnQ2hlY2tib3gub25jaGFuZ2U9ZnVuY3Rpb24oKXtcclxuICBnbG9iYWxEYXRhLnNldFJlZHJhd09uRHJhZyhkcmFnQ2hlY2tib3guY2hlY2tlZClcclxufVxyXG5cclxuXHJcbmNvbnN0IGNvbWJpbmVWYWx1ZXMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnY29tYmluZVZhbHVlcycpO1xyXG5jb21iaW5lVmFsdWVzLm9uY2hhbmdlPWZ1bmN0aW9uKCl7XHJcbiAgZ2xvYmFsRGF0YS5zZXRDb21iaW5lVmFsdWVzKGNvbWJpbmVWYWx1ZXMuY2hlY2tlZCk7XHJcbiAgaWJvbS5wb3B1bGF0ZUJvbVRhYmxlKCk7XHJcbn1cclxuXHJcbmNvbnN0IGZpbHRlciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdmaWx0ZXInKTtcclxuZmlsdGVyLm9uaW5wdXQ9ZnVuY3Rpb24oKXtcclxuICBpYm9tLnNldEZpbHRlcihmaWx0ZXIudmFsdWUpXHJcbn1cclxuXHJcbmNvbnN0IGJvbUNoZWNrYm94ZXMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYm9tQ2hlY2tib3hlcycpO1xyXG5ib21DaGVja2JveGVzLm9uaW5wdXQ9ZnVuY3Rpb24oKXtcclxuICBpYm9tLnNldEJvbUNoZWNrYm94ZXMoYm9tQ2hlY2tib3hlcy52YWx1ZSk7XHJcbn1cclxuXHJcbmNvbnN0IHJlbW92ZUJPTUVudHJpZXMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmVtb3ZlQk9NRW50cmllcycpO1xyXG5yZW1vdmVCT01FbnRyaWVzLm9uaW5wdXQ9ZnVuY3Rpb24oKXtcclxuICBpYm9tLnNldFJlbW92ZUJPTUVudHJpZXMocmVtb3ZlQk9NRW50cmllcy52YWx1ZSk7XHJcbn1cclxuXHJcbmNvbnN0IGFkZGl0aW9uYWxBdHRyaWJ1dGVzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FkZGl0aW9uYWxBdHRyaWJ1dGVzJyk7XHJcbmFkZGl0aW9uYWxBdHRyaWJ1dGVzLm9uaW5wdXQ9ZnVuY3Rpb24oKXtcclxuICBpYm9tLnNldEFkZGl0aW9uYWxBdHRyaWJ1dGVzKGFkZGl0aW9uYWxBdHRyaWJ1dGVzLnZhbHVlKTtcclxufVxyXG5cclxuY29uc3QgZmxfYnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2ZsLWJ0bicpO1xyXG5mbF9idG4ub25jbGljaz1mdW5jdGlvbigpe1xyXG4gIGlib20uY2hhbmdlQ2FudmFzTGF5b3V0KCdGJyk7XHJcbn1cclxuXHJcbmNvbnN0IGZiX2J0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdmYi1idG4nKTtcclxuZmJfYnRuLm9uY2xpY2s9ZnVuY3Rpb24oKXtcclxuICBpYm9tLmNoYW5nZUNhbnZhc0xheW91dCgnRkInKTtcclxufVxyXG5cclxuXHJcbmNvbnN0IGJsX2J0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdibC1idG4nKTtcclxuYmxfYnRuLm9uY2xpY2s9ZnVuY3Rpb24oKXtcclxuICBpYm9tLmNoYW5nZUNhbnZhc0xheW91dCgnQicpO1xyXG59XHJcblxyXG5jb25zdCBib21fYnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2JvbS1idG4nKTtcclxuYm9tX2J0bi5vbmNsaWNrPWZ1bmN0aW9uKCl7XHJcbiAgaWJvbS5jaGFuZ2VCb21MYXlvdXQoJ0JPTScpXHJcbn1cclxuXHJcbmNvbnN0IGxyX2J0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsci1idG4nKTtcclxubHJfYnRuLm9uY2xpY2s9ZnVuY3Rpb24oKXtcclxuICBpYm9tLmNoYW5nZUJvbUxheW91dCgnTFInKVxyXG59XHJcblxyXG5jb25zdCB0Yl9idG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGItYnRuJyk7XHJcbnRiX2J0bi5vbmNsaWNrPWZ1bmN0aW9uKCl7XHJcbiAgaWJvbS5jaGFuZ2VCb21MYXlvdXQoJ1RCJylcclxufVxyXG4iLCIvKiBET00gbWFuaXB1bGF0aW9uIGFuZCBtaXNjIGNvZGUgKi9cclxuXHJcblxyXG52YXIgU3BsaXQgPSByZXF1aXJlKCcuLi92ZW5kZXIvc3BsaXQuanMnKVxyXG52YXIgZ2xvYmFsRGF0YSA9IHJlcXVpcmUoJy4vZ2xvYmFsLmpzJylcclxudmFyIHJlbmRlciA9IHJlcXVpcmUoJy4vcmVuZGVyLmpzJylcclxudmFyIHBjYiAgICA9IHJlcXVpcmUoJy4vcGNiLmpzJylcclxuXHJcblxyXG4vL1RPRE86ICBHTE9CQUwgVkFSSUFCTEUgUkVGQUNUT1JcclxudmFyIGZpbHRlciA9IFwiXCI7XHJcbmZ1bmN0aW9uIGdldEZpbHRlcihpbnB1dCkge1xyXG4gIHJldHVybiBmaWx0ZXI7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNldEZpbHRlcihpbnB1dCkge1xyXG4gIGZpbHRlciA9IGlucHV0LnRvTG93ZXJDYXNlKCk7XHJcbiAgcG9wdWxhdGVCb21UYWJsZSgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBkYmcoaHRtbCkge1xyXG4gIGRiZ2Rpdi5pbm5lckhUTUwgPSBodG1sO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzZXREYXJrTW9kZSh2YWx1ZSkge1xyXG4gIGlmICh2YWx1ZSkge1xyXG4gICAgdG9wbW9zdGRpdi5jbGFzc0xpc3QuYWRkKFwiZGFya1wiKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdG9wbW9zdGRpdi5jbGFzc0xpc3QucmVtb3ZlKFwiZGFya1wiKTtcclxuICB9XHJcbiAgZ2xvYmFsRGF0YS53cml0ZVN0b3JhZ2UoXCJkYXJrbW9kZVwiLCB2YWx1ZSk7XHJcbiAgcmVuZGVyLnJlZHJhd0NhbnZhcyhhbGxjYW52YXMuZnJvbnQpO1xyXG4gIHJlbmRlci5yZWRyYXdDYW52YXMoYWxsY2FudmFzLmJhY2spO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRTdG9yZWRDaGVja2JveFJlZnMoY2hlY2tib3gpIHtcclxuICB2YXIgZXhpc3RpbmdSZWZzID0gZ2xvYmFsRGF0YS5yZWFkU3RvcmFnZShcImNoZWNrYm94X1wiICsgY2hlY2tib3gpO1xyXG4gIGlmICghZXhpc3RpbmdSZWZzKSB7XHJcbiAgICByZXR1cm4gbmV3IFNldCgpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gbmV3IFNldChleGlzdGluZ1JlZnMuc3BsaXQoXCIsXCIpKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldENoZWNrYm94U3RhdGUoY2hlY2tib3gsIHJlZmVyZW5jZXMpIHtcclxuICB2YXIgc3RvcmVkUmVmc1NldCA9IGdldFN0b3JlZENoZWNrYm94UmVmcyhjaGVja2JveCk7XHJcbiAgdmFyIGN1cnJlbnRSZWZzU2V0ID0gbmV3IFNldChyZWZlcmVuY2VzKTtcclxuICAvLyBHZXQgZGlmZmVyZW5jZSBvZiBjdXJyZW50IC0gc3RvcmVkXHJcbiAgdmFyIGRpZmZlcmVuY2UgPSBuZXcgU2V0KGN1cnJlbnRSZWZzU2V0KTtcclxuICBmb3IgKHJlZiBvZiBzdG9yZWRSZWZzU2V0KSB7XHJcbiAgICBkaWZmZXJlbmNlLmRlbGV0ZShyZWYpO1xyXG4gIH1cclxuICBpZiAoZGlmZmVyZW5jZS5zaXplID09IDApIHtcclxuICAgIC8vIEFsbCB0aGUgY3VycmVudCByZWZzIGFyZSBzdG9yZWRcclxuICAgIHJldHVybiBcImNoZWNrZWRcIjtcclxuICB9IGVsc2UgaWYgKGRpZmZlcmVuY2Uuc2l6ZSA9PSBjdXJyZW50UmVmc1NldC5zaXplKSB7XHJcbiAgICAvLyBOb25lIG9mIHRoZSBjdXJyZW50IHJlZnMgYXJlIHN0b3JlZFxyXG4gICAgcmV0dXJuIFwidW5jaGVja2VkXCI7XHJcbiAgfSBlbHNlIHtcclxuICAgIC8vIFNvbWUgb2YgdGhlIHJlZnMgYXJlIHN0b3JlZFxyXG4gICAgcmV0dXJuIFwiaW5kZXRlcm1pbmF0ZVwiO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gc2V0Qm9tQ2hlY2tib3hTdGF0ZShjaGVja2JveCwgZWxlbWVudCwgcmVmZXJlbmNlcykge1xyXG4gIHZhciBzdGF0ZSA9IGdldENoZWNrYm94U3RhdGUoY2hlY2tib3gsIHJlZmVyZW5jZXMpO1xyXG4gIGVsZW1lbnQuY2hlY2tlZCA9IChzdGF0ZSA9PSBcImNoZWNrZWRcIik7XHJcbiAgZWxlbWVudC5pbmRldGVybWluYXRlID0gKHN0YXRlID09IFwiaW5kZXRlcm1pbmF0ZVwiKTtcclxufVxyXG5cclxuZnVuY3Rpb24gY3JlYXRlQ2hlY2tib3hDaGFuZ2VIYW5kbGVyKGNoZWNrYm94LCByZWZlcmVuY2VzKSB7XHJcbiAgcmV0dXJuIGZ1bmN0aW9uKCkge1xyXG4gICAgcmVmc1NldCA9IGdldFN0b3JlZENoZWNrYm94UmVmcyhjaGVja2JveCk7XHJcbiAgICBpZiAodGhpcy5jaGVja2VkKSB7XHJcbiAgICAgIC8vIGNoZWNrYm94IHRpY2tlZFxyXG4gICAgICBmb3IgKHZhciByZWYgb2YgcmVmZXJlbmNlcykge1xyXG4gICAgICAgIHJlZnNTZXQuYWRkKHJlZik7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIC8vIGNoZWNrYm94IHVudGlja2VkXHJcbiAgICAgIGZvciAodmFyIHJlZiBvZiByZWZlcmVuY2VzKSB7XHJcbiAgICAgICAgcmVmc1NldC5kZWxldGUocmVmKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgZ2xvYmFsRGF0YS53cml0ZVN0b3JhZ2UoXCJjaGVja2JveF9cIiArIGNoZWNrYm94LCBbLi4ucmVmc1NldF0uam9pbihcIixcIikpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gY3JlYXRlUm93SGlnaGxpZ2h0SGFuZGxlcihyb3dpZCwgcmVmcykge1xyXG4gIHJldHVybiBmdW5jdGlvbigpIHtcclxuICAgIGlmIChnbG9iYWxEYXRhLmdldEN1cnJlbnRIaWdobGlnaHRlZFJvd0lkKCkpIHtcclxuICAgICAgaWYgKGdsb2JhbERhdGEuZ2V0Q3VycmVudEhpZ2hsaWdodGVkUm93SWQoKSA9PSByb3dpZCkge1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChnbG9iYWxEYXRhLmdldEN1cnJlbnRIaWdobGlnaHRlZFJvd0lkKCkpLmNsYXNzTGlzdC5yZW1vdmUoXCJoaWdobGlnaHRlZFwiKTtcclxuICAgIH1cclxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHJvd2lkKS5jbGFzc0xpc3QuYWRkKFwiaGlnaGxpZ2h0ZWRcIik7XHJcbiAgICBnbG9iYWxEYXRhLnNldEN1cnJlbnRIaWdobGlnaHRlZFJvd0lkKHJvd2lkKTtcclxuICAgIGdsb2JhbERhdGEuc2V0SGlnaGxpZ2h0ZWRSZWZzKHJlZnMpO1xyXG4gICAgcmVuZGVyLmRyYXdIaWdobGlnaHRzKCk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBlbnRyeU1hdGNoZXMocGFydCkge1xyXG4gIC8vIGNoZWNrIHJlZnNcclxuICBpZiAocGFydC5yZWZlcmVuY2UudG9Mb3dlckNhc2UoKS5pbmRleE9mKGdldEZpbHRlcigpKSA+PSAwKSB7XHJcbiAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG4gIC8vIGNoZWNrIHZhbHVlXHJcbiAgaWYgKHBhcnQudmFsdWUudG9Mb3dlckNhc2UoKS5pbmRleE9mKGdldEZpbHRlcigpKT49IDApIHtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICAvLyBjaGVjayBmb290cHJpbnRcclxuICBpZiAocGFydC5wYWNrYWdlLnRvTG93ZXJDYXNlKCkuaW5kZXhPZihnZXRGaWx0ZXIoKSk+PSAwKSB7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcblxyXG4gIC8vIENoZWNrIHRoZSBkaXNwbGF5ZWQgYXR0cmlidXRlc1xyXG4gIHZhciBhZGRpdGlvbmFsQXR0cmlidXRlcyA9IGdsb2JhbERhdGEuZ2V0QWRkaXRpb25hbEF0dHJpYnV0ZXMoKS5zcGxpdCgnLCcpO1xyXG4gIGFkZGl0aW9uYWxBdHRyaWJ1dGVzICAgICA9IGFkZGl0aW9uYWxBdHRyaWJ1dGVzLmZpbHRlcihmdW5jdGlvbihlKXtyZXR1cm4gZX0pO1xyXG4gIGZvciAodmFyIHggb2YgYWRkaXRpb25hbEF0dHJpYnV0ZXMpIHtcclxuICAgICAgLy8gcmVtb3ZlIGJlZ2lubmluZyBhbmQgdHJhaWxpbmcgd2hpdGVzcGFjZVxyXG4gICAgICB4ID0geC50cmltKClcclxuICAgICAgaWYgKHBhcnQuYXR0cmlidXRlcy5oYXMoeCkpIHtcclxuICAgICAgICBpZihwYXJ0LmF0dHJpYnV0ZXMuZ2V0KHgpLmluZGV4T2YoZ2V0RmlsdGVyKCkpID49IDApe1xyXG4gICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gIHJldHVybiBmYWxzZTtcclxufVxyXG5cclxuXHJcbmZ1bmN0aW9uIGhpZ2hsaWdodEZpbHRlcihzKSB7XHJcbiAgaWYgKCFnZXRGaWx0ZXIoKSkge1xyXG4gICAgcmV0dXJuIHM7XHJcbiAgfVxyXG4gIHZhciBwYXJ0cyA9IHMudG9Mb3dlckNhc2UoKS5zcGxpdChnZXRGaWx0ZXIoKSk7XHJcbiAgaWYgKHBhcnRzLmxlbmd0aCA9PSAxKSB7XHJcbiAgICByZXR1cm4gcztcclxuICB9XHJcbiAgdmFyIHIgPSBcIlwiO1xyXG4gIHZhciBwb3MgPSAwO1xyXG4gIGZvciAodmFyIGkgaW4gcGFydHMpIHtcclxuICAgIGlmIChpID4gMCkge1xyXG4gICAgICByICs9ICc8bWFyayBjbGFzcz1cImhpZ2hsaWdodFwiPicgK1xyXG4gICAgICAgIHMuc3Vic3RyaW5nKHBvcywgcG9zICsgZ2V0RmlsdGVyKCkubGVuZ3RoKSArXHJcbiAgICAgICAgJzwvbWFyaz4nO1xyXG4gICAgICBwb3MgKz0gZ2V0RmlsdGVyKCkubGVuZ3RoO1xyXG4gICAgfVxyXG4gICAgciArPSBzLnN1YnN0cmluZyhwb3MsIHBvcyArIHBhcnRzW2ldLmxlbmd0aCk7XHJcbiAgICBwb3MgKz0gcGFydHNbaV0ubGVuZ3RoO1xyXG4gIH1cclxuICByZXR1cm4gcjtcclxufVxyXG5cclxuZnVuY3Rpb24gY2hlY2tib3hTZXRVbnNldEFsbEhhbmRsZXIoY2hlY2tib3huYW1lKSB7XHJcbiAgcmV0dXJuIGZ1bmN0aW9uKCkge1xyXG4gICAgdmFyIGNoZWNrYm94bnVtID0gMDtcclxuICAgIHdoaWxlIChjaGVja2JveG51bSA8IGdsb2JhbERhdGEuZ2V0Q2hlY2tib3hlcygpLmxlbmd0aCAmJlxyXG4gICAgICBnbG9iYWxEYXRhLmdldENoZWNrYm94ZXMoKVtjaGVja2JveG51bV0udG9Mb3dlckNhc2UoKSAhPSBjaGVja2JveG5hbWUudG9Mb3dlckNhc2UoKSkge1xyXG4gICAgICBjaGVja2JveG51bSsrO1xyXG4gICAgfVxyXG4gICAgaWYgKGNoZWNrYm94bnVtID49IGdsb2JhbERhdGEuZ2V0Q2hlY2tib3hlcygpLmxlbmd0aCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICB2YXIgYWxsc2V0ID0gdHJ1ZTtcclxuICAgIHZhciBjaGVja2JveDtcclxuICAgIHZhciByb3c7XHJcbiAgICBmb3IgKHJvdyBvZiBib21ib2R5LmNoaWxkTm9kZXMpIHtcclxuICAgICAgY2hlY2tib3ggPSByb3cuY2hpbGROb2Rlc1tjaGVja2JveG51bSArIDFdLmNoaWxkTm9kZXNbMF07XHJcbiAgICAgIGlmICghY2hlY2tib3guY2hlY2tlZCB8fCBjaGVja2JveC5pbmRldGVybWluYXRlKSB7XHJcbiAgICAgICAgYWxsc2V0ID0gZmFsc2U7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGZvciAocm93IG9mIGJvbWJvZHkuY2hpbGROb2Rlcykge1xyXG4gICAgICBjaGVja2JveCA9IHJvdy5jaGlsZE5vZGVzW2NoZWNrYm94bnVtICsgMV0uY2hpbGROb2Rlc1swXTtcclxuICAgICAgY2hlY2tib3guY2hlY2tlZCA9ICFhbGxzZXQ7XHJcbiAgICAgIGNoZWNrYm94LmluZGV0ZXJtaW5hdGUgPSBmYWxzZTtcclxuICAgICAgY2hlY2tib3gub25jaGFuZ2UoKTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNyZWF0ZUNvbHVtbkhlYWRlcihuYW1lLCBjbHMsIGNvbXBhcmF0b3IpIHtcclxuICB2YXIgdGggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiVEhcIik7XHJcbiAgdGguaW5uZXJIVE1MID0gbmFtZTtcclxuICB0aC5jbGFzc0xpc3QuYWRkKGNscyk7XHJcbiAgdGguc3R5bGUuY3Vyc29yID0gXCJwb2ludGVyXCI7XHJcbiAgdmFyIHNwYW4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiU1BBTlwiKTtcclxuICBzcGFuLmNsYXNzTGlzdC5hZGQoXCJzb3J0bWFya1wiKTtcclxuICBzcGFuLmNsYXNzTGlzdC5hZGQoXCJub25lXCIpO1xyXG4gIHRoLmFwcGVuZENoaWxkKHNwYW4pO1xyXG4gIHRoLm9uY2xpY2sgPSBmdW5jdGlvbigpIHtcclxuICAgIGlmIChnbG9iYWxEYXRhLmdldEN1cnJlbnRTb3J0Q29sdW1uKCkgJiYgdGhpcyAhPT0gZ2xvYmFsRGF0YS5nZXRDdXJyZW50U29ydENvbHVtbigpKSB7XHJcbiAgICAgIC8vIEN1cnJlbnRseSBzb3J0ZWQgYnkgYW5vdGhlciBjb2x1bW5cclxuICAgICAgZ2xvYmFsRGF0YS5nZXRDdXJyZW50U29ydENvbHVtbigpLmNoaWxkTm9kZXNbMV0uY2xhc3NMaXN0LnJlbW92ZShnbG9iYWxEYXRhLmdldEN1cnJlbnRTb3J0T3JkZXIoKSk7XHJcbiAgICAgIGdsb2JhbERhdGEuZ2V0Q3VycmVudFNvcnRDb2x1bW4oKS5jaGlsZE5vZGVzWzFdLmNsYXNzTGlzdC5hZGQoXCJub25lXCIpO1xyXG4gICAgICBnbG9iYWxEYXRhLnNldEN1cnJlbnRTb3J0Q29sdW1uKG51bGwpO1xyXG4gICAgICBnbG9iYWxEYXRhLnNldEN1cnJlbnRTb3J0T3JkZXIobnVsbCk7XHJcbiAgICB9XHJcbiAgICBpZiAoZ2xvYmFsRGF0YS5nZXRDdXJyZW50U29ydENvbHVtbigpICYmIHRoaXMgPT09IGdsb2JhbERhdGEuZ2V0Q3VycmVudFNvcnRDb2x1bW4oKSkge1xyXG4gICAgICAvLyBBbHJlYWR5IHNvcnRlZCBieSB0aGlzIGNvbHVtblxyXG4gICAgICBpZiAoZ2xvYmFsRGF0YS5nZXRDdXJyZW50U29ydE9yZGVyKCkgPT0gXCJhc2NcIikge1xyXG4gICAgICAgIC8vIFNvcnQgYnkgdGhpcyBjb2x1bW4sIGRlc2NlbmRpbmcgb3JkZXJcclxuICAgICAgICBnbG9iYWxEYXRhLnNldEJvbVNvcnRGdW5jdGlvbihmdW5jdGlvbihhLCBiKSB7XHJcbiAgICAgICAgICByZXR1cm4gLWNvbXBhcmF0b3IoYSwgYik7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgZ2xvYmFsRGF0YS5nZXRDdXJyZW50U29ydENvbHVtbigpLmNoaWxkTm9kZXNbMV0uY2xhc3NMaXN0LnJlbW92ZShcImFzY1wiKTtcclxuICAgICAgICBnbG9iYWxEYXRhLmdldEN1cnJlbnRTb3J0Q29sdW1uKCkuY2hpbGROb2Rlc1sxXS5jbGFzc0xpc3QuYWRkKFwiZGVzY1wiKTtcclxuICAgICAgICBnbG9iYWxEYXRhLnNldEN1cnJlbnRTb3J0T3JkZXIoXCJkZXNjXCIpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIFVuc29ydFxyXG4gICAgICAgIGdsb2JhbERhdGEuc2V0Qm9tU29ydEZ1bmN0aW9uKG51bGwpO1xyXG4gICAgICAgIGdsb2JhbERhdGEuZ2V0Q3VycmVudFNvcnRDb2x1bW4oKS5jaGlsZE5vZGVzWzFdLmNsYXNzTGlzdC5yZW1vdmUoXCJkZXNjXCIpO1xyXG4gICAgICAgIGdsb2JhbERhdGEuZ2V0Q3VycmVudFNvcnRDb2x1bW4oKS5jaGlsZE5vZGVzWzFdLmNsYXNzTGlzdC5hZGQoXCJub25lXCIpO1xyXG4gICAgICAgIGdsb2JhbERhdGEuc2V0Q3VycmVudFNvcnRDb2x1bW4obnVsbCk7XHJcbiAgICAgICAgZ2xvYmFsRGF0YS5zZXRDdXJyZW50U29ydE9yZGVyKG51bGwpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBTb3J0IGJ5IHRoaXMgY29sdW1uLCBhc2NlbmRpbmcgb3JkZXJcclxuICAgICAgZ2xvYmFsRGF0YS5zZXRCb21Tb3J0RnVuY3Rpb24oY29tcGFyYXRvcik7XHJcbiAgICAgIGdsb2JhbERhdGEuc2V0Q3VycmVudFNvcnRDb2x1bW4odGhpcyk7XHJcbiAgICAgIGdsb2JhbERhdGEuZ2V0Q3VycmVudFNvcnRDb2x1bW4oKS5jaGlsZE5vZGVzWzFdLmNsYXNzTGlzdC5yZW1vdmUoXCJub25lXCIpO1xyXG4gICAgICBnbG9iYWxEYXRhLmdldEN1cnJlbnRTb3J0Q29sdW1uKCkuY2hpbGROb2Rlc1sxXS5jbGFzc0xpc3QuYWRkKFwiYXNjXCIpO1xyXG4gICAgICBnbG9iYWxEYXRhLnNldEN1cnJlbnRTb3J0T3JkZXIoXCJhc2NcIik7XHJcbiAgICB9XHJcbiAgICBwb3B1bGF0ZUJvbUJvZHkoKTtcclxuICB9XHJcbiAgcmV0dXJuIHRoO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmYW5jeURibENsaWNrSGFuZGxlcihlbCwgb25zaW5nbGUsIG9uZG91YmxlKSB7XHJcbiAgcmV0dXJuIGZ1bmN0aW9uKCkge1xyXG4gICAgaWYgKGVsLmdldEF0dHJpYnV0ZShcImRhdGEtZGJsY2xpY2tcIikgPT0gbnVsbCkge1xyXG4gICAgICBlbC5zZXRBdHRyaWJ1dGUoXCJkYXRhLWRibGNsaWNrXCIsIDEpO1xyXG4gICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIGlmIChlbC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRibGNsaWNrXCIpID09IDEpIHtcclxuICAgICAgICAgIG9uc2luZ2xlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsLnJlbW92ZUF0dHJpYnV0ZShcImRhdGEtZGJsY2xpY2tcIik7XHJcbiAgICAgIH0sIDIwMCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoXCJkYXRhLWRibGNsaWNrXCIpO1xyXG4gICAgICBvbmRvdWJsZSgpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcG9wdWxhdGVCb21IZWFkZXIoKSB7XHJcbiAgd2hpbGUgKGJvbWhlYWQuZmlyc3RDaGlsZCkge1xyXG4gICAgYm9taGVhZC5yZW1vdmVDaGlsZChib21oZWFkLmZpcnN0Q2hpbGQpO1xyXG4gIH1cclxuICB2YXIgdHIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiVFJcIik7XHJcbiAgdmFyIHRoID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcIlRIXCIpO1xyXG4gIHRoLmNsYXNzTGlzdC5hZGQoXCJudW1Db2xcIik7XHJcbiAgdHIuYXBwZW5kQ2hpbGQodGgpO1xyXG4gIGdsb2JhbERhdGEuc2V0Q2hlY2tib3hlcyhnbG9iYWxEYXRhLmdldEJvbUNoZWNrYm94ZXMoKS5zcGxpdChcIixcIikuZmlsdGVyKChlKSA9PiBlKSk7XHJcbiAgLy9YWFg6IFRoZXJlIGlzIHNvbWV0aGluZyB3ZWlyZCB3aXRoIHRoaXMuIFRoZSBiZWhhdmlvciBpcyB0byBzb3J0IHRoZSBidXR0b25zIGJ1dCBcclxuICAvLyBpbiB0aGUgZ3VpIGl0IGFjdGlzIGZ1bm55XHJcbiAgdmFyIGNoZWNrYm94Q29tcGFyZUNsb3N1cmUgPSBmdW5jdGlvbihjaGVja2JveCkge1xyXG4gICAgcmV0dXJuIChhLCBiKSA9PiB7XHJcbiAgICAgIHZhciBzdGF0ZUEgPSBnZXRDaGVja2JveFN0YXRlKGNoZWNrYm94LCBhWzNdKTtcclxuICAgICAgdmFyIHN0YXRlQiA9IGdldENoZWNrYm94U3RhdGUoY2hlY2tib3gsIGJbM10pO1xyXG4gICAgICBpZiAoc3RhdGVBID4gc3RhdGVCKSByZXR1cm4gLTE7XHJcbiAgICAgIGlmIChzdGF0ZUEgPCBzdGF0ZUIpIHJldHVybiAxO1xyXG4gICAgICByZXR1cm4gMDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGZvciAodmFyIGNoZWNrYm94IG9mIGdsb2JhbERhdGEuZ2V0Q2hlY2tib3hlcygpKSB7XHJcbiAgICB0aCA9IGNyZWF0ZUNvbHVtbkhlYWRlcihcclxuICAgICAgY2hlY2tib3gsIGNoZWNrYm94LCBjaGVja2JveENvbXBhcmVDbG9zdXJlKGNoZWNrYm94KSk7XHJcbiAgICB0aC5vbmNsaWNrID0gZmFuY3lEYmxDbGlja0hhbmRsZXIoXHJcbiAgICAgIHRoLCB0aC5vbmNsaWNrLmJpbmQodGgpLCBjaGVja2JveFNldFVuc2V0QWxsSGFuZGxlcihjaGVja2JveCkpO1xyXG4gICAgdHIuYXBwZW5kQ2hpbGQodGgpO1xyXG4gIH1cclxuXHJcbiAgdHIuYXBwZW5kQ2hpbGQoY3JlYXRlQ29sdW1uSGVhZGVyKFwiUmVmZXJlbmNlc1wiLCBcIlJlZmVyZW5jZXNcIiwgKHBhcnRBLCBwYXJ0QikgPT4ge1xyXG4gICAgICBpZiAocGFydEEucmVmZXJlbmNlICE9IHBhcnRCLnJlZmVyZW5jZSkgcmV0dXJuIHBhcnRBLnJlZmVyZW5jZSA+IHBhcnRCLnJlZmVyZW5jZSA/IDEgOiAtMTtcclxuICAgICAgZWxzZSByZXR1cm4gMDtcclxuICB9KSk7XHJcblxyXG4gIHRyLmFwcGVuZENoaWxkKGNyZWF0ZUNvbHVtbkhlYWRlcihcIlZhbHVlXCIsIFwiVmFsdWVcIiwgKHBhcnRBLCBwYXJ0QikgPT4ge1xyXG4gICAgaWYgKHBhcnRBLnZhbHVlICE9IHBhcnRCLnZhbHVlKSByZXR1cm4gcGFydEEudmFsdWUgPiBwYXJ0Qi52YWx1ZSA/IDEgOiAtMTtcclxuICAgIGVsc2UgcmV0dXJuIDA7XHJcbiAgfSkpO1xyXG5cclxuICB0ci5hcHBlbmRDaGlsZChjcmVhdGVDb2x1bW5IZWFkZXIoXCJGb290cHJpbnRcIiwgXCJGb290cHJpbnRcIiwgKHBhcnRBLCBwYXJ0QikgPT4ge1xyXG4gICAgaWYgKHBhcnRBLnBhY2thZ2UgIT0gcGFydEIucGFja2FnZSkgcmV0dXJuIHBhcnRBLnBhY2thZ2UgPiBwYXJ0Qi5wYWNrYWdlID8gMSA6IC0xO1xyXG4gICAgZWxzZSByZXR1cm4gMDtcclxuICB9KSk7XHJcblxyXG4gIHZhciBhZGRpdGlvbmFsQXR0cmlidXRlcyA9IGdsb2JhbERhdGEuZ2V0QWRkaXRpb25hbEF0dHJpYnV0ZXMoKS5zcGxpdCgnLCcpO1xyXG4gIC8vIFJlbW92ZSBudWxsLCBcIlwiLCB1bmRlZmluZWQsIGFuZCAwIHZhbHVlc1xyXG4gIGFkZGl0aW9uYWxBdHRyaWJ1dGVzICAgID1hZGRpdGlvbmFsQXR0cmlidXRlcy5maWx0ZXIoZnVuY3Rpb24oZSl7cmV0dXJuIGV9KTtcclxuICBmb3IgKHZhciB4IG9mIGFkZGl0aW9uYWxBdHRyaWJ1dGVzKSB7XHJcbiAgICAgIC8vIHJlbW92ZSBiZWdpbm5pbmcgYW5kIHRyYWlsaW5nIHdoaXRlc3BhY2VcclxuICAgICAgeCA9IHgudHJpbSgpXHJcbiAgICAgIGlmICh4KSB7XHJcbiAgICAgICAgdHIuYXBwZW5kQ2hpbGQoY3JlYXRlQ29sdW1uSGVhZGVyKHgsIFwiQXR0cmlidXRlc1wiLCAocGFydEEsIHBhcnRCKSA9PiB7XHJcbiAgICAgICAgICBpZiAocGFydEEuYXR0cmlidXRlcy5nZXQoeCkgIT0gcGFydEIuYXR0cmlidXRlcy5nZXQoeCkpIHJldHVybiAgcGFydEEuYXR0cmlidXRlcy5nZXQoeCkgPiBwYXJ0Qi5hdHRyaWJ1dGVzLmdldCh4KSA/IDEgOiAtMTtcclxuICAgICAgICAgIGVsc2UgcmV0dXJuIDA7XHJcbiAgICAgICAgfSkpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gIGlmKGdsb2JhbERhdGEuZ2V0Q29tYmluZVZhbHVlcygpKVxyXG4gIHtcclxuICAgIC8vWFhYOiBUaGlzIGNvbXBhcmlzb24gZnVuY3Rpb24gaXMgdXNpbmcgcG9zaXRpdmUgYW5kIG5lZ2F0aXZlIGltcGxpY2l0XHJcbiAgICB0ci5hcHBlbmRDaGlsZChjcmVhdGVDb2x1bW5IZWFkZXIoXCJRdWFudGl0eVwiLCBcIlF1YW50aXR5XCIsIChwYXJ0QSwgcGFydEIpID0+IHtcclxuICAgICAgcmV0dXJuIHBhcnRBLnF1YW50aXR5IC0gcGFydEIucXVhbnRpdHk7XHJcbiAgICB9KSk7XHJcbiAgfVxyXG5cclxuICBib21oZWFkLmFwcGVuZENoaWxkKHRyKTtcclxuXHJcbn1cclxuXHJcbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbi8vIEZpbHRlciBmdW5jdGlvbnMgYXJlIGRlZmluZWQgaGVyZS4gVGhlc2UgbGV0IHRoZSBhcHBsaWNhdGlvbiBmaWx0ZXIgXHJcbi8vIGVsZW1lbnRzIG91dCBvZiB0aGUgY29tcGxldGUgYm9tLiBcclxuLy9cclxuLy8gVGhlIGZpbHRlcmluZyBmdW5jdGlvbiBzaG91bGQgcmV0dXJuIHRydWUgaWYgdGhlIHBhcnQgc2hvdWxkIGJlIGZpbHRlcmVkIG91dFxyXG4vLyBvdGhlcndpc2UgaXQgcmV0dXJucyBmYWxzZVxyXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG5mdW5jdGlvbiBHZXRCT01Gb3JTaWRlT2ZCb2FyZChsb2NhdGlvbil7XHJcbiAgdmFyIHJlc3VsdCA9IHBjYi5HZXRCT00oKTtcclxuICAgIHN3aXRjaCAobG9jYXRpb24pIHtcclxuICAgIGNhc2UgJ0YnOlxyXG4gICAgICByZXN1bHQgPSBwY2IuZmlsdGVyQk9NVGFibGUocmVzdWx0LCBmaWx0ZXJCT01fRnJvbnQpO1xyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgJ0InOlxyXG4gICAgICByZXN1bHQgPSBwY2IuZmlsdGVyQk9NVGFibGUocmVzdWx0LCBmaWx0ZXJCT01fQmFjayk7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgZGVmYXVsdDpcclxuICAgICAgYnJlYWs7XHJcbiAgfVxyXG4gIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZpbHRlckJPTV9Gcm9udChwYXJ0KXtcclxuICB2YXIgcmVzdWx0ID0gdHJ1ZTtcclxuICBpZihwYXJ0LmxvY2F0aW9uID09IFwiRlwiKXtcclxuICAgIHJlc3VsdCA9IGZhbHNlO1xyXG4gIH1cclxuICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5mdW5jdGlvbiBmaWx0ZXJCT01fQmFjayhwYXJ0KXtcclxuICB2YXIgcmVzdWx0ID0gdHJ1ZTtcclxuICBpZihwYXJ0LmxvY2F0aW9uID09IFwiQlwiKXtcclxuICAgIHJlc3VsdCA9IGZhbHNlO1xyXG4gIH1cclxuICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5mdW5jdGlvbiBmaWx0ZXJCT01fQnlBdHRyaWJ1dGUocGFydCl7XHJcbiAgdmFyIHJlc3VsdCA9IGZhbHNlO1xyXG4gIHZhciBzcGxpdEZpbHRlclN0cmluZyA9IGdsb2JhbERhdGEuZ2V0UmVtb3ZlQk9NRW50cmllcygpLnNwbGl0KCcsJyk7XHJcbiAgLy8gUmVtb3ZlIG51bGwsIFwiXCIsIHVuZGVmaW5lZCwgYW5kIDAgdmFsdWVzXHJcbiAgc3BsaXRGaWx0ZXJTdHJpbmcgICAgPSBzcGxpdEZpbHRlclN0cmluZy5maWx0ZXIoZnVuY3Rpb24oZSl7cmV0dXJuIGV9KTtcclxuXHJcbiAgaWYoc3BsaXRGaWx0ZXJTdHJpbmcubGVuZ3RoID4gMCApXHJcbiAge1xyXG4gICAgZm9yKHZhciBpIG9mIHNwbGl0RmlsdGVyU3RyaW5nKXtcclxuICAgICAgLy8gcmVtb3ZpbmcgYmVnaW5uaW5nIGFuZCB0cmFpbGluZyB3aGl0ZXNwYWNlXHJcbiAgICAgIGkgPSBpLnRyaW0oKVxyXG4gICAgICBpZihwYXJ0LmF0dHJpYnV0ZXMuaGFzKGkpKXtcclxuICAgICAgICAvLyBJZCB0aGUgdmFsdWUgaXMgYW4gZW1wdHkgc3RyaW5nIHRoZW4gZG9udCBmaWx0ZXIgb3V0IHRoZSBlbnRyeS4gXHJcbiAgICAgICAgLy8gaWYgdGhlIHZhbHVlIGlzIGFueXRoaW5nIHRoZW4gZmlsdGVyIG91dCB0aGUgYm9tIGVudHJ5XHJcbiAgICAgICAgaWYocGFydC5hdHRyaWJ1dGVzLmdldChpKSAhPSBcIlwiKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHJlc3VsdCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gcmVzdWx0O1xyXG59XHJcbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcblxyXG5mdW5jdGlvbiBHZW5lcmF0ZUJPTVRhYmxlKClcclxue1xyXG4gIC8vIEdldCBib20gdGFibGUgd2l0aCBlbGVtZW50cyBmb3IgdGhlIHNpZGUgb2YgYm9hcmQgdGhlIHVzZXIgaGFzIHNlbGVjdGVkXHJcbiAgdmFyIGJvbXRhYmxlVGVtcCA9IEdldEJPTUZvclNpZGVPZkJvYXJkKGdsb2JhbERhdGEuZ2V0Q2FudmFzTGF5b3V0KCkpO1xyXG5cclxuICAvLyBBcHBseSBhdHRyaWJ1dGUgZmlsdGVyIHRvIGJvYXJkXHJcbiAgYm9tdGFibGVUZW1wID0gcGNiLmZpbHRlckJPTVRhYmxlKGJvbXRhYmxlVGVtcCwgZmlsdGVyQk9NX0J5QXR0cmlidXRlKTtcclxuXHJcbiAgLy8gSWYgdGhlIHBhcnRzIGFyZSBkaXNwbGF5ZWQgb25lIHBlciBsaW5lIChub3QgY29tYmluZWQgdmFsdWVzKSwgdGhlbiB0aGUgdGhlIGJvbSB0YWJsZSBuZWVkcyB0byBiZSBmbGF0dGVuZWQuIFxyXG4gIC8vIEJ5IGRlZmF1bHQgdGhlIGRhdGEgaW4gdGhlIGpzb24gZmlsZSBpcyBjb21iaW5lZFxyXG4gIGJvbXRhYmxlID0gZ2xvYmFsRGF0YS5nZXRDb21iaW5lVmFsdWVzKCkgPyBwY2IuR2V0Qk9NQ29tYmluZWRWYWx1ZXMoYm9tdGFibGVUZW1wKSA6IGJvbXRhYmxlVGVtcDtcclxuXHJcbiAgcmV0dXJuIGJvbXRhYmxlO1xyXG59XHJcblxyXG4vL1RPRE86IFRoaXMgc2hvdWxkIGJlIHJld3JpdHRlbiB0byBpbnRlcmFjdCB3aXRoIGpzb24gdXNpbmcgdGhlIHRhZ3MgaW5zdGVhZCBvZiBcclxuLy8gICAgICBoYXZpbmcgYWxsIG9mIHRoZSBlbGVtZW50cyBoYXJkY29kZWQuXHJcbmZ1bmN0aW9uIHBvcHVsYXRlQm9tQm9keSgpIHtcclxuICB3aGlsZSAoYm9tLmZpcnN0Q2hpbGQpIHtcclxuICAgIGJvbS5yZW1vdmVDaGlsZChib20uZmlyc3RDaGlsZCk7XHJcbiAgfVxyXG4gIGdsb2JhbERhdGEuc2V0SGlnaGxpZ2h0SGFuZGxlcnMoW10pO1xyXG4gIGdsb2JhbERhdGEuc2V0Q3VycmVudEhpZ2hsaWdodGVkUm93SWQobnVsbCk7XHJcbiAgdmFyIGZpcnN0ID0gdHJ1ZTtcclxuXHJcbiAgYm9tdGFibGUgPSBHZW5lcmF0ZUJPTVRhYmxlKCk7XHJcblxyXG4gIGlmIChnbG9iYWxEYXRhLmdldEJvbVNvcnRGdW5jdGlvbigpKSB7XHJcbiAgICBib210YWJsZSA9IGJvbXRhYmxlLnNsaWNlKCkuc29ydChnbG9iYWxEYXRhLmdldEJvbVNvcnRGdW5jdGlvbigpKTtcclxuICB9XHJcbiAgZm9yICh2YXIgaSBpbiBib210YWJsZSkge1xyXG4gICAgdmFyIGJvbWVudHJ5ID0gYm9tdGFibGVbaV07XHJcbiAgICB2YXIgcmVmZXJlbmNlcyA9IGJvbWVudHJ5LnJlZmVyZW5jZTtcclxuXHJcbiAgICBpZiAoZ2V0RmlsdGVyKCkgIT0gXCJcIil7XHJcbiAgICAgIGlmKCFlbnRyeU1hdGNoZXMoYm9tZW50cnkpKXtcclxuICAgICAgICBjb250aW51ZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICB2YXIgdHIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiVFJcIik7XHJcbiAgICB2YXIgdGQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiVERcIik7XHJcbiAgICB2YXIgcm93bnVtID0gK2kgKyAxO1xyXG4gICAgdHIuaWQgPSBcImJvbXJvd1wiICsgcm93bnVtO1xyXG4gICAgdGQudGV4dENvbnRlbnQgPSByb3dudW07XHJcbiAgICB0ci5hcHBlbmRDaGlsZCh0ZCk7XHJcblxyXG4gICAgLy8gQ2hlY2tib3hlc1xyXG4gICAgZm9yICh2YXIgY2hlY2tib3ggb2YgZ2xvYmFsRGF0YS5nZXRDaGVja2JveGVzKCkpIHtcclxuICAgICAgaWYgKGNoZWNrYm94KSB7XHJcbiAgICAgICAgdGQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiVERcIik7XHJcbiAgICAgICAgdmFyIGlucHV0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImlucHV0XCIpO1xyXG4gICAgICAgIGlucHV0LnR5cGUgPSBcImNoZWNrYm94XCI7XHJcbiAgICAgICAgaW5wdXQub25jaGFuZ2UgPSBjcmVhdGVDaGVja2JveENoYW5nZUhhbmRsZXIoY2hlY2tib3gsIHJlZmVyZW5jZXMpO1xyXG4gICAgICAgIHNldEJvbUNoZWNrYm94U3RhdGUoY2hlY2tib3gsIGlucHV0LCByZWZlcmVuY2VzKTtcclxuICAgICAgICB0ZC5hcHBlbmRDaGlsZChpbnB1dCk7XHJcbiAgICAgICAgdHIuYXBwZW5kQ2hpbGQodGQpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy9JTkZPOiBUaGUgbGluZXMgYmVsb3cgYWRkIHRoZSBjb250cm9sIHRoZSBjb2x1bW5zIG9uIHRoZSBib20gdGFibGVcclxuICAgIC8vIFJlZmVyZW5jZXNcclxuICAgIHRkID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcIlREXCIpO1xyXG4gICAgdGQuaW5uZXJIVE1MID0gaGlnaGxpZ2h0RmlsdGVyKHJlZmVyZW5jZXMpO1xyXG4gICAgdHIuYXBwZW5kQ2hpbGQodGQpO1xyXG4gICAgLy8gVmFsdWVcclxuICAgIHRkID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcIlREXCIpO1xyXG4gICAgdGQuaW5uZXJIVE1MID0gaGlnaGxpZ2h0RmlsdGVyKGJvbWVudHJ5LnZhbHVlKTtcclxuICAgIHRyLmFwcGVuZENoaWxkKHRkKTtcclxuICAgIC8vIEZvb3RwcmludFxyXG4gICAgdGQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiVERcIik7XHJcbiAgICB0ZC5pbm5lckhUTUwgPSBoaWdobGlnaHRGaWx0ZXIoYm9tZW50cnkucGFja2FnZSk7XHJcbiAgICB0ci5hcHBlbmRDaGlsZCh0ZCk7XHJcbiAgICBcclxuICAgIC8vIEF0dHJpYnV0ZXNcclxuICAgIHZhciBhZGRpdGlvbmFsQXR0cmlidXRlcyA9IGdsb2JhbERhdGEuZ2V0QWRkaXRpb25hbEF0dHJpYnV0ZXMoKS5zcGxpdCgnLCcpO1xyXG4gICAgZm9yICh2YXIgeCBvZiBhZGRpdGlvbmFsQXR0cmlidXRlcykge1xyXG4gICAgICB4ID0geC50cmltKClcclxuICAgICAgaWYgKHgpIHtcclxuICAgICAgICB0ZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJURFwiKTtcclxuICAgICAgICB0ZC5pbm5lckhUTUwgPSBoaWdobGlnaHRGaWx0ZXIocGNiLmdldEF0dHJpYnV0ZVZhbHVlKGJvbWVudHJ5LCB4LnRvTG93ZXJDYXNlKCkpKTtcclxuICAgICAgICB0ci5hcHBlbmRDaGlsZCh0ZCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBpZihnbG9iYWxEYXRhLmdldENvbWJpbmVWYWx1ZXMoKSlcclxuICAgIHtcclxuXHJcbiAgICAgIHRkID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcIlREXCIpO1xyXG4gICAgICB0ZC50ZXh0Q29udGVudCA9IGJvbWVudHJ5LnF1YW50aXR5O1xyXG4gICAgICB0ci5hcHBlbmRDaGlsZCh0ZCk7XHJcbiAgICB9XHJcbiAgICBib20uYXBwZW5kQ2hpbGQodHIpO1xyXG5cclxuXHJcbiAgICBib20uYXBwZW5kQ2hpbGQodHIpO1xyXG4gICAgdmFyIGhhbmRsZXIgPSBjcmVhdGVSb3dIaWdobGlnaHRIYW5kbGVyKHRyLmlkLCByZWZlcmVuY2VzKTtcclxuICAgIHRyLm9ubW91c2Vtb3ZlID0gaGFuZGxlcjtcclxuICAgIGdsb2JhbERhdGEucHVzaEhpZ2hsaWdodEhhbmRsZXJzKHtcclxuICAgICAgaWQ6IHRyLmlkLFxyXG4gICAgICBoYW5kbGVyOiBoYW5kbGVyLFxyXG4gICAgICByZWZzOiByZWZlcmVuY2VzXHJcbiAgICB9KTtcclxuICAgIGlmIChnZXRGaWx0ZXIoKSAmJiBmaXJzdCkge1xyXG4gICAgICBoYW5kbGVyKCk7XHJcbiAgICAgIGZpcnN0ID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBzbW9vdGhTY3JvbGxUb1Jvdyhyb3dpZCkge1xyXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHJvd2lkKS5zY3JvbGxJbnRvVmlldyh7XHJcbiAgICBiZWhhdmlvcjogXCJzbW9vdGhcIixcclxuICAgIGJsb2NrOiBcImNlbnRlclwiLFxyXG4gICAgaW5saW5lOiBcIm5lYXJlc3RcIlxyXG4gIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBoaWdobGlnaHRQcmV2aW91c1JvdygpIHtcclxuICBpZiAoIWdsb2JhbERhdGEuZ2V0Q3VycmVudEhpZ2hsaWdodGVkUm93SWQoKSkge1xyXG4gICAgZ2xvYmFsRGF0YS5nZXRIaWdobGlnaHRIYW5kbGVycygpW2dsb2JhbERhdGEuZ2V0SGlnaGxpZ2h0SGFuZGxlcnMoKS5sZW5ndGggLSAxXS5oYW5kbGVyKCk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGlmIChnbG9iYWxEYXRhLmdldEhpZ2hsaWdodEhhbmRsZXJzKCkubGVuZ3RoID4gMSAmJlxyXG4gICAgICBnbG9iYWxEYXRhLmdldEhpZ2hsaWdodEhhbmRsZXJzKClbMF0uaWQgPT0gZ2xvYmFsRGF0YS5nZXRDdXJyZW50SGlnaGxpZ2h0ZWRSb3dJZCgpKSB7XHJcbiAgICAgIGdsb2JhbERhdGEuZ2V0SGlnaGxpZ2h0SGFuZGxlcnMoKVtnbG9iYWxEYXRhLmdldEhpZ2hsaWdodEhhbmRsZXJzKCkubGVuZ3RoIC0gMV0uaGFuZGxlcigpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBnbG9iYWxEYXRhLmdldEhpZ2hsaWdodEhhbmRsZXJzKCkubGVuZ3RoIC0gMTsgaSsrKSB7XHJcbiAgICAgICAgaWYgKGdsb2JhbERhdGEuZ2V0SGlnaGxpZ2h0SGFuZGxlcnMoKVtpICsgMV0uaWQgPT0gZ2xvYmFsRGF0YS5nZXRDdXJyZW50SGlnaGxpZ2h0ZWRSb3dJZCgpKSB7XHJcbiAgICAgICAgICBnbG9iYWxEYXRhLmdldEhpZ2hsaWdodEhhbmRsZXJzKClbaV0uaGFuZGxlcigpO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIHNtb290aFNjcm9sbFRvUm93KGdsb2JhbERhdGEuZ2V0Q3VycmVudEhpZ2hsaWdodGVkUm93SWQoKSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGhpZ2hsaWdodE5leHRSb3coKSB7XHJcbiAgaWYgKCFnbG9iYWxEYXRhLmdldEN1cnJlbnRIaWdobGlnaHRlZFJvd0lkKCkpIHtcclxuICAgIGdsb2JhbERhdGEuZ2V0SGlnaGxpZ2h0SGFuZGxlcnMoKVswXS5oYW5kbGVyKCk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGlmIChnbG9iYWxEYXRhLmdldEhpZ2hsaWdodEhhbmRsZXJzKCkubGVuZ3RoID4gMSAmJlxyXG4gICAgICBnbG9iYWxEYXRhLmdldEhpZ2hsaWdodEhhbmRsZXJzKClbZ2xvYmFsRGF0YS5nZXRIaWdobGlnaHRIYW5kbGVycygpLmxlbmd0aCAtIDFdLmlkID09IGdsb2JhbERhdGEuZ2V0Q3VycmVudEhpZ2hsaWdodGVkUm93SWQoKSkge1xyXG4gICAgICBnbG9iYWxEYXRhLmdldEhpZ2hsaWdodEhhbmRsZXJzKClbMF0uaGFuZGxlcigpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yICh2YXIgaSA9IDE7IGkgPCBnbG9iYWxEYXRhLmdldEhpZ2hsaWdodEhhbmRsZXJzKCkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICBpZiAoZ2xvYmFsRGF0YS5nZXRIaWdobGlnaHRIYW5kbGVycygpW2kgLSAxXS5pZCA9PSBnbG9iYWxEYXRhLmdldEN1cnJlbnRIaWdobGlnaHRlZFJvd0lkKCkpIHtcclxuICAgICAgICAgIGdsb2JhbERhdGEuZ2V0SGlnaGxpZ2h0SGFuZGxlcnMoKVtpXS5oYW5kbGVyKCk7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgc21vb3RoU2Nyb2xsVG9Sb3coZ2xvYmFsRGF0YS5nZXRDdXJyZW50SGlnaGxpZ2h0ZWRSb3dJZCgpKTtcclxufVxyXG5cclxuZnVuY3Rpb24gcG9wdWxhdGVCb21UYWJsZSgpIHtcclxuICBwb3B1bGF0ZUJvbUhlYWRlcigpO1xyXG4gIHBvcHVsYXRlQm9tQm9keSgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBtb2R1bGVzQ2xpY2tlZChyZWZlcmVuY2VzKSB7XHJcbiAgdmFyIGxhc3RDbGlja2VkSW5kZXggPSByZWZlcmVuY2VzLmluZGV4T2YoZ2xvYmFsRGF0YS5nZXRMYXN0Q2xpY2tlZFJlZigpKTtcclxuICB2YXIgcmVmID0gcmVmZXJlbmNlc1sobGFzdENsaWNrZWRJbmRleCArIDEpICUgcmVmZXJlbmNlcy5sZW5ndGhdO1xyXG4gIGZvciAodmFyIGhhbmRsZXIgb2YgZ2xvYmFsRGF0YS5nZXRIaWdobGlnaHRIYW5kbGVycygpKSB7XHJcbiAgICBpZiAoaGFuZGxlci5yZWZzLmluZGV4T2YocmVmKSA+PSAwKSB7XHJcbiAgICAgIGdsb2JhbERhdGEuc2V0TGFzdENsaWNrZWRSZWYocmVmKTtcclxuICAgICAgaGFuZGxlci5oYW5kbGVyKCk7XHJcbiAgICAgIHNtb290aFNjcm9sbFRvUm93KGdsb2JhbERhdGEuZ2V0Q3VycmVudEhpZ2hsaWdodGVkUm93SWQoKSk7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gc2lsa3NjcmVlblZpc2libGUodmlzaWJsZSkge1xyXG4gIGlmICh2aXNpYmxlKSB7XHJcbiAgICBhbGxjYW52YXMuZnJvbnQuc2lsay5zdHlsZS5kaXNwbGF5ID0gXCJcIjtcclxuICAgIGFsbGNhbnZhcy5iYWNrLnNpbGsuc3R5bGUuZGlzcGxheSA9IFwiXCI7XHJcbiAgICBnbG9iYWxEYXRhLndyaXRlU3RvcmFnZShcInNpbGtzY3JlZW5WaXNpYmxlXCIsIHRydWUpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBhbGxjYW52YXMuZnJvbnQuc2lsay5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbiAgICBhbGxjYW52YXMuYmFjay5zaWxrLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcclxuICAgIGdsb2JhbERhdGEud3JpdGVTdG9yYWdlKFwic2lsa3NjcmVlblZpc2libGVcIiwgZmFsc2UpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gY2hhbmdlQ2FudmFzTGF5b3V0KGxheW91dCkge1xyXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZmwtYnRuXCIpLmNsYXNzTGlzdC5yZW1vdmUoXCJkZXByZXNzZWRcIik7XHJcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJmYi1idG5cIikuY2xhc3NMaXN0LnJlbW92ZShcImRlcHJlc3NlZFwiKTtcclxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJsLWJ0blwiKS5jbGFzc0xpc3QucmVtb3ZlKFwiZGVwcmVzc2VkXCIpO1xyXG4gIHN3aXRjaCAobGF5b3V0KSB7XHJcbiAgICBjYXNlICdGJzpcclxuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJmbC1idG5cIikuY2xhc3NMaXN0LmFkZChcImRlcHJlc3NlZFwiKTtcclxuICAgICAgaWYgKGdsb2JhbERhdGEuZ2V0Qm9tTGF5b3V0KCkgIT0gXCJCT01cIikge1xyXG4gICAgICAgIGdsb2JhbERhdGEuY29sbGFwc2VDYW52YXNTcGxpdCgxKTtcclxuICAgICAgfVxyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgJ0InOlxyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJsLWJ0blwiKS5jbGFzc0xpc3QuYWRkKFwiZGVwcmVzc2VkXCIpO1xyXG4gICAgICBpZiAoZ2xvYmFsRGF0YS5nZXRCb21MYXlvdXQoKSAhPSBcIkJPTVwiKSB7XHJcbiAgICAgICAgZ2xvYmFsRGF0YS5jb2xsYXBzZUNhbnZhc1NwbGl0KDApO1xyXG4gICAgICB9XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgZGVmYXVsdDpcclxuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJmYi1idG5cIikuY2xhc3NMaXN0LmFkZChcImRlcHJlc3NlZFwiKTtcclxuICAgICAgaWYgKGdsb2JhbERhdGEuZ2V0Qm9tTGF5b3V0KCkgIT0gXCJCT01cIikge1xyXG4gICAgICAgIGdsb2JhbERhdGEuc2V0U2l6ZXNDYW52YXNTcGxpdChbNTAsIDUwXSk7XHJcbiAgICAgIH1cclxuICB9XHJcbiAgZ2xvYmFsRGF0YS5zZXRDYW52YXNMYXlvdXQobGF5b3V0KTtcclxuICBnbG9iYWxEYXRhLndyaXRlU3RvcmFnZShcImNhbnZhc2xheW91dFwiLCBsYXlvdXQpO1xyXG4gIHJlbmRlci5yZXNpemVBbGwoKTtcclxuICBwb3B1bGF0ZUJvbVRhYmxlKCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBvcHVsYXRlTWV0YWRhdGEoKSB7XHJcbiAgdmFyIG1ldGFkYXRhICA9IHBjYi5HZXRNZXRhZGF0YSgpO1xyXG4gIFxyXG4gIGlmKG1ldGFkYXRhLnJldmlzaW9uID09IFwiXCIpXHJcbiAge1xyXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0aXRsZVwiKS5pbm5lckhUTUwgICAgPSBcIlwiXHJcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJldmlzaW9uXCIpLmlubmVySFRNTCA9IG1ldGFkYXRhLnRpdGxlO1xyXG4gIH1cclxuICBlbHNle1xyXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0aXRsZVwiKS5pbm5lckhUTUwgICAgPSBtZXRhZGF0YS50aXRsZTtcclxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicmV2aXNpb25cIikuaW5uZXJIVE1MID0gXCJSZXY6IFwiICsgbWV0YWRhdGEucmV2aXNpb247XHJcbiAgfVxyXG5cclxuICBcclxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNvbXBhbnlcIikuaW5uZXJIVE1MICA9IG1ldGFkYXRhLmNvbXBhbnk7XHJcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJmaWxlZGF0ZVwiKS5pbm5lckhUTUwgPSBtZXRhZGF0YS5kYXRlO1xyXG4gIGlmIChtZXRhZGF0YS50aXRsZSAhPSBcIlwiKSB7XHJcbiAgICBkb2N1bWVudC50aXRsZSA9IG1ldGFkYXRhLnRpdGxlICsgXCIgQk9NXCI7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBjaGFuZ2VCb21MYXlvdXQobGF5b3V0KSB7XHJcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJib20tYnRuXCIpLmNsYXNzTGlzdC5yZW1vdmUoXCJkZXByZXNzZWRcIik7XHJcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJsci1idG5cIikuY2xhc3NMaXN0LnJlbW92ZShcImRlcHJlc3NlZFwiKTtcclxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRiLWJ0blwiKS5jbGFzc0xpc3QucmVtb3ZlKFwiZGVwcmVzc2VkXCIpO1xyXG4gIHN3aXRjaCAobGF5b3V0KSB7XHJcbiAgICBjYXNlICdCT00nOlxyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJvbS1idG5cIikuY2xhc3NMaXN0LmFkZChcImRlcHJlc3NlZFwiKTtcclxuICAgICAgaWYgKGdsb2JhbERhdGEuZ2V0Qm9tU3BsaXQoKSkge1xyXG4gICAgICAgIGdsb2JhbERhdGEuZGVzdHJveUJvbVNwbGl0KCk7XHJcbiAgICAgICAgZ2xvYmFsRGF0YS5zZXRCb21TcGxpdChudWxsKTtcclxuICAgICAgICBnbG9iYWxEYXRhLmRlc3Ryb3lDYW52YXNTcGxpdCgpO1xyXG4gICAgICAgIGdsb2JhbERhdGEuc2V0Q2FudmFzU3BsaXQobnVsbCk7XHJcbiAgICAgIH1cclxuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJmcm9udGNhbnZhc1wiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYmFja2NhbnZhc1wiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYm90XCIpLnN0eWxlLmhlaWdodCA9IFwiXCI7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSAnVEInOlxyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRiLWJ0blwiKS5jbGFzc0xpc3QuYWRkKFwiZGVwcmVzc2VkXCIpO1xyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImZyb250Y2FudmFzXCIpLnN0eWxlLmRpc3BsYXkgPSBcIlwiO1xyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJhY2tjYW52YXNcIikuc3R5bGUuZGlzcGxheSA9IFwiXCI7XHJcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYm90XCIpLnN0eWxlLmhlaWdodCA9IFwiY2FsYygxMDAlIC0gODBweClcIjtcclxuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJib21kaXZcIikuY2xhc3NMaXN0LnJlbW92ZShcInNwbGl0LWhvcml6b250YWxcIik7XHJcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY2FudmFzZGl2XCIpLmNsYXNzTGlzdC5yZW1vdmUoXCJzcGxpdC1ob3Jpem9udGFsXCIpO1xyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImZyb250Y2FudmFzXCIpLmNsYXNzTGlzdC5hZGQoXCJzcGxpdC1ob3Jpem9udGFsXCIpO1xyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJhY2tjYW52YXNcIikuY2xhc3NMaXN0LmFkZChcInNwbGl0LWhvcml6b250YWxcIik7XHJcbiAgICAgIGlmIChnbG9iYWxEYXRhLmdldEJvbVNwbGl0KCkpIHtcclxuICAgICAgICBnbG9iYWxEYXRhLmRlc3Ryb3lCb21TcGxpdCgpO1xyXG4gICAgICAgIGdsb2JhbERhdGEuc2V0Qm9tU3BsaXQobnVsbCk7XHJcbiAgICAgICAgZ2xvYmFsRGF0YS5kZXN0cm95Q2FudmFzU3BsaXQoKTtcclxuICAgICAgICBnbG9iYWxEYXRhLnNldENhbnZhc1NwbGl0KG51bGwpO1xyXG4gICAgICB9XHJcbiAgICAgIGdsb2JhbERhdGEuc2V0Qm9tU3BsaXQoU3BsaXQoWycjYm9tZGl2JywgJyNjYW52YXNkaXYnXSwge1xyXG4gICAgICAgIHNpemVzOiBbNTAsIDUwXSxcclxuICAgICAgICBvbkRyYWdFbmQ6IHJlbmRlci5yZXNpemVBbGwsXHJcbiAgICAgICAgZGlyZWN0aW9uOiBcInZlcnRpY2FsXCIsXHJcbiAgICAgICAgZ3V0dGVyU2l6ZTogNVxyXG4gICAgICB9KSk7XHJcbiAgICAgIGdsb2JhbERhdGEuc2V0Q2FudmFzU3BsaXQoU3BsaXQoWycjZnJvbnRjYW52YXMnLCAnI2JhY2tjYW52YXMnXSwge1xyXG4gICAgICAgIHNpemVzOiBbNTAsIDUwXSxcclxuICAgICAgICBndXR0ZXJTaXplOiA1LFxyXG4gICAgICAgIG9uRHJhZ0VuZDogcmVuZGVyLnJlc2l6ZUFsbFxyXG4gICAgICB9KSk7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSAnTFInOlxyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImxyLWJ0blwiKS5jbGFzc0xpc3QuYWRkKFwiZGVwcmVzc2VkXCIpO1xyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImZyb250Y2FudmFzXCIpLnN0eWxlLmRpc3BsYXkgPSBcIlwiO1xyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJhY2tjYW52YXNcIikuc3R5bGUuZGlzcGxheSA9IFwiXCI7XHJcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYm90XCIpLnN0eWxlLmhlaWdodCA9IFwiY2FsYygxMDAlIC0gODBweClcIjtcclxuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJib21kaXZcIikuY2xhc3NMaXN0LmFkZChcInNwbGl0LWhvcml6b250YWxcIik7XHJcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY2FudmFzZGl2XCIpLmNsYXNzTGlzdC5hZGQoXCJzcGxpdC1ob3Jpem9udGFsXCIpO1xyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImZyb250Y2FudmFzXCIpLmNsYXNzTGlzdC5yZW1vdmUoXCJzcGxpdC1ob3Jpem9udGFsXCIpO1xyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJhY2tjYW52YXNcIikuY2xhc3NMaXN0LnJlbW92ZShcInNwbGl0LWhvcml6b250YWxcIik7XHJcbiAgICAgIGlmIChnbG9iYWxEYXRhLmdldEJvbVNwbGl0KCkpIHtcclxuICAgICAgICBnbG9iYWxEYXRhLmRlc3Ryb3lCb21TcGxpdCgpO1xyXG4gICAgICAgIGdsb2JhbERhdGEuc2V0Qm9tU3BsaXQobnVsbCk7XHJcbiAgICAgICAgZ2xvYmFsRGF0YS5kZXN0cm95Q2FudmFzU3BsaXQoKTtcclxuICAgICAgICBnbG9iYWxEYXRhLnNldENhbnZhc1NwbGl0KG51bGwpO1xyXG4gICAgICB9XHJcbiAgICAgIGdsb2JhbERhdGEuc2V0Qm9tU3BsaXQoU3BsaXQoWycjYm9tZGl2JywgJyNjYW52YXNkaXYnXSwge1xyXG4gICAgICAgIHNpemVzOiBbNTAsIDUwXSxcclxuICAgICAgICBvbkRyYWdFbmQ6IHJlbmRlci5yZXNpemVBbGwsXHJcbiAgICAgICAgZ3V0dGVyU2l6ZTogNVxyXG4gICAgICB9KSk7XHJcbiAgICAgIGdsb2JhbERhdGEuc2V0Q2FudmFzU3BsaXQoU3BsaXQoWycjZnJvbnRjYW52YXMnLCAnI2JhY2tjYW52YXMnXSwge1xyXG4gICAgICAgIHNpemVzOiBbNTAsIDUwXSxcclxuICAgICAgICBndXR0ZXJTaXplOiA1LFxyXG4gICAgICAgIGRpcmVjdGlvbjogXCJ2ZXJ0aWNhbFwiLFxyXG4gICAgICAgIG9uRHJhZ0VuZDogcmVuZGVyLnJlc2l6ZUFsbFxyXG4gICAgICB9KSk7XHJcbiAgfVxyXG4gIGdsb2JhbERhdGEuc2V0Qm9tTGF5b3V0KGxheW91dCk7XHJcbiAgZ2xvYmFsRGF0YS53cml0ZVN0b3JhZ2UoXCJib21sYXlvdXRcIiwgbGF5b3V0KTtcclxuICBjaGFuZ2VDYW52YXNMYXlvdXQoZ2xvYmFsRGF0YS5nZXRDYW52YXNMYXlvdXQoKSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvY3VzSW5wdXRGaWVsZChpbnB1dCkge1xyXG4gIGlucHV0LnNjcm9sbEludG9WaWV3KGZhbHNlKTtcclxuICBpbnB1dC5mb2N1cygpO1xyXG4gIGlucHV0LnNlbGVjdCgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmb2N1c0ZpbHRlckZpZWxkKCkge1xyXG4gIGZvY3VzSW5wdXRGaWVsZChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImZpbHRlclwiKSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHRvZ2dsZUJvbUNoZWNrYm94KGJvbXJvd2lkLCBjaGVja2JveG51bSkge1xyXG4gIGlmICghYm9tcm93aWQgfHwgY2hlY2tib3hudW0gPiBnbG9iYWxEYXRhLmdldENoZWNrYm94ZXMoKS5sZW5ndGgpIHtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgdmFyIGJvbXJvdyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGJvbXJvd2lkKTtcclxuICB2YXIgY2hlY2tib3ggPSBib21yb3cuY2hpbGROb2Rlc1tjaGVja2JveG51bV0uY2hpbGROb2Rlc1swXTtcclxuICBjaGVja2JveC5jaGVja2VkID0gIWNoZWNrYm94LmNoZWNrZWQ7XHJcbiAgY2hlY2tib3guaW5kZXRlcm1pbmF0ZSA9IGZhbHNlO1xyXG4gIGNoZWNrYm94Lm9uY2hhbmdlKCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNoZWNrQm9tQ2hlY2tib3goYm9tcm93aWQsIGNoZWNrYm94bmFtZSkge1xyXG4gIHZhciBjaGVja2JveG51bSA9IDA7XHJcbiAgd2hpbGUgKGNoZWNrYm94bnVtIDwgZ2xvYmFsRGF0YS5nZXRDaGVja2JveGVzKCkubGVuZ3RoICYmXHJcbiAgICBnbG9iYWxEYXRhLmdldENoZWNrYm94ZXMoKVtjaGVja2JveG51bV0udG9Mb3dlckNhc2UoKSAhPSBjaGVja2JveG5hbWUudG9Mb3dlckNhc2UoKSkge1xyXG4gICAgY2hlY2tib3hudW0rKztcclxuICB9XHJcbiAgaWYgKCFib21yb3dpZCB8fCBjaGVja2JveG51bSA+PSBnbG9iYWxEYXRhLmdldENoZWNrYm94ZXMoKS5sZW5ndGgpIHtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgdmFyIGJvbXJvdyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGJvbXJvd2lkKTtcclxuICB2YXIgY2hlY2tib3ggPSBib21yb3cuY2hpbGROb2Rlc1tjaGVja2JveG51bSArIDFdLmNoaWxkTm9kZXNbMF07XHJcbiAgY2hlY2tib3guY2hlY2tlZCA9IHRydWU7XHJcbiAgY2hlY2tib3guaW5kZXRlcm1pbmF0ZSA9IGZhbHNlO1xyXG4gIGNoZWNrYm94Lm9uY2hhbmdlKCk7XHJcbn1cclxuXHJcblxyXG5mdW5jdGlvbiByZW1vdmVHdXR0ZXJOb2RlKG5vZGUpIHtcclxuICBmb3IgKHZhciBpID0gMDsgaSA8IG5vZGUuY2hpbGROb2Rlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgaWYgKG5vZGUuY2hpbGROb2Rlc1tpXS5jbGFzc0xpc3QgJiZcclxuICAgICAgbm9kZS5jaGlsZE5vZGVzW2ldLmNsYXNzTGlzdC5jb250YWlucyhcImd1dHRlclwiKSkge1xyXG4gICAgICBub2RlLnJlbW92ZUNoaWxkKG5vZGUuY2hpbGROb2Rlc1tpXSk7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gY2xlYW5HdXR0ZXJzKCkge1xyXG4gIHJlbW92ZUd1dHRlck5vZGUoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJib3RcIikpO1xyXG4gIHJlbW92ZUd1dHRlck5vZGUoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjYW52YXNkaXZcIikpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzZXRCb21DaGVja2JveGVzKHZhbHVlKSB7XHJcbiAgZ2xvYmFsRGF0YS5zZXRCb21DaGVja2JveGVzKHZhbHVlKTtcclxuICBnbG9iYWxEYXRhLndyaXRlU3RvcmFnZShcImJvbUNoZWNrYm94ZXNcIiwgdmFsdWUpO1xyXG4gIHBvcHVsYXRlQm9tVGFibGUoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc2V0UmVtb3ZlQk9NRW50cmllcyh2YWx1ZSkge1xyXG4gIGdsb2JhbERhdGEuc2V0UmVtb3ZlQk9NRW50cmllcyh2YWx1ZSk7XHJcbiAgZ2xvYmFsRGF0YS53cml0ZVN0b3JhZ2UoXCJyZW1vdmVCT01FbnRyaWVzXCIsIHZhbHVlKTtcclxuICBwb3B1bGF0ZUJvbVRhYmxlKCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNldEFkZGl0aW9uYWxBdHRyaWJ1dGVzKHZhbHVlKSB7XHJcbiAgZ2xvYmFsRGF0YS5zZXRBZGRpdGlvbmFsQXR0cmlidXRlcyh2YWx1ZSk7XHJcbiAgZ2xvYmFsRGF0YS53cml0ZVN0b3JhZ2UoXCJhZGRpdGlvbmFsQXR0cmlidXRlc1wiLCB2YWx1ZSk7XHJcbiAgcG9wdWxhdGVCb21UYWJsZSgpO1xyXG59XHJcblxyXG4vLyBYWFg6IE5vbmUgb2YgdGhpcyBzZWVtcyB0byBiZSB3b3JraW5nLiBcclxuZG9jdW1lbnQub25rZXlkb3duID0gZnVuY3Rpb24oZSkge1xyXG4gIHN3aXRjaCAoZS5rZXkpIHtcclxuICAgIGNhc2UgXCJuXCI6XHJcbiAgICAgIGlmIChkb2N1bWVudC5hY3RpdmVFbGVtZW50LnR5cGUgPT0gXCJ0ZXh0XCIpIHtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGdsb2JhbERhdGEuZ2V0Q3VycmVudEhpZ2hsaWdodGVkUm93SWQoKSAhPT0gbnVsbCkge1xyXG4gICAgICAgIGNoZWNrQm9tQ2hlY2tib3goZ2xvYmFsRGF0YS5nZXRDdXJyZW50SGlnaGxpZ2h0ZWRSb3dJZCgpLCBcInBsYWNlZFwiKTtcclxuICAgICAgICBoaWdobGlnaHROZXh0Um93KCk7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICB9XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBcIkFycm93VXBcIjpcclxuICAgICAgaGlnaGxpZ2h0UHJldmlvdXNSb3coKTtcclxuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgXCJBcnJvd0Rvd25cIjpcclxuICAgICAgaGlnaGxpZ2h0TmV4dFJvdygpO1xyXG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgZGVmYXVsdDpcclxuICAgICAgYnJlYWs7XHJcbiAgfVxyXG4gIGlmIChlLmFsdEtleSkge1xyXG4gICAgc3dpdGNoIChlLmtleSkge1xyXG4gICAgICBjYXNlIFwiZlwiOlxyXG4gICAgICAgIGZvY3VzRmlsdGVyRmllbGQoKTtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJ6XCI6XHJcbiAgICAgICAgY2hhbmdlQm9tTGF5b3V0KFwiQk9NXCIpO1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSBcInhcIjpcclxuICAgICAgICBjaGFuZ2VCb21MYXlvdXQoXCJMUlwiKTtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJjXCI6XHJcbiAgICAgICAgY2hhbmdlQm9tTGF5b3V0KFwiVEJcIik7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlIFwidlwiOlxyXG4gICAgICAgIGNoYW5nZUNhbnZhc0xheW91dChcIkZcIik7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlIFwiYlwiOlxyXG4gICAgICAgIGNoYW5nZUNhbnZhc0xheW91dChcIkZCXCIpO1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSBcIm5cIjpcclxuICAgICAgICBjaGFuZ2VDYW52YXNMYXlvdXQoXCJCXCIpO1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICBicmVhaztcclxuICAgIH1cclxuICAgIGlmIChlLmtleSA+PSAnMScgJiYgZS5rZXkgPD0gJzknKSB7XHJcbiAgICAgIHRvZ2dsZUJvbUNoZWNrYm94KGN1cnJlbnRIaWdobGlnaHRlZFJvd0lkLCBwYXJzZUludChlLmtleSkpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuLy9YWFg6IEkgd291bGQgbGlrZSB0aGlzIHRvIGJlIGluIHRoZSBodG1sIGZ1bmN0aW9ucyBqcyBmaWxlLiBCdXQgdGhpcyBmdW5jdGlvbiBuZWVkcyB0byBiZSBcclxuLy8gICAgIHBsYWNlZCBoZXJlLCBvdGhlcndpc2UgdGhlIGFwcGxpY2F0aW9uIHJlbmRlcmluZyBiZWNvbWVzIHZlcnkgdmVyeSB3ZWlyZC5cclxud2luZG93Lm9ubG9hZCA9IGZ1bmN0aW9uKGUpIHtcclxuICBcclxuICAvLyBUaGlzIGZ1bmN0aW9uIG1ha2VzIHNvIHRoYXQgdGhlIHVzZXIgZGF0YSBmb3IgdGhlIHBjYiBpcyBjb252ZXJ0ZWQgdG8gb3VyIGludGVybmFsIHN0cnVjdHVyZVxyXG4gIHBjYi5PcGVuUGNiRGF0YShwY2JkYXRhKVxyXG4gIFxyXG5cclxuICBnbG9iYWxEYXRhLmluaXRTdG9yYWdlKCk7XHJcbiAgY2xlYW5HdXR0ZXJzKCk7XHJcbiAgcmVuZGVyLmluaXRSZW5kZXIoKTtcclxuICBkYmdkaXYgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRiZ1wiKTtcclxuICBib20gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJvbWJvZHlcIik7XHJcbiAgYm9taGVhZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYm9taGVhZFwiKTtcclxuICBnbG9iYWxEYXRhLnNldEJvbUxheW91dChnbG9iYWxEYXRhLnJlYWRTdG9yYWdlKFwiYm9tbGF5b3V0XCIpKTtcclxuICBpZiAoIWdsb2JhbERhdGEuZ2V0Qm9tTGF5b3V0KCkpIHtcclxuICAgIGdsb2JhbERhdGEuc2V0Qm9tTGF5b3V0KFwiTFJcIik7XHJcbiAgfVxyXG4gIGdsb2JhbERhdGEuc2V0Q2FudmFzTGF5b3V0KGdsb2JhbERhdGEucmVhZFN0b3JhZ2UoXCJjYW52YXNsYXlvdXRcIikpO1xyXG4gIGlmICghZ2xvYmFsRGF0YS5nZXRDYW52YXNMYXlvdXQoKSkge1xyXG4gICAgZ2xvYmFsRGF0YS5zZXRDYW52YXNMYXlvdXQoXCJGQlwiKTtcclxuICB9XHJcblxyXG4gIHBvcHVsYXRlTWV0YWRhdGEoKTtcclxuICBnbG9iYWxEYXRhLnNldEJvbUNoZWNrYm94ZXMoZ2xvYmFsRGF0YS5yZWFkU3RvcmFnZShcImJvbUNoZWNrYm94ZXNcIikpO1xyXG4gIGlmIChnbG9iYWxEYXRhLmdldEJvbUNoZWNrYm94ZXMoKSA9PT0gbnVsbCkge1xyXG4gICAgZ2xvYmFsRGF0YS5zZXRCb21DaGVja2JveGVzKFwiUGxhY2VkXCIpO1xyXG4gIH1cclxuICBnbG9iYWxEYXRhLnNldFJlbW92ZUJPTUVudHJpZXMoZ2xvYmFsRGF0YS5yZWFkU3RvcmFnZShcInJlbW92ZUJPTUVudHJpZXNcIikpO1xyXG4gIGlmIChnbG9iYWxEYXRhLmdldFJlbW92ZUJPTUVudHJpZXMoKSA9PT0gbnVsbCkge1xyXG4gICAgZ2xvYmFsRGF0YS5zZXRSZW1vdmVCT01FbnRyaWVzKFwiXCIpO1xyXG4gIH1cclxuICBnbG9iYWxEYXRhLnNldEFkZGl0aW9uYWxBdHRyaWJ1dGVzKGdsb2JhbERhdGEucmVhZFN0b3JhZ2UoXCJhZGRpdGlvbmFsQXR0cmlidXRlc1wiKSk7XHJcbiAgaWYgKGdsb2JhbERhdGEuZ2V0QWRkaXRpb25hbEF0dHJpYnV0ZXMoKSA9PT0gbnVsbCkge1xyXG4gICAgZ2xvYmFsRGF0YS5zZXRBZGRpdGlvbmFsQXR0cmlidXRlcyhcIlwiKTtcclxuICB9XHJcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJib21DaGVja2JveGVzXCIpLnZhbHVlID0gZ2xvYmFsRGF0YS5nZXRCb21DaGVja2JveGVzKCk7XHJcbiAgaWYgKGdsb2JhbERhdGEucmVhZFN0b3JhZ2UoXCJzaWxrc2NyZWVuVmlzaWJsZVwiKSA9PT0gXCJmYWxzZVwiKSB7XHJcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNpbGtzY3JlZW5DaGVja2JveFwiKS5jaGVja2VkID0gZmFsc2U7XHJcbiAgICBzaWxrc2NyZWVuVmlzaWJsZShmYWxzZSk7XHJcbiAgfVxyXG4gIGlmIChnbG9iYWxEYXRhLnJlYWRTdG9yYWdlKFwicmVkcmF3T25EcmFnXCIpID09PSBcImZhbHNlXCIpIHtcclxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZHJhZ0NoZWNrYm94XCIpLmNoZWNrZWQgPSBmYWxzZTtcclxuICAgIGdsb2JhbERhdGEuc2V0UmVkcmF3T25EcmFnKGZhbHNlKTtcclxuICB9XHJcbiAgaWYgKGdsb2JhbERhdGEucmVhZFN0b3JhZ2UoXCJkYXJrbW9kZVwiKSA9PT0gXCJ0cnVlXCIpIHtcclxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGFya21vZGVDaGVja2JveFwiKS5jaGVja2VkID0gdHJ1ZTtcclxuICAgIHNldERhcmtNb2RlKHRydWUpO1xyXG4gIH1cclxuICBpZiAoZ2xvYmFsRGF0YS5yZWFkU3RvcmFnZShcImhpZ2hsaWdodHBpbjFcIikgPT09IFwidHJ1ZVwiKSB7XHJcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImhpZ2hsaWdodHBpbjFDaGVja2JveFwiKS5jaGVja2VkID0gdHJ1ZTtcclxuICAgIGdsb2JhbERhdGEuc2V0SGlnaGxpZ2h0UGluMSh0cnVlKTtcclxuICAgIHJlbmRlci5yZWRyYXdDYW52YXMoYWxsY2FudmFzLmZyb250KTtcclxuICAgIHJlbmRlci5yZWRyYXdDYW52YXMoYWxsY2FudmFzLmJhY2spO1xyXG4gIH1cclxuICAvLyBJZiB0aGlzIGlzIHRydWUgdGhlbiBjb21iaW5lIHBhcnRzIGFuZCBkaXNwbGF5IHF1YW50aXR5XHJcbiAgaWYgKGdsb2JhbERhdGEucmVhZFN0b3JhZ2UoXCJjb21iaW5lVmFsdWVzXCIpID09PSBcInRydWVcIikge1xyXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjb21iaW5lVmFsdWVzXCIpLmNoZWNrZWQgPSB0cnVlO1xyXG4gICAgZ2xvYmFsRGF0YS5zZXRDb21iaW5lVmFsdWVzKHRydWUpO1xyXG4gIH1cclxuICBib2FyZFJvdGF0aW9uID0gZ2xvYmFsRGF0YS5yZWFkU3RvcmFnZShcImJvYXJkUm90YXRpb25cIik7XHJcbiAgaWYgKGJvYXJkUm90YXRpb24gPT09IG51bGwpIHtcclxuICAgIGJvYXJkUm90YXRpb24gPSAwO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBib2FyZFJvdGF0aW9uID0gcGFyc2VJbnQoYm9hcmRSb3RhdGlvbik7XHJcbiAgfVxyXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYm9hcmRSb3RhdGlvblwiKS52YWx1ZSA9IGJvYXJkUm90YXRpb24gLyA1O1xyXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicm90YXRpb25EZWdyZWVcIikudGV4dENvbnRlbnQgPSBib2FyZFJvdGF0aW9uO1xyXG4gIC8vIFRyaWdnZXJzIHJlbmRlclxyXG4gIGNoYW5nZUJvbUxheW91dChnbG9iYWxEYXRhLmdldEJvbUxheW91dCgpKTtcclxufVxyXG5cclxud2luZG93Lm9ucmVzaXplID0gcmVuZGVyLnJlc2l6ZUFsbDtcclxud2luZG93Lm1hdGNoTWVkaWEoXCJwcmludFwiKS5hZGRMaXN0ZW5lcihyZW5kZXIucmVzaXplQWxsKTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0ge1xyXG4gIHNldERhcmtNb2RlICAgICAgICAsIHNpbGtzY3JlZW5WaXNpYmxlICAgICAgLCBjaGFuZ2VCb21MYXlvdXQsIGNoYW5nZUNhbnZhc0xheW91dCxcclxuICBzZXRCb21DaGVja2JveGVzICAgLCBwb3B1bGF0ZUJvbVRhYmxlICAgICAgICwgc2V0RmlsdGVyICAgICAgLCBnZXRGaWx0ZXIgICAgICAgICAsXHJcbiAgc2V0UmVtb3ZlQk9NRW50cmllcywgc2V0QWRkaXRpb25hbEF0dHJpYnV0ZXNcclxufVxyXG4iLCIvKlxyXG4gICAgVGhpcyBmaWxlIGNvbnRhaW5zIGFsbCBvZiB0aGUgZGVmaW5pdGlvbnMgZm9yIHdvcmtpbmcgd2l0aCBwY2JkYXRhLmpzb24uIFxyXG4gICAgVGhpcyBmaWxlIGRlY2xhcmVzIGFsbCBvZiB0aGUgYWNjZXNzIGZ1bmN0aW9ucyBhbmQgaW50ZXJmYWNlcyBmb3IgY29udmVydGluZyBcclxuICAgIHRoZSBqc29uIGZpbGUgaW50byBhbiBpbnRlcm5hbCBkYXRhIHN0cnVjdHVyZS4gXHJcbiovXHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUENCIFBhcnQgSW50ZXJmYWNlc1xyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuLy8gUmVhZCB0aGUgZWNhZCBwcm9wZXJ0eS4gVGhpcyBwcm9wZXJ0eSBsZXRzIHRoZSBhcHBsaWNhdGlvbiBrbm93IHdoYXQgXHJcbi8vIGVjYWQgc29mdHdhcmUgZ2VuZXJhdGVkIHRoZSBqc29uIGZpbGUuIFxyXG5mdW5jdGlvbiBHZXRDQURUeXBlKHBjYmRhdGFTdHJ1Y3R1cmUpXHJcbntcclxuICAgIGlmKHBjYmRhdGFTdHJ1Y3R1cmUuaGFzT3duUHJvcGVydHkoXCJlY2FkXCIpKXtcclxuICAgICAgICByZXR1cm4gcGNiZGF0YVN0cnVjdHVyZS5lY2FkO1xyXG4gICAgfVxyXG59XHJcblxyXG4vLyBUaGlzIHdpbGwgaG9sZCB0aGUgcGFydCBvYmplY3RzLiBUaGVyZSBpcyBvbmUgZW50cnkgcGVyIHBhcnRcclxuLy8gRm9ybWF0IG9mIGEgcGFydCBpcyBhcyBmb2xsb3dzXHJcbi8vIFtWQUxVRSxQQUNLQUdFLFJFRlJFTkVDRSBERVNJR05BVE9SLCAsTE9DQVRJT04sIEFUVFJJQlVURV0sXHJcbi8vIHdoZXJlIEFUVFJJQlVURSBpcyBhIGRpY3Qgb2YgQVRUUklCVVRFIE5BTUUgOiBBVFRSSUJVVEUgVkFMVUVcclxudmFyIEJPTSA9IFtdO1xyXG5cclxuLy8gQ29uc3RydWN0b3IgZm9yIGNyZWF0aW5nIGEgcGFydC5cclxuZnVuY3Rpb24gUGFydCh2YWx1ZSwgcGFja2FnZSwgcmVmZXJlbmNlLCBsb2NhdGlvbiwgYXR0cmlidXRlcykge1xyXG4gICAgdGhpcy5xdWFudGl0eSAgID0gMTtcclxuICAgIHRoaXMudmFsdWUgICAgICA9IHZhbHVlO1xyXG4gICAgdGhpcy5wYWNrYWdlICAgID0gcGFja2FnZTtcclxuICAgIHRoaXMucmVmZXJlbmNlICA9IHJlZmVyZW5jZTtcclxuICAgIHRoaXMubG9jYXRpb24gICA9IGxvY2F0aW9uO1xyXG4gICAgdGhpcy5hdHRyaWJ1dGVzID0gYXR0cmlidXRlcztcclxufVxyXG5cclxuZnVuY3Rpb24gQ29weVBhcnQoaW5wdXRQYXJ0KXtcclxuICAvLyBYWFg6IFRoaXMgaXMgbm90IHBlcmZvcm1pbmcgYSBkZWVwIGNvcHksIGF0dHJpYnV0ZXMgaXMgYSBtYXAgYW5kIHRoaXMgaXMgYmVpbmcgY29waWVkIGJ5IFxyXG4gIC8vICAgICAgcmVmZXJlbmNlIHdoaWNoIGlzIG5vdCBxdWl0ZSB3aGF0IHdlIHdhbnQgaGVyZS4gSXQgc2hvdWxkIGJlIGEgZGVlcCBjb3B5IHNvIG9uY2UgY2FsbGVkXHJcbiAgLy8gICAgICB0aGlzIHdpbGwgcmVzdWx0IGluIGEgY29tcGxldGVseSBuZXcgb2JqZWN0IHRoYXQgd2lsbCBub3QgcmVmZXJlbmNlIG9uZSBhbm90aGVyXHJcbiAgcmV0dXJuIG5ldyBQYXJ0KGlucHV0UGFydC52YWx1ZSwgaW5wdXRQYXJ0LnBhY2thZ2UsIGlucHV0UGFydC5yZWZlcmVuY2UsIGlucHV0UGFydC5sb2NhdGlvbiwgaW5wdXRQYXJ0LmF0dHJpYnV0ZXMpO1xyXG59XHJcblxyXG4vL1RPRE86IFRoZXJlIHNob3VsZCBiZSBzdGVwcyBoZXJlIGZvciB2YWxpZGF0aW5nIHRoZSBkYXRhIGFuZCBwdXR0aW5nIGl0IGludG8gYSBcclxuLy8gICAgICBmb3JtYXQgdGhhdCBpcyB2YWxpZCBmb3Igb3VyIGFwcGxpY2F0aW9uXHJcbmZ1bmN0aW9uIENyZWF0ZUJPTShwY2JkYXRhU3RydWN0dXJlKXtcclxuICAgIC8vIEZvciBldmVyeSBwYXJ0IGluIHRoZSBpbnB1dCBmaWxlLCBjb252ZXJ0IGl0IHRvIG91ciBpbnRlcm5hbCBcclxuICAgIC8vIHJlcHJlc2VudGF0aW9uIGRhdGEgc3RydWN0dXJlLlxyXG4gICAgZm9yKHZhciBwYXJ0IG9mIHBjYmRhdGFTdHJ1Y3R1cmUuYm9tLmJvdGgpe1xyXG4gICAgICAgIC8vIGV4dHJhY3QgdGhlIHBhcnQgZGF0YS4gVGhpcyBpcyBoZXJlIHNvIEkgY2FuIGl0ZXJhdGUgdGhlIGRlc2lnbiBcclxuICAgICAgICAvLyB3aGVuIEkgbWFrZSBjaGFuZ2VzIHRvIHRoZSB1bmRlcmx5aW5nIGpzb24gZmlsZS5cclxuICAgICAgICB2YXIgdmFsdWUgICAgID0gcGFydFsxXTtcclxuICAgICAgICB2YXIgcGFja2FnZSAgID0gcGFydFsyXTtcclxuICAgICAgICB2YXIgcmVmZXJlbmNlID0gcGFydFszXVswXTtcclxuICAgICAgICB2YXIgbG9jYXRpb24gID0gcGFydFs2XTtcclxuXHJcbiAgICAgICAgLy8gQXR0cmlidXRlTmFtZSBhbmQgQXR0cmlidXRlVmFsdWUgYXJlIHR3byBzdHJpbmdzIHRoYXQgYXJlIGRlbGltaW5hdGVkIGJ5ICc7Jy4gXHJcbiAgICAgICAgLy8gU3BsaXQgdGhlIHN0cmluZ3MgYnkgJzsnIGFuZCB0aGVuIHppcCB0aGVtIHRvZ2V0aGVyXHJcbiAgICAgICAgdmFyIGF0dHJpYnV0ZU5hbWVzID0gcGFydFs0XS5zcGxpdCgnOycpO1xyXG4gICAgICAgIHZhciBhdHRyaWJ1dGVWYWx1ZXMgPSBwYXJ0WzVdLnNwbGl0KCc7Jyk7XHJcblxyXG4gICAgICAgIC8vWFhYOiBBU1NVTVRJT04gdGhhdCBhdHRyaWJ1dGVOYW1lcyBpcyB0aGUgc2FtZSBsZW5ndGggYXMgYXR0cmlidXRlVmFsdWVzXHJcbiAgICAgICAgYXR0cmlidXRlcyA9IG5ldyBNYXAoKTsgLy8gQ3JlYXRlIGEgZW1wdHkgZGljdGlvbmFyeVxyXG4gICAgICAgIGZvcih2YXIgaSBpbiBhdHRyaWJ1dGVOYW1lcyl7XHJcbiAgICAgICAgICAgIGF0dHJpYnV0ZXMuc2V0KGF0dHJpYnV0ZU5hbWVzW2ldLnRvTG93ZXJDYXNlKCksYXR0cmlidXRlVmFsdWVzW2ldLnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBBZGQgdGhlIHBhciB0byB0aGUgZ2xvYmFsIHBhcnQgYXJyYXlcclxuICAgICAgICBCT00ucHVzaChuZXcgUGFydCh2YWx1ZSwgcGFja2FnZSwgcmVmZXJlbmNlLCBsb2NhdGlvbiwgYXR0cmlidXRlcykpO1xyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBHZXRCT00oKXtcclxuICAgICAgcmV0dXJuIEJPTTtcclxufVxyXG5cclxuLy8gVEFrZXMgYSBCT00gdGFibGUgYW5kIGEgZmlsdGVyIGZ1bmN0aW9uLiBUaGUgZmlsdGVyIFxyXG4vLyBmdW5jdGlvbiBpcyB1c2VkIG9udGhlIHByb3ZpZGVkIHRhYmxlIHRvIHJlbW92ZSBcclxuLy8gYW55IHBhcnQgdGhhdCBzYXRpc2Z5IHRoZSBmaWx0ZXJcclxuZnVuY3Rpb24gZmlsdGVyQk9NVGFibGUoYm9tdGFibGUsIGZpbHRlckZ1bmN0aW9uKXtcclxuICB2YXIgcmVzdWx0ID0gW107XHJcblxyXG4gIC8vIE1ha2VzIHN1cmUgdGhhdCB0aEUgZmlsdGVyIGZ1bmN0aW9uIGlzIGRlZmluZWQuIFxyXG4gIC8vIGlmIG5vdCBkZWZpbmVkIHRoZW4gbm90aGluZyBzaG91bGQgYmUgZmlsdGVyZWQuIFxyXG4gIGlmKGZpbHRlckZ1bmN0aW9uICE9IG51bGwpe1xyXG4gICAgZm9yKHZhciBpIGluIGJvbXRhYmxlKXtcclxuICAgICAgLy8gSWYgdGhlIGZpbHRlciByZXR1cm5zIGZhbHNlIC0+IGRvIG5vdCByZW1vdmUgcGFydCwgaXQgZG9lcyBub3QgbmVlZCB0byBiZSBmaWx0ZXJlZFxyXG4gICAgICBpZighZmlsdGVyRnVuY3Rpb24oYm9tdGFibGVbaV0pKXtcclxuICAgICAgICByZXN1bHQucHVzaChDb3B5UGFydChib210YWJsZVtpXSkpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIGVsc2V7XHJcbiAgICByZXN1bHQgPSBib210YWJsZTtcclxuICB9XHJcbiAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuLy8gVGFrZXMgYSBib20gdGFibGUgYW5kIGNvbWJpbmVzIGVudHJpZXMgdGhhdCBhcmUgdGhlIHNhbWVcclxuZnVuY3Rpb24gR2V0Qk9NQ29tYmluZWRWYWx1ZXMoYm9tdGFibGVUZW1wKXtcclxuICAgIHJlc3VsdCA9IFtdO1xyXG5cclxuICAgIC8vIFRPRE86IHNvcnQgYm9tdGFibGVUZW1wLiBBc3N1bXB0aW9uIGhlcmUgaXMgdGhhdCB0aGUgYm9tdGFibGVUZW1wIGlzIHByZXNvcnRlZFxyXG5cclxuICAgIGlmKGJvbXRhYmxlVGVtcC5sZW5ndGg+MCl7XHJcbiAgICAgIC8vIFhYWDogQXNzdW1pbmcgdGhhdCB0aGUgaW5wdXQganNvbiBkYXRhIGhhcyBib20gZW50cmllcyBwcmVzb3J0ZWRcclxuICAgICAgLy8gVE9ETzogU3RhcnQgYXQgaW5kZXggMSwgYW5kIGNvbXBhcmUgdGhlIGN1cnJlbnQgdG8gdGhlIGxhc3QsIHRoaXMgc2hvdWxkIHNpbXBsaWZ5IHRoZSBsb2dpY1xyXG4gICAgICAvLyBOZWVkIHRvIGNyZWF0ZSBhIG5ldyBvYmplY3QgYnkgZGVlcCBjb3B5LiB0aGlzIGlzIGJlY2F1c2Ugb2JqZWN0cyBieSBkZWZhdWx0IGFyZSBwYXNzZWQgYnkgcmVmZXJlbmNlIGFuZCBpIGRvbnQgXHJcbiAgICAgIC8vIHdhbnQgdG8gbW9kaWZ5IHRoZW0uXHJcbiAgICAgIHJlc3VsdC5wdXNoKENvcHlQYXJ0KGJvbXRhYmxlVGVtcFswXSkpO1xyXG4gICAgICBjb3VudCA9IDA7XHJcbiAgICAgIGZvciAodmFyIG4gPSAxOyBuIDwgYm9tdGFibGVUZW1wLmxlbmd0aDtuKyspXHJcbiAgICAgIHtcclxuICAgICAgICBpZihyZXN1bHRbY291bnRdLnZhbHVlID09IGJvbXRhYmxlVGVtcFtuXS52YWx1ZSlcclxuICAgICAgICB7XHJcbiAgICAgICAgICAvLyBGb3IgcGFydHMgdGhhdCBhcmUgbGlzdGVkIGFzIGNvbWJpbmVkLCBzdG9yZSB0aGUgcmVmZXJlbmNlcyBhcyBhbiBhcnJheS5cclxuICAgICAgICAgIC8vIFRoaXMgaXMgYmVjYXVzZSB0aGUgbG9naWMgZm9yIGhpZ2hsaWdodGluZyBuZWVkcyB0byBtYXRjaCBzdHJpbmdzIGFuZCBcclxuICAgICAgICAgIC8vIElmIGFuIGFwcGVuZGVkIHN0cmluZyBpcyB1c2VkIGl0IG1pZ2h0IG5vdCB3b3JrIHJpZ2h0XHJcbiAgICAgICAgICByZWZTdHJpbmcgPSByZXN1bHRbY291bnRdLnJlZmVyZW5jZSArIFwiLFwiICsgYm9tdGFibGVUZW1wW25dLnJlZmVyZW5jZTtcclxuICAgICAgICAgIHJlc3VsdFtjb3VudF0ucXVhbnRpdHkgKz0gMTtcclxuICAgICAgICAgIHJlc3VsdFtjb3VudF0ucmVmZXJlbmNlID0gcmVmU3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcmVzdWx0LnB1c2goQ29weVBhcnQoYm9tdGFibGVUZW1wW25dKSk7XHJcbiAgICAgICAgICBjb3VudCsrO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0QXR0cmlidXRlVmFsdWUocGFydCwgYXR0cmlidXRlVG9Mb29rdXApe1xyXG4gICAgdmFyIGF0dHJpYnV0ZXMgPSBwYXJ0LmF0dHJpYnV0ZXM7XHJcbiAgICB2YXIgcmVzdWx0ID0gXCJcIjtcclxuXHJcbiAgICBpZihhdHRyaWJ1dGVUb0xvb2t1cCA9PSBcIm5hbWVcIilcclxuICAgIHtcclxuICAgICAgcmVzdWx0ID0gcGFydC5yZWZlcmVuY2U7XHJcbiAgICB9XHJcbiAgICBlbHNlXHJcbiAgICB7XHJcbiAgICAgIHJlc3VsdCA9IChhdHRyaWJ1dGVzLmhhcyhhdHRyaWJ1dGVUb0xvb2t1cCkgPyBhdHRyaWJ1dGVzLmdldChhdHRyaWJ1dGVUb0xvb2t1cCkgOiBcIlwiKTtcclxuICAgIH1cclxuICAgIC8vIENoZWNrIHRoYXQgdGhlIGF0dHJpYnV0ZSBleGlzdHMgYnkgbG9va2luZyB1cCBpdHMgbmFtZS4gSWYgaXQgZXhpc3RzXHJcbiAgICAvLyB0aGUgcmV0dXJuIHRoZSB2YWx1ZSBmb3IgdGhlIGF0dHJpYnV0ZSwgb3RoZXJ3aXNlIHJldHVybiBhbiBlbXB0eSBzdHJpbmcuIFxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBDQiBNZXRhZGF0YSBJbnRlcmZhY2VzXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxudmFyIG1ldGFkYXRhO1xyXG4vLyBDb25zdHJ1Y3RvciBmb3IgY3JlYXRpbmcgYSBwYXJ0LlxyXG5mdW5jdGlvbiBNZXRhZGF0YSh0aXRsZSwgcmV2aXNpb24sIGNvbXBhbnksIGRhdGUpIHtcclxuICAgIHRoaXMudGl0bGUgICAgPSB0aXRsZTtcclxuICAgIHRoaXMucmV2aXNpb24gPSByZXZpc2lvbjtcclxuICAgIHRoaXMuY29tcGFueSAgPSBjb21wYW55O1xyXG4gICAgdGhpcy5kYXRlICAgICA9IGRhdGU7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIENyZWF0ZU1ldGFkYXRhKHBjYmRhdGFTdHJ1Y3R1cmUpe1xyXG4gIG1ldGFkYXRhID0gbmV3IE1ldGFkYXRhKHBjYmRhdGFTdHJ1Y3R1cmUubWV0YWRhdGEudGl0bGUgICwgcGNiZGF0YVN0cnVjdHVyZS5tZXRhZGF0YS5yZXZpc2lvbiwgXHJcbiAgICAgICAgICAgICAgICAgICAgICBwY2JkYXRhU3RydWN0dXJlLm1ldGFkYXRhLmNvbXBhbnksIHBjYmRhdGFTdHJ1Y3R1cmUubWV0YWRhdGEuZGF0ZSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIEdldE1ldGFkYXRhKCl7XHJcbiAgcmV0dXJuIG1ldGFkYXRhO1xyXG59XHJcblxyXG5cclxuXHJcbmZ1bmN0aW9uIE9wZW5QY2JEYXRhKHBjYmRhdGEpe1xyXG4gIENyZWF0ZUJPTShwY2JkYXRhKTtcclxuICBDcmVhdGVNZXRhZGF0YShwY2JkYXRhKTtcclxufVxyXG5cclxubW9kdWxlLmV4cG9ydHMgPSB7XHJcbiAgT3BlblBjYkRhdGEsIEdldEJPTSwgZ2V0QXR0cmlidXRlVmFsdWUsIEdldEJPTUNvbWJpbmVkVmFsdWVzLCBmaWx0ZXJCT01UYWJsZSwgR2V0TWV0YWRhdGFcclxufSIsInZhciBwY2JGb250ID0ge1xyXG4gICAgXCJmb250X2RhdGFcIjoge1xyXG4gICAgICAgIFwiIFwiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuNzYxOTA0NzYxOTA0NzYxOVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCIjXCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC45MDQ3NjE5MDQ3NjE5MDQ3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43MTQyODU3MTQyODU3MTQyXHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNDc2MTkwNDc2MTkwNDc2MTYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjE0Mjg1NzE0Mjg1NzE0MjhcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xNDI4NTcxNDI4NTcxNDI4NVxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjgwOTUyMzgwOTUyMzgwOTUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjI4NTcxNDI4NTcxNDI4NTdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4wOTUyMzgwOTUyMzgwOTUyMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMjg1NzE0Mjg1NzE0Mjg1N1xyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjUyMzgwOTUyMzgwOTUyMzcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTQyODU3MTQyODU3MTQyODVcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC44MDk1MjM4MDk1MjM4MDk1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4xNDI4NTcxNDI4NTcxNDI4XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMS4wXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIi1cIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgxNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNDI4NTcxNDI4NTcxNDI4NTVcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMS4wLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC40Mjg1NzE0Mjg1NzE0Mjg1NVxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDEuMjM4MDk1MjM4MDk1MjM4MVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCIuXCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjg1NzE0Mjg1NzE0Mjg1NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA5NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICB9LFxyXG4gICAgICAgIFwiMFwiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjQyODU3MTQyODU3MTQyODU1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTIzODA5NTIzODA5NTIzNyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjYxOTA0NzYxOTA0NzYxOTEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjBcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC45NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuODU3MTQyODU3MTQyODU3MVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjY2NjY2NjY2NjY2NjY2NjZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43NjE5MDQ3NjE5MDQ3NjE5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC40Mjg1NzE0Mjg1NzE0Mjg1NVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjcxNDI4NTcxNDI4NTcxNDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjIzODA5NTIzODA5NTIzODA4XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMTQyODU3MTQyODU3MTQyODVcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTkxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjUyMzgwOTUyMzgwOTUyMzcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjQyODU3MTQyODU3MTQyODU1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zMzMzMzMzMzMzMzMzMzMzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjIzODA5NTIzODA5NTIzODA4XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjQyODU3MTQyODU3MTQyODU1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjY2NjY2NjY2NjY2NjY2NjZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuODU3MTQyODU3MTQyODU3MVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zMzMzMzMzMzMzMzMzMzMzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNDI4NTcxNDI4NTcxNDI4NTUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIFwid1wiOiAwLjk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICB9LFxyXG4gICAgICAgIFwiMVwiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjE5MDQ3NjE5MDQ3NjE5MDQ3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC40NzYxOTA0NzYxOTA0NzYxNixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNDc2MTkwNDc2MTkwNDc2MTYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuOTA0NzYxOTA0NzYxOTA0N1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjgwOTUyMzgwOTUyMzgwOTVcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzYxOTA0NzYxOTA0NzYxOVxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCIyXCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjMzMzMzMzMzMzMzMzMzMzMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41NzE0Mjg1NzE0Mjg1NzE0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjcxNDI4NTcxNDI4NTcxNDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43NjE5MDQ3NjE5MDQ3NjE5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC44NTcxNDI4NTcxNDI4NTcxXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzYxOTA0NzYxOTA0NzYxOVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjcxNDI4NTcxNDI4NTcxNDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjYxOTA0NzYxOTA0NzYxOTFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xNDI4NTcxNDI4NTcxNDI4NSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC45NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIjNcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xNDI4NTcxNDI4NTcxNDI4NSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC40Mjg1NzE0Mjg1NzE0Mjg1NSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjY2NjY2NjY2NjY2NjY2NlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjU3MTQyODU3MTQyODU3MTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjY2NjY2NjY2NjY2NjY2NjZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42MTkwNDc2MTkwNDc2MTkxXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTcxNDI4NTcxNDI4NTcxNFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMjM4MDk1MjM4MDk1MjM4MDhcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43MTQyODU3MTQyODU3MTQyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xNDI4NTcxNDI4NTcxNDI4NVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA5NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTcxNDI4NTcxNDI4NTcxNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjg1NzE0Mjg1NzE0Mjg1NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA5NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTQyODU3MTQyODU3MTQyODUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC45NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIjRcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43MTQyODU3MTQyODU3MTQyXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNDI4NTcxNDI4NTcxNDI4NTUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA5NTIzODA5NTIzODA5NTFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMzgwOTUyMzgwOTUyMzgwOTNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC44MDk1MjM4MDk1MjM4MDk1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4zODA5NTIzODA5NTIzODA5M1xyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCI1XCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjU3MTQyODU3MTQyODU3MTRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjE5MDQ3NjE5MDQ3NjE5MVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjMzMzMzMzMzMzMzMzMzMzMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjY2NjY2NjY2NjY2NjY2NjZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41NzE0Mjg1NzE0Mjg1NzE0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42NjY2NjY2NjY2NjY2NjY2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjE5MDQ3NjE5MDQ3NjE5MVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjcxNDI4NTcxNDI4NTcxNDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjU3MTQyODU3MTQyODU3MTRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43NjE5MDQ3NjE5MDQ3NjE5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC40NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjIzODA5NTIzODA5NTIzODA4XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMTQyODU3MTQyODU3MTQyODVcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjU3MTQyODU3MTQyODU3MTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjMzMzMzMzMzMzMzMzMzMzMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjE5MDQ3NjE5MDQ3NjE5MDQ3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xNDI4NTcxNDI4NTcxNDI4NVxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCI6XCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjg1NzE0Mjg1NzE0Mjg1NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA5NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42NjY2NjY2NjY2NjY2NjY2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjg1NzE0Mjg1NzE0Mjg1NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjE5MDQ3NjE5MDQ3NjE5MVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC41NzE0Mjg1NzE0Mjg1NzE0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjYxOTA0NzYxOTA0NzYxOTFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjY2NjY2NjY2NjY2NjY2NlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC41NzE0Mjg1NzE0Mjg1NzE0XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC40NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCJBXCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjMzMzMzMzMzMzMzMzMzMzNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4zMzMzMzMzMzMzMzMzMzMzXHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMDk1MjM4MDk1MjM4MDk1MjMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjQyODU3MTQyODU3MTQyODU1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC44NTcxNDI4NTcxNDI4NTcxXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIkJcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41NzE0Mjg1NzE0Mjg1NzE0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC41NzE0Mjg1NzE0Mjg1NzE0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTIzODA5NTIzODA5NTIzN1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuODA5NTIzODA5NTIzODA5NCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMzgwOTUyMzgwOTUyMzgwOTNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC44MDk1MjM4MDk1MjM4MDk0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4yMzgwOTUyMzgwOTUyMzgwOFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODAzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjU3MTQyODU3MTQyODU3MTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjg1NzE0Mjg1NzE0Mjg1NzFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43NjE5MDQ3NjE5MDQ3NjE5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43NjE5MDQ3NjE5MDQ3NjE5XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjY2NjY2NjY2NjY2NjY2NlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjYxOTA0NzYxOTA0NzYxOTFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41NzE0Mjg1NzE0Mjg1NzE0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC41NzE0Mjg1NzE0Mjg1NzE0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjU3MTQyODU3MTQyODU3MTRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIFwid1wiOiAxLjBcclxuICAgICAgICB9LFxyXG4gICAgICAgIFwiQ1wiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjgwOTUyMzgwOTUyMzgwOTUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTkxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41MjM4MDk1MjM4MDk1MjM3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yODU3MTQyODU3MTQyODU3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xOTA0NzYxOTA0NzYxOTA0N1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4yODU3MTQyODU3MTQyODU3XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjYxOTA0NzYxOTA0NzYxOTFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuODA5NTIzODA5NTIzODA5NVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjkwNDc2MTkwNDc2MTkwNDdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjUyMzgwOTUyMzgwOTUyMzcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTkxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjgwOTUyMzgwOTUyMzgwOTUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIFwid1wiOiAxLjBcclxuICAgICAgICB9LFxyXG4gICAgICAgIFwiRFwiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODAzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjQ3NjE5MDQ3NjE5MDQ3NjEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjBcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43MTQyODU3MTQyODU3MTQyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC45MDQ3NjE5MDQ3NjE5MDQ3XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuODA5NTIzODA5NTIzODA5NVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjgwOTUyMzgwOTUyMzgwOTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjYxOTA0NzYxOTA0NzYxOTFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC44MDk1MjM4MDk1MjM4MDk0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC40NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjI4NTcxNDI4NTcxNDI4NTdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43MTQyODU3MTQyODU3MTQyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xOTA0NzYxOTA0NzYxOTA0N1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC40NzYxOTA0NzYxOTA0NzYxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMS4wXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIkVcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTcxNDI4NTcxNDI4NTcxNFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjU3MTQyODU3MTQyODU3MTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjU3MTQyODU3MTQyODU3MTRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43MTQyODU3MTQyODU3MTQyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43MTQyODU3MTQyODU3MTQyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC45MDQ3NjE5MDQ3NjE5MDQ3XHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIkZcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41NzE0Mjg1NzE0Mjg1NzE0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC41NzE0Mjg1NzE0Mjg1NzE0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjU3MTQyODU3MTQyODU3MTRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43MTQyODU3MTQyODU3MTQyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC44NTcxNDI4NTcxNDI4NTcxXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIkdcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43NjE5MDQ3NjE5MDQ3NjE5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjUyMzgwOTUyMzgwOTUyMzcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjkwNDc2MTkwNDc2MTkwNDdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuODA5NTIzODA5NTIzODA5NVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjE5MDQ3NjE5MDQ3NjE5MDQ3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42MTkwNDc2MTkwNDc2MTkxXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjI4NTcxNDI4NTcxNDI4NTdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yODU3MTQyODU3MTQyODU3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xOTA0NzYxOTA0NzYxOTA0N1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjM4MDk1MjM4MDk1MjM4MDkzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjUyMzgwOTUyMzgwOTUyMzcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjYxOTA0NzYxOTA0NzYxOTEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA5NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuODA5NTIzODA5NTIzODA5NSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMTQyODU3MTQyODU3MTQyODVcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC44MDk1MjM4MDk1MjM4MDk1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC40NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjYxOTA0NzYxOTA0NzYxOTEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMS4wXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIklcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIFwid1wiOiAwLjQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIkpcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41MjM4MDk1MjM4MDk1MjM3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTIzODA5NTIzODA5NTIzNyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMzMzMzMzMzMzMzMzMzMzM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjQ3NjE5MDQ3NjE5MDQ3NjE2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xOTA0NzYxOTA0NzYxOTA0N1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjM4MDk1MjM4MDk1MjM4MDkzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xNDI4NTcxNDI4NTcxNDI4NSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC43NjE5MDQ3NjE5MDQ3NjE5XHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIkxcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43MTQyODU3MTQyODU3MTQyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIFwid1wiOiAwLjgwOTUyMzgwOTUyMzgwOTVcclxuICAgICAgICB9LFxyXG4gICAgICAgIFwiTVwiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjU3MTQyODU3MTQyODU3MTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjMzMzMzMzMzMzMzMzMzMzNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC45MDQ3NjE5MDQ3NjE5MDQ3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMS4xNDI4NTcxNDI4NTcxNDI4XHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIk5cIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC44MDk1MjM4MDk1MjM4MDk0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC44MDk1MjM4MDk1MjM4MDk0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIlBcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43MTQyODU3MTQyODU3MTQyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjgwOTUyMzgwOTUyMzgwOTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjg1NzE0Mjg1NzE0Mjg1NzFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC44MDk1MjM4MDk1MjM4MDk0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43MTQyODU3MTQyODU3MTQyXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjE5MDQ3NjE5MDQ3NjE5MVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjcxNDI4NTcxNDI4NTcxNDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjU3MTQyODU3MTQyODU3MTRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjUyMzgwOTUyMzgwOTUyMzdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTIzODA5NTIzODA5NTIzN1xyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDEuMFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCJSXCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuODA5NTIzODA5NTIzODA5NCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNDc2MTkwNDc2MTkwNDc2MSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTIzODA5NTIzODA5NTIzN1xyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODAzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjcxNDI4NTcxNDI4NTcxNDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjBcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43NjE5MDQ3NjE5MDQ3NjE5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC45NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuODA5NTIzODA5NTIzODA5NCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuODU3MTQyODU3MTQyODU3MVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjgwOTUyMzgwOTUyMzgwOTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43NjE5MDQ3NjE5MDQ3NjE5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42MTkwNDc2MTkwNDc2MTkxXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTcxNDI4NTcxNDI4NTcxNFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTIzODA5NTIzODA5NTIzN1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODAzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC41MjM4MDk1MjM4MDk1MjM3XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMS4wXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIlNcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zMzMzMzMzMzMzMzMzMzMzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41NzE0Mjg1NzE0Mjg1NzE0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjcxNDI4NTcxNDI4NTcxNDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMjM4MDk1MjM4MDk1MjM4MDhcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43NjE5MDQ3NjE5MDQ3NjE5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4zMzMzMzMzMzMzMzMzMzMzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNDI4NTcxNDI4NTcxNDI4NTVcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC40NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjU3MTQyODU3MTQyODU3MTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjUyMzgwOTUyMzgwOTUyMzdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTcxNDI4NTcxNDI4NTcxNFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjYxOTA0NzYxOTA0NzYxOTFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjY2NjY2NjY2NjY2NjY2NlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjE5MDQ3NjE5MDQ3NjE5MDQ3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43NjE5MDQ3NjE5MDQ3NjE5XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjg1NzE0Mjg1NzE0Mjg1NzFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjBcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjYxOTA0NzYxOTA0NzYxOTEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43NjE5MDQ3NjE5MDQ3NjE5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wXHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC45NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIlVcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODAzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4yMzgwOTUyMzgwOTUyMzgwOFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTY0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xNDI4NTcxNDI4NTcxNDI4NVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjMzMzMzMzMzMzMzMzMzMzI2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjQyODU3MTQyODU3MTQyODUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzE0Mjg1NzE0Mjg1NzE0MixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43NjE5MDQ3NjE5MDQ3NjE5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xNDI4NTcxNDI4NTcxNDI4NVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjgwOTUyMzgwOTUyMzgwOTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjIzODA5NTIzODA5NTIzODA4XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuODA5NTIzODA5NTIzODA5NCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCJWXCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMDk1MjM4MDk1MjM4MDk1MjMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC40Mjg1NzE0Mjg1NzE0Mjg1NSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNzYxOTA0NzYxOTA0NzYxOSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuODU3MTQyODU3MTQyODU3MVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCJXXCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTQyODU3MTQyODU3MTQyODUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTcxNDI4NTcxNDI4NTcxNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzYxOTA0NzYxOTA0NzYxOVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjc2MTkwNDc2MTkwNDc2MTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAxLjAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIFwid1wiOiAxLjE0Mjg1NzE0Mjg1NzE0MjhcclxuICAgICAgICB9LFxyXG4gICAgICAgIFwiWFwiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjE0Mjg1NzE0Mjg1NzE0Mjg1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuODA5NTIzODA5NTIzODA5NSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuODA5NTIzODA5NTIzODA5NSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjE0Mjg1NzE0Mjg1NzE0Mjg1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIFwid1wiOiAwLjk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICB9LFxyXG4gICAgICAgIFwiYVwiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjU3MTQyODU3MTQyODU3MTRcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTkxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42NjY2NjY2NjY2NjY2NjY2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTIzODA5NTIzODA5NTIzNyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjMzMzMzMzMzMzMzMzMzMzMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjY2NjY2NjY2NjY2NjY2NlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA5NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTcxNDI4NTcxNDI4NTcxNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMzMzMzMzMzMzMzMzMzMzMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA5NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE5MDQ3NjE5MDQ3NjE5MDQ3XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjI4NTcxNDI4NTcxNDI4NTdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMzgwOTUyMzgwOTUyMzgwOTNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zMzMzMzMzMzMzMzMzMzMzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC40Mjg1NzE0Mjg1NzE0Mjg1NVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjU3MTQyODU3MTQyODU3MTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjQyODU3MTQyODU3MTQyODU1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIFwid1wiOiAwLjkwNDc2MTkwNDc2MTkwNDdcclxuICAgICAgICB9LFxyXG4gICAgICAgIFwiZFwiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjA0NzYxOTA0NzYxOTA0NzRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjU3MTQyODU3MTQyODU3MTQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjM4MDk1MjM4MDk1MjM4MDkzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yODU3MTQyODU3MTQyODU3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xNDI4NTcxNDI4NTcxNDI4NVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjE5MDQ3NjE5MDQ3NjE5MDQ3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4yMzgwOTUyMzgwOTUyMzgwOFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjE5MDQ3NjE5MDQ3NjE5MDQ3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC41MjM4MDk1MjM4MDk1MjM3XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjYxOTA0NzYxOTA0NzYxOTFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yODU3MTQyODU3MTQyODU3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42NjY2NjY2NjY2NjY2NjY2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMzgwOTUyMzgwOTUyMzgwOTMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41NzE0Mjg1NzE0Mjg1NzE0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43MTQyODU3MTQyODU3MTQyXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjY2NjY2NjY2NjY2NjY2NlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuOTA0NzYxOTA0NzYxOTA0N1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCJlXCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjE5MDQ3NjE5MDQ3NjE5MSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41MjM4MDk1MjM4MDk1MjM3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zMzMzMzMzMzMzMzMzMzMzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMTkwNDc2MTkwNDc2MTkwNDdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTcxNDI4NTcxNDI4NTcxNFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42NjY2NjY2NjY2NjY2NjY2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMzMzMzMzMzMzMzMzMzMzMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjUyMzgwOTUyMzgwOTUyMzcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTkxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42NjY2NjY2NjY2NjY2NjY2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTcxNDI4NTcxNDI4NTcxNFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjM4MDk1MjM4MDk1MjM4MDkzXHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC44NTcxNDI4NTcxNDI4NTcxXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcImdcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43MTQyODU3MTQyODU3MTQyXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjYxOTA0NzYxOTA0NzYxOTEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41NzE0Mjg1NzE0Mjg1NzE0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNDc2MTkwNDc2MTkwNDc2MTYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjg1NzE0Mjg1NzE0Mjg1N1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjMzMzMzMzMzMzMzMzMzMzMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjg1NzE0Mjg1NzE0Mjg1N1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41NzE0Mjg1NzE0Mjg1NzE0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjg1NzE0Mjg1NzE0Mjg1NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMTQyODU3MTQyODU3MTQyODVcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMjM4MDk1MjM4MDk1MjM4MDhcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTIzODA5NTIzODA5NTIzN1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42MTkwNDc2MTkwNDc2MTkxXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjg1NzE0Mjg1NzE0Mjg1NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjY2NjY2NjY2NjY2NjY2NlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjM4MDk1MjM4MDk1MjM4MDkzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43MTQyODU3MTQyODU3MTQyXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTcxNDI4NTcxNDI4NTcxNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjY2NjY2NjY2NjY2NjY2NjZcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIFwid1wiOiAwLjkwNDc2MTkwNDc2MTkwNDdcclxuICAgICAgICB9LFxyXG4gICAgICAgIFwiaVwiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjBcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xLjBcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTEuMDQ3NjE5MDQ3NjE5MDQ3NFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC45NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC40NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCJrXCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMzMzMzMzMzMzMzMzMzMzMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNDI4NTcxNDI4NTcxNDI4NTVcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTkxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTkxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43MTQyODU3MTQyODU3MTQyXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjMzMzMzMzMzMzMzMzMzMzNcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIFwid1wiOiAwLjgwOTUyMzgwOTUyMzgwOTVcclxuICAgICAgICB9LFxyXG4gICAgICAgIFwibFwiOiB7XHJcbiAgICAgICAgICAgIFwibFwiOiBbXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjM4MDk1MjM4MDk1MjM4MDkzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yODU3MTQyODU3MTQyODU3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wOTUyMzgwOTUyMzgwOTUyM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xOTA0NzYxOTA0NzYxOTA0N1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC41MjM4MDk1MjM4MDk1MjM3XHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIm5cIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjE5MDQ3NjE5MDQ3NjE5MVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjY2NjY2NjY2NjY2NjY2NjZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjUyMzgwOTUyMzgwOTUyMzcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTkxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42NjY2NjY2NjY2NjY2NjY2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTcxNDI4NTcxNDI4NTcxNFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuOTA0NzYxOTA0NzYxOTA0N1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCJvXCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMzgwOTUyMzgwOTUyMzgwOTMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA5NTIzODA5NTIzODA5NTIzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjIzODA5NTIzODA5NTIzODA4XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjUyMzgwOTUyMzgwOTUyMzdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjE5MDQ3NjE5MDQ3NjE5MVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjY2NjY2NjY2NjY2NjY2NjZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjUyMzgwOTUyMzgwOTUyMzcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTkxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42NjY2NjY2NjY2NjY2NjY2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjE5MDQ3NjE5MDQ3NjE5MVxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjcxNDI4NTcxNDI4NTcxNDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjUyMzgwOTUyMzgwOTUyMzdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC43MTQyODU3MTQyODU3MTQyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4yMzgwOTUyMzgwOTUyMzgwOFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE0Mjg1NzE0Mjg1NzE0Mjg1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjE5MDQ3NjE5MDQ3NjE5MSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41MjM4MDk1MjM4MDk1MjM3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC45MDQ3NjE5MDQ3NjE5MDQ3XHJcbiAgICAgICAgfSxcclxuICAgICAgICBcInJcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yMzgwOTUyMzgwOTUyMzgwOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTIzODA5NTIzODA5NTIzN1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjI4NTcxNDI4NTcxNDI4NTcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjYxOTA0NzYxOTA0NzYxOTFcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zMzMzMzMzMzMzMzMzMzMzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42NjY2NjY2NjY2NjY2NjY2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNDI4NTcxNDI4NTcxNDI4NTUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC41MjM4MDk1MjM4MDk1MjM3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43MTQyODU3MTQyODU3MTQyXHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBcIndcIjogMC42MTkwNDc2MTkwNDc2MTkxXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcInNcIjoge1xyXG4gICAgICAgICAgICBcImxcIjogW1xyXG4gICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4yODU3MTQyODU3MTQyODU3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4wNDc2MTkwNDc2MTkwNDc2MTZcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC40NzYxOTA0NzYxOTA0NzYxNixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTcxNDI4NTcxNDI4NTcxNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42MTkwNDc2MTkwNDc2MTkxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xOTA0NzYxOTA0NzYxOTA0N1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjYxOTA0NzYxOTA0NzYxOTEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjIzODA5NTIzODA5NTIzODA4XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTcxNDI4NTcxNDI4NTcxNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMzMzMzMzMzMzMzMzMzMzM1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjQ3NjE5MDQ3NjE5MDQ3NjE2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4zODA5NTIzODA5NTIzODA5M1xyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjMzMzMzMzMzMzMzMzMzMzMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjM4MDk1MjM4MDk1MjM4MDkzXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjQyODU3MTQyODU3MTQyODU1XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTkwNDc2MTkwNDc2MTkwNDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjUyMzgwOTUyMzgwOTUyMzdcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4xOTA0NzYxOTA0NzYxOTA0NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNTcxNDI4NTcxNDI4NTcxNFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC42NjY2NjY2NjY2NjY2NjY2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMzMzMzMzMzMzMzMzMzMzMyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjQ3NjE5MDQ3NjE5MDQ3NjE2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43MTQyODU3MTQyODU3MTQyXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTcxNDI4NTcxNDI4NTcxNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNjY2NjY2NjY2NjY2NjY2NlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuODA5NTIzODA5NTIzODA5NVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCJ0XCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMDk1MjM4MDk1MjM4MDk1MjMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC40NzYxOTA0NzYxOTA0NzYxNixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMS4wNDc2MTkwNDc2MTkwNDc0XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE5MDQ3NjE5MDQ3NjE5MDQ3XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjg1NzE0Mjg1NzE0Mjg1NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNDc2MTkwNDc2MTkwNDc2MTYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuNTcxNDI4NTcxNDI4NTcxNFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCJ1XCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjY2NjY2NjY2NjY2NjY2NixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjY2NjY2NjY2NjY2NjY2NjYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjA0NzYxOTA0NzYxOTA0NzYxNlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwLjIzODA5NTIzODA5NTIzODA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC43MTQyODU3MTQyODU3MTQyXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjM4MDk1MjM4MDk1MjM4MDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjE5MDQ3NjE5MDQ3NjE5MDQ3XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMjg1NzE0Mjg1NzE0Mjg1NyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNTIzODA5NTIzODA5NTIzNyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjE5MDQ3NjE5MDQ3NjE5MSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDk1MjM4MDk1MjM4MDk1MjNcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC42NjY2NjY2NjY2NjY2NjY2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtMC4xNDI4NTcxNDI4NTcxNDI4NVxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuOTA0NzYxOTA0NzYxOTA0N1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXCJ2XCI6IHtcclxuICAgICAgICAgICAgXCJsXCI6IFtcclxuICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuMTQyODU3MTQyODU3MTQyODUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0wLjcxNDI4NTcxNDI4NTcxNDJcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgMC4zODA5NTIzODA5NTIzODA5MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuMDQ3NjE5MDQ3NjE5MDQ3NjE2XHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDAuNjE5MDQ3NjE5MDQ3NjE5MSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLTAuNzE0Mjg1NzE0Mjg1NzE0MlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgXCJ3XCI6IDAuNzYxOTA0NzYxOTA0NzYxOVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSIsIi8qIFBDQiByZW5kZXJpbmcgY29kZSAqL1xyXG5cclxudmFyIGdsb2JhbERhdGEgPSByZXF1aXJlKCcuL2dsb2JhbC5qcycpXHJcblxyXG5mdW5jdGlvbiBkZWcycmFkKGRlZykge1xyXG4gIHJldHVybiBkZWcgKiBNYXRoLlBJIC8gMTgwO1xyXG59XHJcblxyXG5mdW5jdGlvbiBjYWxjRm9udFBvaW50KGxpbmVwb2ludCwgdGV4dCwgb2Zmc2V0eCwgb2Zmc2V0eSwgdGlsdCkge1xyXG4gIHZhciBwb2ludCA9IFtcclxuICAgIGxpbmVwb2ludFswXSAqIHRleHQud2lkdGggKyBvZmZzZXR4LFxyXG4gICAgbGluZXBvaW50WzFdICogdGV4dC5oZWlnaHQgKyBvZmZzZXR5XHJcbiAgXTtcclxuICAvLyBBZGRpbmcgaGFsZiBhIGxpbmUgaGVpZ2h0IGhlcmUgaXMgdGVjaG5pY2FsbHkgYSBidWdcclxuICAvLyBidXQgcGNibmV3IGN1cnJlbnRseSBkb2VzIHRoZSBzYW1lLCB0ZXh0IGlzIHNsaWdodGx5IHNoaWZ0ZWQuXHJcbiAgcG9pbnRbMF0gLT0gKHBvaW50WzFdICsgdGV4dC5oZWlnaHQgKiAwLjUpICogdGlsdDtcclxuICByZXR1cm4gcG9pbnQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRyYXd0ZXh0KGN0eCwgdGV4dCwgY29sb3IsIGZsaXApIHtcclxuICBjdHguc2F2ZSgpO1xyXG4gIGN0eC50cmFuc2xhdGUoLi4udGV4dC5wb3MpO1xyXG4gIHZhciBhbmdsZSA9IC10ZXh0LmFuZ2xlO1xyXG4gIGlmICh0ZXh0LmF0dHIuaW5jbHVkZXMoXCJtaXJyb3JlZFwiKSkge1xyXG4gICAgY3R4LnNjYWxlKC0xLCAxKTtcclxuICAgIGFuZ2xlID0gLWFuZ2xlO1xyXG4gIH1cclxuICB2YXIgdGlsdCA9IDA7XHJcbiAgaWYgKHRleHQuYXR0ci5pbmNsdWRlcyhcIml0YWxpY1wiKSkge1xyXG4gICAgdGlsdCA9IDAuMTI1O1xyXG4gIH1cclxuICB2YXIgaW50ZXJsaW5lID0gKHRleHQuaGVpZ2h0ICogMS41ICsgdGV4dC50aGlja25lc3MpIC8gMjtcclxuICB2YXIgdHh0ID0gdGV4dC50ZXh0LnNwbGl0KFwiXFxuXCIpO1xyXG4gIGN0eC5yb3RhdGUoZGVnMnJhZChhbmdsZSkpO1xyXG4gIGN0eC5maWxsU3R5bGUgPSBjb2xvcjtcclxuICBjdHguc3Ryb2tlU3R5bGUgPSBjb2xvcjtcclxuICBjdHgubGluZUNhcCA9IFwicm91bmRcIjtcclxuICBjdHgubGluZVdpZHRoID0gdGV4dC50aGlja25lc3M7XHJcbiAgZm9yICh2YXIgaSBpbiB0eHQpIHtcclxuICAgIHZhciBvZmZzZXR5ID0gKC0odHh0Lmxlbmd0aCAtIDEpICsgaSAqIDIpICogaW50ZXJsaW5lICsgdGV4dC5oZWlnaHQgLyAyO1xyXG4gICAgdmFyIGxpbmVXaWR0aCA9IDA7XHJcbiAgICBmb3IgKHZhciBjIG9mIHR4dFtpXSkge1xyXG4gICAgICBsaW5lV2lkdGggKz0gcGNiRm9udC5mb250X2RhdGFbY10udyAqIHRleHQud2lkdGg7XHJcbiAgICB9XHJcbiAgICB2YXIgb2Zmc2V0eCA9IDA7XHJcbiAgICBzd2l0Y2ggKHRleHQuaG9yaXpfanVzdGlmeSkge1xyXG4gICAgICBjYXNlIC0xOlxyXG4gICAgICAgIC8vIEp1c3RpZnkgbGVmdCwgZG8gbm90aGluZ1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlIDA6XHJcbiAgICAgICAgLy8gSnVzdGlmeSBjZW50ZXJcclxuICAgICAgICBvZmZzZXR4IC09IGxpbmVXaWR0aCAvIDI7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgMTpcclxuICAgICAgICAvLyBKdXN0aWZ5IHJpZ2h0XHJcbiAgICAgICAgb2Zmc2V0eCAtPSBsaW5lV2lkdGg7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgICBmb3IgKHZhciBjIG9mIHR4dFtpXSkge1xyXG4gICAgICBmb3IgKHZhciBsaW5lIG9mIHBjYkZvbnQuZm9udF9kYXRhW2NdLmwpIHtcclxuICAgICAgICAvLyBEcmF3aW5nIGVhY2ggc2VnbWVudCBzZXBhcmF0ZWx5IGluc3RlYWQgb2ZcclxuICAgICAgICAvLyBwb2x5bGluZSBiZWNhdXNlIHJvdW5kIGxpbmUgY2FwcyBkb24ndCB3b3JrIGluIGpvaW50c1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGluZS5sZW5ndGggLSAxOyBpKyspIHtcclxuICAgICAgICAgIGN0eC5iZWdpblBhdGgoKTtcclxuICAgICAgICAgIGN0eC5tb3ZlVG8oLi4uY2FsY0ZvbnRQb2ludChsaW5lW2ldLCB0ZXh0LCBvZmZzZXR4LCBvZmZzZXR5LCB0aWx0KSk7XHJcbiAgICAgICAgICBjdHgubGluZVRvKC4uLmNhbGNGb250UG9pbnQobGluZVtpICsgMV0sIHRleHQsIG9mZnNldHgsIG9mZnNldHksIHRpbHQpKTtcclxuICAgICAgICAgIGN0eC5zdHJva2UoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgb2Zmc2V0eCArPSBwY2JGb250LmZvbnRfZGF0YVtjXS53ICogdGV4dC53aWR0aDtcclxuICAgIH1cclxuICB9XHJcbiAgY3R4LnJlc3RvcmUoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZHJhd2VkZ2UoY3R4LCBzY2FsZWZhY3RvciwgZWRnZSwgY29sb3IpIHtcclxuICBjdHguc3Ryb2tlU3R5bGUgPSBjb2xvcjtcclxuICBjdHgubGluZVdpZHRoID0gTWF0aC5tYXgoMSAvIHNjYWxlZmFjdG9yLCBlZGdlLndpZHRoKTtcclxuICBjdHgubGluZUNhcCA9IFwicm91bmRcIjtcclxuICBpZiAoZWRnZS50eXBlID09IFwic2VnbWVudFwiKSBcclxuICB7XHJcbiAgICBjdHguYmVnaW5QYXRoKCk7XHJcbiAgICBjdHgubW92ZVRvKC4uLmVkZ2Uuc3RhcnQpO1xyXG4gICAgY3R4LmxpbmVUbyguLi5lZGdlLmVuZCk7XHJcbiAgICBjdHguc3Ryb2tlKCk7XHJcbiAgfVxyXG4gIGlmIChlZGdlLnR5cGUgPT0gXCJhcmNcIikge1xyXG4gICAgY3R4LmJlZ2luUGF0aCgpO1xyXG4gICAgY3R4LmFyYyhcclxuICAgICAgLi4uZWRnZS5zdGFydCxcclxuICAgICAgZWRnZS5yYWRpdXMsXHJcbiAgICAgIGRlZzJyYWQoZWRnZS5zdGFydGFuZ2xlKSxcclxuICAgICAgZGVnMnJhZChlZGdlLmVuZGFuZ2xlKSk7XHJcbiAgICBjdHguc3Ryb2tlKCk7XHJcbiAgfVxyXG4gIGlmIChlZGdlLnR5cGUgPT0gXCJjaXJjbGVcIikge1xyXG4gICAgY3R4LmJlZ2luUGF0aCgpO1xyXG4gICAgY3R4LmFyYyhcclxuICAgICAgLi4uZWRnZS5zdGFydCxcclxuICAgICAgZWRnZS5yYWRpdXMsXHJcbiAgICAgIDAsIDIgKiBNYXRoLlBJKTtcclxuICAgIGN0eC5jbG9zZVBhdGgoKTtcclxuICAgIGN0eC5zdHJva2UoKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRyYXdSb3VuZFJlY3QoY3R4LCBjb2xvciwgc2l6ZSwgcmFkaXVzLCBjdHhtZXRob2QpIHtcclxuICBjdHguYmVnaW5QYXRoKCk7XHJcbiAgY3R4LnN0cm9rZVN0eWxlID0gY29sb3I7XHJcbiAgdmFyIHggPSBzaXplWzBdICogLTAuNTtcclxuICB2YXIgeSA9IHNpemVbMV0gKiAtMC41O1xyXG4gIHZhciB3aWR0aCA9IHNpemVbMF07XHJcbiAgdmFyIGhlaWdodCA9IHNpemVbMV07XHJcbiAgY3R4Lm1vdmVUbyh4LCAwKTtcclxuICBjdHguYXJjVG8oeCwgeSArIGhlaWdodCwgeCArIHdpZHRoLCB5ICsgaGVpZ2h0LCByYWRpdXMpO1xyXG4gIGN0eC5hcmNUbyh4ICsgd2lkdGgsIHkgKyBoZWlnaHQsIHggKyB3aWR0aCwgeSwgcmFkaXVzKTtcclxuICBjdHguYXJjVG8oeCArIHdpZHRoLCB5LCB4LCB5LCByYWRpdXMpO1xyXG4gIGN0eC5hcmNUbyh4LCB5LCB4LCB5ICsgaGVpZ2h0LCByYWRpdXMpO1xyXG4gIGN0eC5jbG9zZVBhdGgoKTtcclxuICBjdHhtZXRob2QoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZHJhd09ibG9uZyhjdHgsIGNvbG9yLCBzaXplLCBjdHhtZXRob2QpIHtcclxuICBkcmF3Um91bmRSZWN0KGN0eCwgY29sb3IsIHNpemUsIE1hdGgubWluKHNpemVbMF0sIHNpemVbMV0pIC8gMiwgY3R4bWV0aG9kKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZHJhd1BvbHlnb25zKGN0eCwgY29sb3IsIHBvbHlnb25zLCBjdHhtZXRob2QpIHtcclxuICBjdHguZmlsbFN0eWxlID0gY29sb3I7XHJcbiAgaWYocG9seWdvbnMubGVuZ3RoPjApXHJcbiAge1xyXG4gICAgZm9yICh2YXIgcG9seWdvbiBvZiBwb2x5Z29ucykge1xyXG4gICAgICBjdHguYmVnaW5QYXRoKCk7XHJcbiAgICAgIGZvciAodmFyIHZlcnRleCBvZiBwb2x5Z29uKSB7XHJcbiAgICAgICAgY3R4LmxpbmVUbyguLi52ZXJ0ZXgpXHJcbiAgICAgIH1cclxuICAgICAgY3R4LmNsb3NlUGF0aCgpO1xyXG4gICAgICBjdHhtZXRob2QoKTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRyYXdQb2x5Z29uU2hhcGUoY3R4LCBzaGFwZSwgY29sb3IpIHtcclxuICBjdHguc2F2ZSgpO1xyXG4gIGN0eC50cmFuc2xhdGUoLi4uc2hhcGUucG9zKTtcclxuICBjdHgucm90YXRlKGRlZzJyYWQoLXNoYXBlLmFuZ2xlKSk7XHJcbiAgZHJhd1BvbHlnb25zKGN0eCwgY29sb3IsIHNoYXBlLnBvbHlnb25zLCBjdHguZmlsbC5iaW5kKGN0eCkpO1xyXG4gIGN0eC5yZXN0b3JlKCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRyYXdEcmF3aW5nKGN0eCwgbGF5ZXIsIHNjYWxlZmFjdG9yLCBkcmF3aW5nLCBjb2xvcikge1xyXG4gIGlmIChbXCJzZWdtZW50XCIsIFwiYXJjXCIsIFwiY2lyY2xlXCJdLmluY2x1ZGVzKGRyYXdpbmcudHlwZSkpIHtcclxuICAgIGRyYXdlZGdlKGN0eCwgc2NhbGVmYWN0b3IsIGRyYXdpbmcsIGNvbG9yKTtcclxuICB9IGVsc2UgaWYgKGRyYXdpbmcudHlwZSA9PSBcInBvbHlnb25cIikge1xyXG4gICAgZHJhd1BvbHlnb25TaGFwZShjdHgsIGRyYXdpbmcsIGNvbG9yKTtcclxuICB9IGVsc2Uge1xyXG4gICAgZHJhd3RleHQoY3R4LCBkcmF3aW5nLCBjb2xvciwgbGF5ZXIgPT0gXCJCXCIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZHJhd0NpcmNsZShjdHgsIHJhZGl1cywgY3R4bWV0aG9kKSB7XHJcbiAgY3R4LmJlZ2luUGF0aCgpO1xyXG4gIGN0eC5hcmMoMCwgMCwgcmFkaXVzLCAwLCAyICogTWF0aC5QSSk7XHJcbiAgY3R4LmNsb3NlUGF0aCgpO1xyXG4gIGN0eG1ldGhvZCgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBkcmF3UGFkKGN0eCwgcGFkLCBjb2xvciwgb3V0bGluZSkge1xyXG4gIGN0eC5zYXZlKCk7XHJcbiAgY3R4LnRyYW5zbGF0ZSguLi5wYWQucG9zKTtcclxuICBjdHgucm90YXRlKGRlZzJyYWQocGFkLmFuZ2xlKSk7XHJcbiAgaWYgKHBhZC5vZmZzZXQpIHtcclxuICAgIGN0eC50cmFuc2xhdGUoLi4ucGFkLm9mZnNldCk7XHJcbiAgfVxyXG4gIGN0eC5maWxsU3R5bGUgPSBjb2xvcjtcclxuICBjdHguc3Ryb2tlU3R5bGUgPSBjb2xvcjtcclxuICB2YXIgY3R4bWV0aG9kID0gb3V0bGluZSA/IGN0eC5zdHJva2UuYmluZChjdHgpIDogY3R4LmZpbGwuYmluZChjdHgpO1xyXG4gIGlmIChwYWQuc2hhcGUgPT0gXCJyZWN0XCIpIHtcclxuICAgIHZhciByZWN0ID0gWy4uLnBhZC5zaXplLm1hcChjID0+IC1jICogMC41KSwgLi4ucGFkLnNpemVdO1xyXG4gICAgaWYgKG91dGxpbmUpIHtcclxuICAgICAgY3R4LnN0cm9rZVJlY3QoLi4ucmVjdCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjdHguZmlsbFJlY3QoLi4ucmVjdCk7XHJcbiAgICB9XHJcbiAgfSBlbHNlIGlmIChwYWQuc2hhcGUgPT0gXCJvdmFsXCIpIHtcclxuICAgIGRyYXdPYmxvbmcoY3R4LCBjb2xvciwgcGFkLnNpemUsIGN0eG1ldGhvZCk7XHJcbiAgfSBlbHNlIGlmIChwYWQuc2hhcGUgPT0gXCJjaXJjbGVcIikge1xyXG4gICAgZHJhd0NpcmNsZShjdHgsIHBhZC5zaXplWzBdIC8gMiwgY3R4bWV0aG9kKTtcclxuICB9IGVsc2UgaWYgKHBhZC5zaGFwZSA9PSBcInJvdW5kcmVjdFwiKSB7XHJcbiAgICBkcmF3Um91bmRSZWN0KGN0eCwgY29sb3IsIHBhZC5zaXplLCBwYWQucmFkaXVzLCBjdHhtZXRob2QpO1xyXG4gIH0gZWxzZSBpZiAocGFkLnNoYXBlID09IFwiY3VzdG9tXCIpIHtcclxuICAgIGRyYXdQb2x5Z29ucyhjdHgsIGNvbG9yLCBwYWQucG9seWdvbnMsIGN0eG1ldGhvZCk7XHJcbiAgfVxyXG4gIGlmIChwYWQudHlwZSA9PSBcInRoXCIgJiYgIW91dGxpbmUpIHtcclxuICAgIGN0eC5maWxsU3R5bGUgPSBcIiNDQ0NDQ0NcIjtcclxuICAgIGlmIChwYWQuZHJpbGxzaGFwZSA9PSBcIm9ibG9uZ1wiKSB7XHJcbiAgICAgIGRyYXdPYmxvbmcoY3R4LCBcIiNDQ0NDQ0NcIiwgcGFkLmRyaWxsc2l6ZSwgY3R4bWV0aG9kKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGRyYXdDaXJjbGUoY3R4LCBwYWQuZHJpbGxzaXplWzBdIC8gMiwgY3R4bWV0aG9kKTtcclxuICAgIH1cclxuICB9XHJcbiAgY3R4LnJlc3RvcmUoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZHJhd01vZHVsZShjdHgsIGxheWVyLCBzY2FsZWZhY3RvciwgbW9kdWxlLCBwYWRjb2xvciwgb3V0bGluZWNvbG9yLCBoaWdobGlnaHQpIHtcclxuICBpZiAoaGlnaGxpZ2h0KSB7XHJcbiAgICAvLyBkcmF3IGJvdW5kaW5nIGJveFxyXG4gICAgaWYgKG1vZHVsZS5sYXllciA9PSBsYXllcikge1xyXG4gICAgICBjdHguc2F2ZSgpO1xyXG4gICAgICBjdHguZ2xvYmFsQWxwaGEgPSAwLjI7XHJcbiAgICAgIGN0eC50cmFuc2xhdGUoLi4ubW9kdWxlLmJib3gucG9zKTtcclxuICAgICAgY3R4LmZpbGxTdHlsZSA9IHBhZGNvbG9yO1xyXG4gICAgICBjdHguZmlsbFJlY3QoMCwgMCwuLi5tb2R1bGUuYmJveC5zaXplKTtcclxuICAgICAgY3R4Lmdsb2JhbEFscGhhID0gMTtcclxuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gcGFkY29sb3I7XHJcbiAgICAgIGN0eC5zdHJva2VSZWN0KFxyXG4gICAgICAgIDAsIDAsXHJcbiAgICAgICAgLi4ubW9kdWxlLmJib3guc2l6ZSk7XHJcbiAgICAgIGN0eC5yZXN0b3JlKCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC8vIGRyYXcgZHJhd2luZ3NcclxuICBmb3IgKHZhciBkcmF3aW5nIG9mIG1vZHVsZS5kcmF3aW5ncykge1xyXG4gICAgaWYgKGRyYXdpbmcubGF5ZXIgPT0gbGF5ZXIpIHtcclxuICAgICAgZHJhd0RyYXdpbmcoY3R4LCBsYXllciwgc2NhbGVmYWN0b3IsIGRyYXdpbmcuZHJhd2luZywgcGFkY29sb3IpO1xyXG4gICAgfVxyXG4gIH1cclxuICAvLyBkcmF3IHBhZHNcclxuICBmb3IgKHZhciBwYWQgb2YgbW9kdWxlLnBhZHMpIHtcclxuICAgIGlmIChwYWQubGF5ZXJzLmluY2x1ZGVzKGxheWVyKSkge1xyXG4gICAgICBkcmF3UGFkKGN0eCwgcGFkLCBwYWRjb2xvciwgZmFsc2UpO1xyXG4gICAgICBcclxuICAgICAgXHJcbiAgICAgIGlmIChwYWQucGluMSAmJiBnbG9iYWxEYXRhLmdldEhpZ2hsaWdodFBpbjEoKSkgXHJcbiAgICAgIHtcclxuICAgICAgICBkcmF3UGFkKGN0eCwgcGFkLCBvdXRsaW5lY29sb3IsIHRydWUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBkcmF3RWRnZXMoY2FudmFzLCBzY2FsZWZhY3Rvcikge1xyXG4gIHZhciBjdHggPSBjYW52YXMuZ2V0Q29udGV4dChcIjJkXCIpO1xyXG4gIHZhciBlZGdlY29sb3IgPSBnZXRDb21wdXRlZFN0eWxlKHRvcG1vc3RkaXYpLmdldFByb3BlcnR5VmFsdWUoJy0tcGNiLWVkZ2UtY29sb3InKTtcclxuICBmb3IgKHZhciBlZGdlIG9mIHBjYmRhdGEuZWRnZXMpIHtcclxuICAgIGRyYXdlZGdlKGN0eCwgc2NhbGVmYWN0b3IsIGVkZ2UsIGVkZ2Vjb2xvcik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBkcmF3TW9kdWxlcyhjYW52YXMsIGxheWVyLCBzY2FsZWZhY3RvciwgaGlnaGxpZ2h0ZWRSZWZzKSB7XHJcbiAgdmFyIGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XHJcbiAgY3R4LmxpbmVXaWR0aCA9IDMgLyBzY2FsZWZhY3RvcjtcclxuICB2YXIgc3R5bGUgPSBnZXRDb21wdXRlZFN0eWxlKHRvcG1vc3RkaXYpO1xyXG4gIHZhciBwYWRjb2xvciA9IHN0eWxlLmdldFByb3BlcnR5VmFsdWUoJy0tcGFkLWNvbG9yJyk7XHJcbiAgdmFyIG91dGxpbmVjb2xvciA9IHN0eWxlLmdldFByb3BlcnR5VmFsdWUoJy0tcGluMS1vdXRsaW5lLWNvbG9yJyk7XHJcbiAgaWYgKGhpZ2hsaWdodGVkUmVmcy5sZW5ndGggPiAwKSB7XHJcbiAgICBwYWRjb2xvciA9IHN0eWxlLmdldFByb3BlcnR5VmFsdWUoJy0tcGFkLWNvbG9yLWhpZ2hsaWdodCcpO1xyXG4gICAgb3V0bGluZWNvbG9yID0gc3R5bGUuZ2V0UHJvcGVydHlWYWx1ZSgnLS1waW4xLW91dGxpbmUtY29sb3ItaGlnaGxpZ2h0Jyk7XHJcbiAgfVxyXG4gIGZvciAodmFyIGkgaW4gcGNiZGF0YS5tb2R1bGVzKSB7XHJcbiAgICB2YXIgbW9kID0gcGNiZGF0YS5tb2R1bGVzW2ldO1xyXG4gICAgdmFyIGhpZ2hsaWdodCA9IGhpZ2hsaWdodGVkUmVmcy5pbmNsdWRlcyhtb2QucmVmKTtcclxuICAgIGlmIChoaWdobGlnaHRlZFJlZnMubGVuZ3RoID09IDAgfHwgaGlnaGxpZ2h0KSB7XHJcbiAgICAgIGRyYXdNb2R1bGUoY3R4LCBsYXllciwgc2NhbGVmYWN0b3IsIG1vZCwgcGFkY29sb3IsIG91dGxpbmVjb2xvciwgaGlnaGxpZ2h0KTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRyYXdTaWxrc2NyZWVuKGNhbnZhcywgbGF5ZXIsIHNjYWxlZmFjdG9yKVxyXG57XHJcbiAgdmFyIGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XHJcbiAgZm9yICh2YXIgZCBvZiBwY2JkYXRhLnNpbGtzY3JlZW5bbGF5ZXJdKVxyXG4gIHtcclxuICAgIGlmIChbXCJzZWdtZW50XCIsIFwiYXJjXCIsIFwiY2lyY2xlXCJdLmluY2x1ZGVzKGQudHlwZSkpXHJcbiAgICB7XHJcbiAgICAgIGRyYXdlZGdlKGN0eCwgc2NhbGVmYWN0b3IsIGQsIFwiI2FhNFwiKTtcclxuICAgIH1cclxuICAgIGVsc2UgaWYgKGQudHlwZSA9PSBcInBvbHlnb25cIilcclxuICAgIHtcclxuICAgICAgZHJhd1BvbHlnb25TaGFwZShjdHgsIGQsIFwiIzRhYVwiKTtcclxuICAgIH1cclxuICAgIGVsc2VcclxuICAgIHtcclxuICAgICAgZHJhd3RleHQoY3R4LCBkLCBcIiM0YWFcIiwgbGF5ZXIgPT0gXCJCXCIpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gY2xlYXJDYW52YXMoY2FudmFzKSB7XHJcbiAgdmFyIGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XHJcbiAgY3R4LnNhdmUoKTtcclxuICBjdHguc2V0VHJhbnNmb3JtKDEsIDAsIDAsIDEsIDAsIDApO1xyXG4gIGN0eC5jbGVhclJlY3QoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcclxuICBjdHgucmVzdG9yZSgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBkcmF3SGlnaGxpZ2h0c09uTGF5ZXIoY2FudmFzZGljdCkge1xyXG4gIGNsZWFyQ2FudmFzKGNhbnZhc2RpY3QuaGlnaGxpZ2h0KTtcclxuICBkcmF3TW9kdWxlcyhjYW52YXNkaWN0LmhpZ2hsaWdodCwgY2FudmFzZGljdC5sYXllcixcclxuICAgIGNhbnZhc2RpY3QudHJhbnNmb3JtLnMsIGdsb2JhbERhdGEuZ2V0SGlnaGxpZ2h0ZWRSZWZzKCkpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBkcmF3SGlnaGxpZ2h0cygpIHtcclxuICBkcmF3SGlnaGxpZ2h0c09uTGF5ZXIoYWxsY2FudmFzLmZyb250KTtcclxuICBkcmF3SGlnaGxpZ2h0c09uTGF5ZXIoYWxsY2FudmFzLmJhY2spO1xyXG59XHJcblxyXG5mdW5jdGlvbiBkcmF3QmFja2dyb3VuZChjYW52YXNkaWN0KSB7XHJcbiAgY2xlYXJDYW52YXMoY2FudmFzZGljdC5iZyk7XHJcbiAgY2xlYXJDYW52YXMoY2FudmFzZGljdC5zaWxrKTtcclxuICBkcmF3RWRnZXMoY2FudmFzZGljdC5iZywgY2FudmFzZGljdC50cmFuc2Zvcm0ucyk7XHJcbiAgZHJhd01vZHVsZXMoY2FudmFzZGljdC5iZywgY2FudmFzZGljdC5sYXllciwgY2FudmFzZGljdC50cmFuc2Zvcm0ucywgW10pO1xyXG4gIGRyYXdTaWxrc2NyZWVuKGNhbnZhc2RpY3Quc2lsaywgY2FudmFzZGljdC5sYXllciwgY2FudmFzZGljdC50cmFuc2Zvcm0ucyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHByZXBhcmVDYW52YXMoY2FudmFzLCBmbGlwLCB0cmFuc2Zvcm0pIHtcclxuICB2YXIgY3R4ID0gY2FudmFzLmdldENvbnRleHQoXCIyZFwiKTtcclxuICBjdHguc2V0VHJhbnNmb3JtKDEsIDAsIDAsIDEsIDAsIDApO1xyXG4gIHZhciBmb250c2l6ZSA9IDEuNTU7XHJcbiAgY3R4LnNjYWxlKHRyYW5zZm9ybS56b29tLCB0cmFuc2Zvcm0uem9vbSk7XHJcbiAgY3R4LnRyYW5zbGF0ZSh0cmFuc2Zvcm0ucGFueCwgdHJhbnNmb3JtLnBhbnkpO1xyXG4gIGlmIChmbGlwKSB7XHJcbiAgICBjdHguc2NhbGUoLTEsIDEpO1xyXG4gIH1cclxuICBjdHgudHJhbnNsYXRlKHRyYW5zZm9ybS54LCB0cmFuc2Zvcm0ueSk7XHJcbiAgY3R4LnJvdGF0ZShkZWcycmFkKGJvYXJkUm90YXRpb24pKTtcclxuICBjdHguc2NhbGUodHJhbnNmb3JtLnMsIHRyYW5zZm9ybS5zKTtcclxufVxyXG5cclxuZnVuY3Rpb24gcHJlcGFyZUxheWVyKGNhbnZhc2RpY3QpIHtcclxuICB2YXIgZmxpcCA9IChjYW52YXNkaWN0LmxheWVyICE9IFwiQlwiKTtcclxuICBmb3IgKHZhciBjIG9mIFtcImJnXCIsIFwic2lsa1wiLCBcImhpZ2hsaWdodFwiXSkge1xyXG4gICAgcHJlcGFyZUNhbnZhcyhjYW52YXNkaWN0W2NdLCBmbGlwLCBjYW52YXNkaWN0LnRyYW5zZm9ybSk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiByb3RhdGVWZWN0b3IodiwgYW5nbGUpIHtcclxuICBhbmdsZSA9IGRlZzJyYWQoYW5nbGUpO1xyXG4gIHJldHVybiBbXHJcbiAgICB2WzBdICogTWF0aC5jb3MoYW5nbGUpIC0gdlsxXSAqIE1hdGguc2luKGFuZ2xlKSxcclxuICAgIHZbMF0gKiBNYXRoLnNpbihhbmdsZSkgKyB2WzFdICogTWF0aC5jb3MoYW5nbGUpXHJcbiAgXTtcclxufVxyXG5cclxuZnVuY3Rpb24gYXBwbHlSb3RhdGlvbihiYm94KSB7XHJcbiAgdmFyIGNvcm5lcnMgPSBbXHJcbiAgICBbYmJveC5taW54LCBiYm94Lm1pbnldLFxyXG4gICAgW2Jib3gubWlueCwgYmJveC5tYXh5XSxcclxuICAgIFtiYm94Lm1heHgsIGJib3gubWlueV0sXHJcbiAgICBbYmJveC5tYXh4LCBiYm94Lm1heHldLFxyXG4gIF07XHJcbiAgY29ybmVycyA9IGNvcm5lcnMubWFwKCh2KSA9PiByb3RhdGVWZWN0b3IodiwgYm9hcmRSb3RhdGlvbikpO1xyXG4gIHJldHVybiB7XHJcbiAgICBtaW54OiBjb3JuZXJzLnJlZHVjZSgoYSwgdikgPT4gTWF0aC5taW4oYSwgdlswXSksIEluZmluaXR5KSxcclxuICAgIG1pbnk6IGNvcm5lcnMucmVkdWNlKChhLCB2KSA9PiBNYXRoLm1pbihhLCB2WzFdKSwgSW5maW5pdHkpLFxyXG4gICAgbWF4eDogY29ybmVycy5yZWR1Y2UoKGEsIHYpID0+IE1hdGgubWF4KGEsIHZbMF0pLCAtSW5maW5pdHkpLFxyXG4gICAgbWF4eTogY29ybmVycy5yZWR1Y2UoKGEsIHYpID0+IE1hdGgubWF4KGEsIHZbMV0pLCAtSW5maW5pdHkpLFxyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcmVjYWxjTGF5ZXJTY2FsZShjYW52YXNkaWN0KSB7XHJcbiAgdmFyIGNhbnZhc2RpdmlkID0ge1xyXG4gICAgXCJGXCI6IFwiZnJvbnRjYW52YXNcIixcclxuICAgIFwiQlwiOiBcImJhY2tjYW52YXNcIlxyXG4gIH0gW2NhbnZhc2RpY3QubGF5ZXJdO1xyXG4gIHZhciB3aWR0aCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGNhbnZhc2RpdmlkKS5jbGllbnRXaWR0aCAqIDI7XHJcbiAgdmFyIGhlaWdodCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGNhbnZhc2RpdmlkKS5jbGllbnRIZWlnaHQgKiAyO1xyXG4gIHZhciBiYm94ID0gYXBwbHlSb3RhdGlvbihwY2JkYXRhLmVkZ2VzX2Jib3gpO1xyXG4gIHZhciBzY2FsZWZhY3RvciA9IDAuOTggKiBNYXRoLm1pbihcclxuICAgIHdpZHRoIC8gKGJib3gubWF4eCAtIGJib3gubWlueCksXHJcbiAgICBoZWlnaHQgLyAoYmJveC5tYXh5IC0gYmJveC5taW55KVxyXG4gICk7XHJcbiAgaWYgKHNjYWxlZmFjdG9yIDwgMC4xKSB7XHJcbiAgICBzY2FsZWZhY3RvciA9IDE7XHJcbiAgfVxyXG4gIGNhbnZhc2RpY3QudHJhbnNmb3JtLnMgPSBzY2FsZWZhY3RvcjtcclxuICB2YXIgZmxpcCA9IChjYW52YXNkaWN0LmxheWVyICE9IFwiQlwiKTtcclxuICBpZiAoZmxpcCkge1xyXG4gICAgY2FudmFzZGljdC50cmFuc2Zvcm0ueCA9IC0oKGJib3gubWF4eCArIGJib3gubWlueCkgKiBzY2FsZWZhY3RvciArIHdpZHRoKSAqIDAuNTtcclxuICB9IGVsc2Uge1xyXG4gICAgY2FudmFzZGljdC50cmFuc2Zvcm0ueCA9IC0oKGJib3gubWF4eCArIGJib3gubWlueCkgKiBzY2FsZWZhY3RvciAtIHdpZHRoKSAqIDAuNTtcclxuICB9XHJcbiAgY2FudmFzZGljdC50cmFuc2Zvcm0ueSA9IC0oKGJib3gubWF4eSArIGJib3gubWlueSkgKiBzY2FsZWZhY3RvciAtIGhlaWdodCkgKiAwLjU7XHJcbiAgZm9yICh2YXIgYyBvZiBbXCJiZ1wiLCBcInNpbGtcIiwgXCJoaWdobGlnaHRcIl0pIHtcclxuICAgIGNhbnZhcyA9IGNhbnZhc2RpY3RbY107XHJcbiAgICBjYW52YXMud2lkdGggPSB3aWR0aDtcclxuICAgIGNhbnZhcy5oZWlnaHQgPSBoZWlnaHQ7XHJcbiAgICBjYW52YXMuc3R5bGUud2lkdGggPSAod2lkdGggLyAyKSArIFwicHhcIjtcclxuICAgIGNhbnZhcy5zdHlsZS5oZWlnaHQgPSAoaGVpZ2h0IC8gMikgKyBcInB4XCI7XHJcbiAgfVxyXG4gIGNvbnNvbGUubG9nKFwiU2NhbGUgZmFjdG9yIFwiICsgY2FudmFzZGl2aWQgKyBcIjogXCIsIGNhbnZhc2RpY3QudHJhbnNmb3JtKTtcclxufVxyXG5cclxuZnVuY3Rpb24gcmVkcmF3Q2FudmFzKGxheWVyZGljdCkge1xyXG4gIHByZXBhcmVMYXllcihsYXllcmRpY3QpO1xyXG4gIGRyYXdCYWNrZ3JvdW5kKGxheWVyZGljdCk7XHJcbiAgZHJhd0hpZ2hsaWdodHNPbkxheWVyKGxheWVyZGljdCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlc2l6ZUNhbnZhcyhsYXllcmRpY3QpIHtcclxuICByZWNhbGNMYXllclNjYWxlKGxheWVyZGljdCk7XHJcbiAgcmVkcmF3Q2FudmFzKGxheWVyZGljdCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlc2l6ZUFsbCgpIHtcclxuICByZXNpemVDYW52YXMoYWxsY2FudmFzLmZyb250KTtcclxuICByZXNpemVDYW52YXMoYWxsY2FudmFzLmJhY2spO1xyXG59XHJcblxyXG5mdW5jdGlvbiBiYm94U2NhbihsYXllciwgeCwgeSkge1xyXG4gIHZhciByZXN1bHQgPSBbXTtcclxuICBmb3IgKHZhciBpIGluIHBjYmRhdGEubW9kdWxlcykge1xyXG4gICAgdmFyIG1vZHVsZSA9IHBjYmRhdGEubW9kdWxlc1tpXTtcclxuICAgIGlmIChtb2R1bGUubGF5ZXIgPT0gbGF5ZXIpIHtcclxuICAgICAgdmFyIGIgPSBtb2R1bGUuYmJveDtcclxuICAgICAgaWYgKGIucG9zWzBdIDw9IHggJiYgYi5wb3NbMF0gKyBiLnNpemVbMF0gPj0geCAmJlxyXG4gICAgICAgIGIucG9zWzFdIDw9IHkgJiYgYi5wb3NbMV0gKyBiLnNpemVbMV0gPj0geSkge1xyXG4gICAgICAgIHJlc3VsdC5wdXNoKG1vZHVsZS5yZWYpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGhhbmRsZU1vdXNlRG93bihlLCBsYXllcmRpY3QpIHtcclxuICBpZiAoZS53aGljaCAhPSAxKSB7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGUucHJldmVudERlZmF1bHQoKTtcclxuICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gIGxheWVyZGljdC50cmFuc2Zvcm0ubW91c2VzdGFydHggPSBlLm9mZnNldFg7XHJcbiAgbGF5ZXJkaWN0LnRyYW5zZm9ybS5tb3VzZXN0YXJ0eSA9IGUub2Zmc2V0WTtcclxuICBsYXllcmRpY3QudHJhbnNmb3JtLm1vdXNlZG93bnggPSBlLm9mZnNldFg7XHJcbiAgbGF5ZXJkaWN0LnRyYW5zZm9ybS5tb3VzZWRvd255ID0gZS5vZmZzZXRZO1xyXG4gIGxheWVyZGljdC50cmFuc2Zvcm0ubW91c2Vkb3duID0gdHJ1ZTtcclxufVxyXG5cclxuZnVuY3Rpb24gaGFuZGxlTW91c2VDbGljayhlLCBsYXllcmRpY3QpIHtcclxuICB2YXIgeCA9IGUub2Zmc2V0WDtcclxuICB2YXIgeSA9IGUub2Zmc2V0WTtcclxuICB2YXIgdCA9IGxheWVyZGljdC50cmFuc2Zvcm07XHJcbiAgaWYgKGxheWVyZGljdC5sYXllciA9PSBcIkJcIikge1xyXG4gICAgeCA9ICgyICogeCAvIHQuem9vbSAtIHQucGFueCArIHQueCkgLyAtdC5zO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB4ID0gKDIgKiB4IC8gdC56b29tIC0gdC5wYW54IC0gdC54KSAvIHQucztcclxuICB9XHJcbiAgeSA9ICgyICogeSAvIHQuem9vbSAtIHQueSAtIHQucGFueSkgLyB0LnM7XHJcbiAgdmFyIHYgPSByb3RhdGVWZWN0b3IoW3gsIHldLCAtYm9hcmRSb3RhdGlvbik7XHJcbiAgdmFyIHJlZmxpc3QgPSBiYm94U2NhbihsYXllcmRpY3QubGF5ZXIsIHZbMF0sIHZbMV0pO1xyXG4gIGlmIChyZWZsaXN0Lmxlbmd0aCA+IDApIHtcclxuICAgIG1vZHVsZXNDbGlja2VkKHJlZmxpc3QpO1xyXG4gICAgZHJhd0hpZ2hsaWdodHMoKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGhhbmRsZU1vdXNlVXAoZSwgbGF5ZXJkaWN0KSB7XHJcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgaWYgKGUud2hpY2ggPT0gMSAmJlxyXG4gICAgbGF5ZXJkaWN0LnRyYW5zZm9ybS5tb3VzZWRvd24gJiZcclxuICAgIGxheWVyZGljdC50cmFuc2Zvcm0ubW91c2Vkb3dueCA9PSBlLm9mZnNldFggJiZcclxuICAgIGxheWVyZGljdC50cmFuc2Zvcm0ubW91c2Vkb3dueSA9PSBlLm9mZnNldFkpIHtcclxuICAgIC8vIFRoaXMgaXMganVzdCBhIGNsaWNrXHJcbiAgICBoYW5kbGVNb3VzZUNsaWNrKGUsIGxheWVyZGljdCk7XHJcbiAgICBsYXllcmRpY3QudHJhbnNmb3JtLm1vdXNlZG93biA9IGZhbHNlO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBpZiAoZS53aGljaCA9PSAzKSB7XHJcbiAgICAvLyBSZXNldCBwYW4gYW5kIHpvb20gb24gcmlnaHQgY2xpY2suXHJcbiAgICBsYXllcmRpY3QudHJhbnNmb3JtLnBhbnggPSAwO1xyXG4gICAgbGF5ZXJkaWN0LnRyYW5zZm9ybS5wYW55ID0gMDtcclxuICAgIGxheWVyZGljdC50cmFuc2Zvcm0uem9vbSA9IDE7XHJcbiAgICByZWRyYXdDYW52YXMobGF5ZXJkaWN0KTtcclxuICB9IGVsc2UgaWYgKCFnbG9iYWxEYXRhLmdldFJlZHJhd09uRHJhZygpKSB7XHJcbiAgICByZWRyYXdDYW52YXMobGF5ZXJkaWN0KTtcclxuICB9XHJcbiAgbGF5ZXJkaWN0LnRyYW5zZm9ybS5tb3VzZWRvd24gPSBmYWxzZTtcclxufVxyXG5cclxuZnVuY3Rpb24gaGFuZGxlTW91c2VNb3ZlKGUsIGxheWVyZGljdCkge1xyXG4gIGlmICghbGF5ZXJkaWN0LnRyYW5zZm9ybS5tb3VzZWRvd24pIHtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgdmFyIGR4ID0gZS5vZmZzZXRYIC0gbGF5ZXJkaWN0LnRyYW5zZm9ybS5tb3VzZXN0YXJ0eDtcclxuICB2YXIgZHkgPSBlLm9mZnNldFkgLSBsYXllcmRpY3QudHJhbnNmb3JtLm1vdXNlc3RhcnR5O1xyXG4gIGxheWVyZGljdC50cmFuc2Zvcm0ucGFueCArPSAyICogZHggLyBsYXllcmRpY3QudHJhbnNmb3JtLnpvb207XHJcbiAgbGF5ZXJkaWN0LnRyYW5zZm9ybS5wYW55ICs9IDIgKiBkeSAvIGxheWVyZGljdC50cmFuc2Zvcm0uem9vbTtcclxuICBsYXllcmRpY3QudHJhbnNmb3JtLm1vdXNlc3RhcnR4ID0gZS5vZmZzZXRYO1xyXG4gIGxheWVyZGljdC50cmFuc2Zvcm0ubW91c2VzdGFydHkgPSBlLm9mZnNldFk7XHJcbiAgaWYgKGdsb2JhbERhdGEuZ2V0UmVkcmF3T25EcmFnKCkpIHtcclxuICAgIHJlZHJhd0NhbnZhcyhsYXllcmRpY3QpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gaGFuZGxlTW91c2VXaGVlbChlLCBsYXllcmRpY3QpIHtcclxuICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICB2YXIgdCA9IGxheWVyZGljdC50cmFuc2Zvcm07XHJcbiAgdmFyIHdoZWVsZGVsdGEgPSBlLmRlbHRhWTtcclxuICBpZiAoZS5kZWx0YU1vZGUgPT0gMSkge1xyXG4gICAgLy8gRkYgb25seSwgc2Nyb2xsIGJ5IGxpbmVzXHJcbiAgICB3aGVlbGRlbHRhICo9IDMwO1xyXG4gIH0gZWxzZSBpZiAoZS5kZWx0YU1vZGUgPT0gMikge1xyXG4gICAgd2hlZWxkZWx0YSAqPSAzMDA7XHJcbiAgfVxyXG4gIHZhciBtID0gTWF0aC5wb3coMS4xLCAtd2hlZWxkZWx0YSAvIDQwKTtcclxuICAvLyBMaW1pdCBhbW91bnQgb2Ygem9vbSBwZXIgdGljay5cclxuICBpZiAobSA+IDIpIHtcclxuICAgIG0gPSAyO1xyXG4gIH0gZWxzZSBpZiAobSA8IDAuNSkge1xyXG4gICAgbSA9IDAuNTtcclxuICB9XHJcbiAgdC56b29tICo9IG07XHJcbiAgdmFyIHpvb21kID0gKDEgLSBtKSAvIHQuem9vbTtcclxuICB0LnBhbnggKz0gMiAqIGUub2Zmc2V0WCAqIHpvb21kO1xyXG4gIHQucGFueSArPSAyICogZS5vZmZzZXRZICogem9vbWQ7XHJcbiAgcmVkcmF3Q2FudmFzKGxheWVyZGljdCk7XHJcbiAgY29uc29sZS5sb2cobGF5ZXJkaWN0LnRyYW5zZm9ybS56b29tKTtcclxufVxyXG5cclxuZnVuY3Rpb24gYWRkTW91c2VIYW5kbGVycyhkaXYsIGxheWVyZGljdCkge1xyXG4gIGRpdi5vbm1vdXNlZG93biA9IGZ1bmN0aW9uKGUpIHtcclxuICAgIGhhbmRsZU1vdXNlRG93bihlLCBsYXllcmRpY3QpO1xyXG4gIH07XHJcbiAgZGl2Lm9ubW91c2Vtb3ZlID0gZnVuY3Rpb24oZSkge1xyXG4gICAgaGFuZGxlTW91c2VNb3ZlKGUsIGxheWVyZGljdCk7XHJcbiAgfTtcclxuICBkaXYub25tb3VzZXVwID0gZnVuY3Rpb24oZSkge1xyXG4gICAgaGFuZGxlTW91c2VVcChlLCBsYXllcmRpY3QpO1xyXG4gIH07XHJcbiAgZGl2Lm9ubW91c2VvdXQgPSBmdW5jdGlvbihlKSB7XHJcbiAgICBoYW5kbGVNb3VzZVVwKGUsIGxheWVyZGljdCk7XHJcbiAgfVxyXG4gIGRpdi5vbndoZWVsID0gZnVuY3Rpb24oZSkge1xyXG4gICAgaGFuZGxlTW91c2VXaGVlbChlLCBsYXllcmRpY3QpO1xyXG4gIH1cclxuICBmb3IgKHZhciBlbGVtZW50IG9mIFtkaXYsIGxheWVyZGljdC5iZywgbGF5ZXJkaWN0LnNpbGssIGxheWVyZGljdC5oaWdobGlnaHRdKSB7XHJcbiAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjb250ZXh0bWVudVwiLCBmdW5jdGlvbihlKSB7XHJcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIH0sIGZhbHNlKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNldEJvYXJkUm90YXRpb24odmFsdWUpIHtcclxuICBib2FyZFJvdGF0aW9uID0gdmFsdWUgKiA1O1xyXG4gIGdsb2JhbERhdGEud3JpdGVTdG9yYWdlKFwiYm9hcmRSb3RhdGlvblwiLCBib2FyZFJvdGF0aW9uKTtcclxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvdGF0aW9uRGVncmVlXCIpLnRleHRDb250ZW50ID0gYm9hcmRSb3RhdGlvbjtcclxuICByZXNpemVBbGwoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gaW5pdFJlbmRlcigpIHtcclxuICBhbGxjYW52YXMgPSB7XHJcbiAgICBmcm9udDoge1xyXG4gICAgICB0cmFuc2Zvcm06IHtcclxuICAgICAgICB4OiAwLFxyXG4gICAgICAgIHk6IDAsXHJcbiAgICAgICAgczogMSxcclxuICAgICAgICBwYW54OiAwLFxyXG4gICAgICAgIHBhbnk6IDAsXHJcbiAgICAgICAgem9vbTogMSxcclxuICAgICAgICBtb3VzZXN0YXJ0eDogMCxcclxuICAgICAgICBtb3VzZXN0YXJ0eTogMCxcclxuICAgICAgICBtb3VzZWRvd246IGZhbHNlLFxyXG4gICAgICB9LFxyXG4gICAgICBiZzogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJGX2JnXCIpLFxyXG4gICAgICBzaWxrOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIkZfc2xrXCIpLFxyXG4gICAgICBoaWdobGlnaHQ6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiRl9obFwiKSxcclxuICAgICAgbGF5ZXI6IFwiRlwiLFxyXG4gICAgfSxcclxuICAgIGJhY2s6IHtcclxuICAgICAgdHJhbnNmb3JtOiB7XHJcbiAgICAgICAgeDogMCxcclxuICAgICAgICB5OiAwLFxyXG4gICAgICAgIHM6IDEsXHJcbiAgICAgICAgcGFueDogMCxcclxuICAgICAgICBwYW55OiAwLFxyXG4gICAgICAgIHpvb206IDEsXHJcbiAgICAgICAgbW91c2VzdGFydHg6IDAsXHJcbiAgICAgICAgbW91c2VzdGFydHk6IDAsXHJcbiAgICAgICAgbW91c2Vkb3duOiBmYWxzZSxcclxuICAgICAgfSxcclxuICAgICAgYmc6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiQl9iZ1wiKSxcclxuICAgICAgc2lsazogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJCX3Nsa1wiKSxcclxuICAgICAgaGlnaGxpZ2h0OiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIkJfaGxcIiksXHJcbiAgICAgIGxheWVyOiBcIkJcIixcclxuICAgIH1cclxuICB9O1xyXG4gIGFkZE1vdXNlSGFuZGxlcnMoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJmcm9udGNhbnZhc1wiKSwgYWxsY2FudmFzLmZyb250KTtcclxuICBhZGRNb3VzZUhhbmRsZXJzKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYmFja2NhbnZhc1wiKSwgYWxsY2FudmFzLmJhY2spO1xyXG59XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IHtcclxuICByZXNpemVBbGwsXHJcbiAgaW5pdFJlbmRlcixcclxuICByZWRyYXdDYW52YXMsXHJcbiAgZHJhd0hpZ2hsaWdodHMsXHJcbiAgc2V0Qm9hcmRSb3RhdGlvblxyXG59OyIsIi8qXHJcbiAgU3BsaXQuanMgLSB2MS4zLjVcclxuICBNSVQgTGljZW5zZVxyXG4gIGh0dHBzOi8vZ2l0aHViLmNvbS9uYXRoYW5jYWhpbGwvU3BsaXQuanNcclxuKi9cclxuIWZ1bmN0aW9uKGUsdCl7XCJvYmplY3RcIj09dHlwZW9mIGV4cG9ydHMmJlwidW5kZWZpbmVkXCIhPXR5cGVvZiBtb2R1bGU/bW9kdWxlLmV4cG9ydHM9dCgpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUodCk6ZS5TcGxpdD10KCl9KHRoaXMsZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjt2YXIgZT13aW5kb3csdD1lLmRvY3VtZW50LG49XCJhZGRFdmVudExpc3RlbmVyXCIsaT1cInJlbW92ZUV2ZW50TGlzdGVuZXJcIixyPVwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0XCIscz1mdW5jdGlvbigpe3JldHVybiExfSxvPWUuYXR0YWNoRXZlbnQmJiFlW25dLGE9W1wiXCIsXCItd2Via2l0LVwiLFwiLW1vei1cIixcIi1vLVwiXS5maWx0ZXIoZnVuY3Rpb24oZSl7dmFyIG49dC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO3JldHVybiBuLnN0eWxlLmNzc1RleHQ9XCJ3aWR0aDpcIitlK1wiY2FsYyg5cHgpXCIsISFuLnN0eWxlLmxlbmd0aH0pLnNoaWZ0KCkrXCJjYWxjXCIsbD1mdW5jdGlvbihlKXtyZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgZXx8ZSBpbnN0YW5jZW9mIFN0cmluZz90LnF1ZXJ5U2VsZWN0b3IoZSk6ZX07cmV0dXJuIGZ1bmN0aW9uKHUsYyl7ZnVuY3Rpb24geihlLHQsbil7dmFyIGk9QSh5LHQsbik7T2JqZWN0LmtleXMoaSkuZm9yRWFjaChmdW5jdGlvbih0KXtyZXR1cm4gZS5zdHlsZVt0XT1pW3RdfSl9ZnVuY3Rpb24gaChlLHQpe3ZhciBuPUIoeSx0KTtPYmplY3Qua2V5cyhuKS5mb3JFYWNoKGZ1bmN0aW9uKHQpe3JldHVybiBlLnN0eWxlW3RdPW5bdF19KX1mdW5jdGlvbiBmKGUpe3ZhciB0PUVbdGhpcy5hXSxuPUVbdGhpcy5iXSxpPXQuc2l6ZStuLnNpemU7dC5zaXplPWUvdGhpcy5zaXplKmksbi5zaXplPWktZS90aGlzLnNpemUqaSx6KHQuZWxlbWVudCx0LnNpemUsdGhpcy5hR3V0dGVyU2l6ZSkseihuLmVsZW1lbnQsbi5zaXplLHRoaXMuYkd1dHRlclNpemUpfWZ1bmN0aW9uIG0oZSl7dmFyIHQ7dGhpcy5kcmFnZ2luZyYmKCh0PVwidG91Y2hlc1wiaW4gZT9lLnRvdWNoZXNbMF1bYl0tdGhpcy5zdGFydDplW2JdLXRoaXMuc3RhcnQpPD1FW3RoaXMuYV0ubWluU2l6ZStNK3RoaXMuYUd1dHRlclNpemU/dD1FW3RoaXMuYV0ubWluU2l6ZSt0aGlzLmFHdXR0ZXJTaXplOnQ+PXRoaXMuc2l6ZS0oRVt0aGlzLmJdLm1pblNpemUrTSt0aGlzLmJHdXR0ZXJTaXplKSYmKHQ9dGhpcy5zaXplLShFW3RoaXMuYl0ubWluU2l6ZSt0aGlzLmJHdXR0ZXJTaXplKSksZi5jYWxsKHRoaXMsdCksYy5vbkRyYWcmJmMub25EcmFnKCkpfWZ1bmN0aW9uIGcoKXt2YXIgZT1FW3RoaXMuYV0uZWxlbWVudCx0PUVbdGhpcy5iXS5lbGVtZW50O3RoaXMuc2l6ZT1lW3JdKClbeV0rdFtyXSgpW3ldK3RoaXMuYUd1dHRlclNpemUrdGhpcy5iR3V0dGVyU2l6ZSx0aGlzLnN0YXJ0PWVbcl0oKVtHXX1mdW5jdGlvbiBkKCl7dmFyIHQ9dGhpcyxuPUVbdC5hXS5lbGVtZW50LHI9RVt0LmJdLmVsZW1lbnQ7dC5kcmFnZ2luZyYmYy5vbkRyYWdFbmQmJmMub25EcmFnRW5kKCksdC5kcmFnZ2luZz0hMSxlW2ldKFwibW91c2V1cFwiLHQuc3RvcCksZVtpXShcInRvdWNoZW5kXCIsdC5zdG9wKSxlW2ldKFwidG91Y2hjYW5jZWxcIix0LnN0b3ApLHQucGFyZW50W2ldKFwibW91c2Vtb3ZlXCIsdC5tb3ZlKSx0LnBhcmVudFtpXShcInRvdWNobW92ZVwiLHQubW92ZSksZGVsZXRlIHQuc3RvcCxkZWxldGUgdC5tb3ZlLG5baV0oXCJzZWxlY3RzdGFydFwiLHMpLG5baV0oXCJkcmFnc3RhcnRcIixzKSxyW2ldKFwic2VsZWN0c3RhcnRcIixzKSxyW2ldKFwiZHJhZ3N0YXJ0XCIscyksbi5zdHlsZS51c2VyU2VsZWN0PVwiXCIsbi5zdHlsZS53ZWJraXRVc2VyU2VsZWN0PVwiXCIsbi5zdHlsZS5Nb3pVc2VyU2VsZWN0PVwiXCIsbi5zdHlsZS5wb2ludGVyRXZlbnRzPVwiXCIsci5zdHlsZS51c2VyU2VsZWN0PVwiXCIsci5zdHlsZS53ZWJraXRVc2VyU2VsZWN0PVwiXCIsci5zdHlsZS5Nb3pVc2VyU2VsZWN0PVwiXCIsci5zdHlsZS5wb2ludGVyRXZlbnRzPVwiXCIsdC5ndXR0ZXIuc3R5bGUuY3Vyc29yPVwiXCIsdC5wYXJlbnQuc3R5bGUuY3Vyc29yPVwiXCJ9ZnVuY3Rpb24gUyh0KXt2YXIgaT10aGlzLHI9RVtpLmFdLmVsZW1lbnQsbz1FW2kuYl0uZWxlbWVudDshaS5kcmFnZ2luZyYmYy5vbkRyYWdTdGFydCYmYy5vbkRyYWdTdGFydCgpLHQucHJldmVudERlZmF1bHQoKSxpLmRyYWdnaW5nPSEwLGkubW92ZT1tLmJpbmQoaSksaS5zdG9wPWQuYmluZChpKSxlW25dKFwibW91c2V1cFwiLGkuc3RvcCksZVtuXShcInRvdWNoZW5kXCIsaS5zdG9wKSxlW25dKFwidG91Y2hjYW5jZWxcIixpLnN0b3ApLGkucGFyZW50W25dKFwibW91c2Vtb3ZlXCIsaS5tb3ZlKSxpLnBhcmVudFtuXShcInRvdWNobW92ZVwiLGkubW92ZSkscltuXShcInNlbGVjdHN0YXJ0XCIscykscltuXShcImRyYWdzdGFydFwiLHMpLG9bbl0oXCJzZWxlY3RzdGFydFwiLHMpLG9bbl0oXCJkcmFnc3RhcnRcIixzKSxyLnN0eWxlLnVzZXJTZWxlY3Q9XCJub25lXCIsci5zdHlsZS53ZWJraXRVc2VyU2VsZWN0PVwibm9uZVwiLHIuc3R5bGUuTW96VXNlclNlbGVjdD1cIm5vbmVcIixyLnN0eWxlLnBvaW50ZXJFdmVudHM9XCJub25lXCIsby5zdHlsZS51c2VyU2VsZWN0PVwibm9uZVwiLG8uc3R5bGUud2Via2l0VXNlclNlbGVjdD1cIm5vbmVcIixvLnN0eWxlLk1velVzZXJTZWxlY3Q9XCJub25lXCIsby5zdHlsZS5wb2ludGVyRXZlbnRzPVwibm9uZVwiLGkuZ3V0dGVyLnN0eWxlLmN1cnNvcj1qLGkucGFyZW50LnN0eWxlLmN1cnNvcj1qLGcuY2FsbChpKX1mdW5jdGlvbiB2KGUpe2UuZm9yRWFjaChmdW5jdGlvbih0LG4pe2lmKG4+MCl7dmFyIGk9RltuLTFdLHI9RVtpLmFdLHM9RVtpLmJdO3Iuc2l6ZT1lW24tMV0scy5zaXplPXQseihyLmVsZW1lbnQsci5zaXplLGkuYUd1dHRlclNpemUpLHoocy5lbGVtZW50LHMuc2l6ZSxpLmJHdXR0ZXJTaXplKX19KX1mdW5jdGlvbiBwKCl7Ri5mb3JFYWNoKGZ1bmN0aW9uKGUpe2UucGFyZW50LnJlbW92ZUNoaWxkKGUuZ3V0dGVyKSxFW2UuYV0uZWxlbWVudC5zdHlsZVt5XT1cIlwiLEVbZS5iXS5lbGVtZW50LnN0eWxlW3ldPVwiXCJ9KX12b2lkIDA9PT1jJiYoYz17fSk7dmFyIHksYixHLEUsdz1sKHVbMF0pLnBhcmVudE5vZGUsRD1lLmdldENvbXB1dGVkU3R5bGUodykuZmxleERpcmVjdGlvbixVPWMuc2l6ZXN8fHUubWFwKGZ1bmN0aW9uKCl7cmV0dXJuIDEwMC91Lmxlbmd0aH0pLGs9dm9pZCAwIT09Yy5taW5TaXplP2MubWluU2l6ZToxMDAseD1BcnJheS5pc0FycmF5KGspP2s6dS5tYXAoZnVuY3Rpb24oKXtyZXR1cm4ga30pLEw9dm9pZCAwIT09Yy5ndXR0ZXJTaXplP2MuZ3V0dGVyU2l6ZToxMCxNPXZvaWQgMCE9PWMuc25hcE9mZnNldD9jLnNuYXBPZmZzZXQ6MzAsTz1jLmRpcmVjdGlvbnx8XCJob3Jpem9udGFsXCIsaj1jLmN1cnNvcnx8KFwiaG9yaXpvbnRhbFwiPT09Tz9cImV3LXJlc2l6ZVwiOlwibnMtcmVzaXplXCIpLEM9Yy5ndXR0ZXJ8fGZ1bmN0aW9uKGUsbil7dmFyIGk9dC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO3JldHVybiBpLmNsYXNzTmFtZT1cImd1dHRlciBndXR0ZXItXCIrbixpfSxBPWMuZWxlbWVudFN0eWxlfHxmdW5jdGlvbihlLHQsbil7dmFyIGk9e307cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHR8fHQgaW5zdGFuY2VvZiBTdHJpbmc/aVtlXT10OmlbZV09bz90K1wiJVwiOmErXCIoXCIrdCtcIiUgLSBcIituK1wicHgpXCIsaX0sQj1jLmd1dHRlclN0eWxlfHxmdW5jdGlvbihlLHQpe3JldHVybiBuPXt9LG5bZV09dCtcInB4XCIsbjt2YXIgbn07XCJob3Jpem9udGFsXCI9PT1PPyh5PVwid2lkdGhcIixcImNsaWVudFdpZHRoXCIsYj1cImNsaWVudFhcIixHPVwibGVmdFwiLFwicGFkZGluZ0xlZnRcIik6XCJ2ZXJ0aWNhbFwiPT09TyYmKHk9XCJoZWlnaHRcIixcImNsaWVudEhlaWdodFwiLGI9XCJjbGllbnRZXCIsRz1cInRvcFwiLFwicGFkZGluZ1RvcFwiKTt2YXIgRj1bXTtyZXR1cm4gRT11Lm1hcChmdW5jdGlvbihlLHQpe3ZhciBpLHM9e2VsZW1lbnQ6bChlKSxzaXplOlVbdF0sbWluU2l6ZTp4W3RdfTtpZih0PjAmJihpPXthOnQtMSxiOnQsZHJhZ2dpbmc6ITEsaXNGaXJzdDoxPT09dCxpc0xhc3Q6dD09PXUubGVuZ3RoLTEsZGlyZWN0aW9uOk8scGFyZW50Ond9LGkuYUd1dHRlclNpemU9TCxpLmJHdXR0ZXJTaXplPUwsaS5pc0ZpcnN0JiYoaS5hR3V0dGVyU2l6ZT1MLzIpLGkuaXNMYXN0JiYoaS5iR3V0dGVyU2l6ZT1MLzIpLFwicm93LXJldmVyc2VcIj09PUR8fFwiY29sdW1uLXJldmVyc2VcIj09PUQpKXt2YXIgYT1pLmE7aS5hPWkuYixpLmI9YX1pZighbyYmdD4wKXt2YXIgYz1DKHQsTyk7aChjLEwpLGNbbl0oXCJtb3VzZWRvd25cIixTLmJpbmQoaSkpLGNbbl0oXCJ0b3VjaHN0YXJ0XCIsUy5iaW5kKGkpKSx3Lmluc2VydEJlZm9yZShjLHMuZWxlbWVudCksaS5ndXR0ZXI9Y30wPT09dHx8dD09PXUubGVuZ3RoLTE/eihzLmVsZW1lbnQscy5zaXplLEwvMik6eihzLmVsZW1lbnQscy5zaXplLEwpO3ZhciBmPXMuZWxlbWVudFtyXSgpW3ldO3JldHVybiBmPHMubWluU2l6ZSYmKHMubWluU2l6ZT1mKSx0PjAmJkYucHVzaChpKSxzfSksbz97c2V0U2l6ZXM6dixkZXN0cm95OnB9OntzZXRTaXplczp2LGdldFNpemVzOmZ1bmN0aW9uKCl7cmV0dXJuIEUubWFwKGZ1bmN0aW9uKGUpe3JldHVybiBlLnNpemV9KX0sY29sbGFwc2U6ZnVuY3Rpb24oZSl7aWYoZT09PUYubGVuZ3RoKXt2YXIgdD1GW2UtMV07Zy5jYWxsKHQpLG98fGYuY2FsbCh0LHQuc2l6ZS10LmJHdXR0ZXJTaXplKX1lbHNle3ZhciBuPUZbZV07Zy5jYWxsKG4pLG98fGYuY2FsbChuLG4uYUd1dHRlclNpemUpfX0sZGVzdHJveTpwfX19KTtcclxuIl19
